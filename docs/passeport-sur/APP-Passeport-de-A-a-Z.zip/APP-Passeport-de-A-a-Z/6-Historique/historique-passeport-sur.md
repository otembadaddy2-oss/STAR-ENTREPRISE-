- **Pubs pour www.starentreprise.com** (« /ads ») : Carry veut y revenir plus tard. Proposer : (1) voir les pubs des concurrents, (2) créer les visuels, (3) texte + plan de campagne, (4) vraie campagne payante (seulement après son accord + budget).
- **Pili-Pili Events** : savoir si la personne utilise son espace (1 seule visite en 24 h, probablement la nôtre). Question ouverte : filiale ou cliente partenaire ?
- **Idée de projet d'État (passeports)** : application de suivi des demandes de passeport pour le Ministère / Préfecture de Brazzaville. À cadrer en démonstration avec données fictives avant toute donnée réelle.

## 24/11/2026 — Démo « Suivi des demandes de passeport » (dossier passeport-demo/)
- App autonome (aucune donnée réelle, données fictives stockées sur l'appareil) : scan MRZ (clés de contrôle vérifiées, testé sur le spécimen ICAO), première demande + **renouvellement passeport expiré** (ancien passeport à restituer avant la remise), statuts + historique, alertes anti-fraude, tableau de bord Ministère/Préfecture, export Excel, reçu avec QR.
- Excel d'exemple avec formules vivantes et diagrammes : `tools/fabrique-excel-passeport-demo.py`.
- NON mis en ligne (≈41 crédits Netlify). À faire si Carry dit oui : mise en ligne + page protégée/noindex ; dossier PDF de présentation pour le Ministère ; lecture automatique de la photo (OCR) à rendre hors-ligne avant une vraie démo.

## 25/11/2026 — « Passeport Sûr » : application finale (dossier passeport-demo/)
- Refonte complète : design aux couleurs du Congo (vert/jaune/rouge + vert forêt), logo SVG dessiné (bouclier-drapeau + livret + coche), accueil, 7 écrans, installable et hors connexion (PWA).
- **Logo : Higgsfield a seulement 0,23 crédit (une image = 0,75)** → logo fait en SVG. Si Carry recharge, proposer des variantes d'image Higgsfield.
- Moteur anti-fraude : pièce modifiée (chiffres de contrôle), doublon, double identité, réseau d'intermédiaires (même téléphone), pièce expirée, renouvellement irrégulier, étape sautée, remise éclair, action de nuit, dossier bloqué, agents à surveiller ; score de risque 0-100 ; la Préfecture classe « vérifié » ou « enquête ».
- Suivi par le demandeur (n° de dossier + code du reçu). Excel enrichi : `tools/fabrique-excel-passeport-demo.py`.
- NON mis en ligne (≈41 crédits). Prochaines étapes à proposer : mise en ligne (page non référencée), dossier PDF de présentation pour le Ministère, lecture photo hors-ligne.

## 25/11/2026 — « Passeport Sûr » : photos + signature STAR ENTREPRISE cachée
- 6 photos libres de droits (licence Unsplash, ~830 Ko en WebP) : Brazzaville (Valdhy Mbemba ×3), passeport (Global Residence Index), empreinte (George Prentzas), aéroport (Jakub Żerdzicki). Script : `tools/photos-passeport-sur.py`.
- Signature discrète en bas de chaque écran (logo officiel STAR ENTREPRISE + « Tous droits réservés », comme KOMYO) ; bouton « ⓘ Informations » qui ouvre le panneau caché : logo officiel, slogan, contacts, crédits photos. Méta « auteur : STAR ENTREPRISE » dans la page.
- Environnement Carry : `images.unsplash.com` ajouté aux hôtes autorisés (nécessaire au téléchargement des photos).
- Toujours NON mis en ligne (≈41 crédits). À proposer : mise en ligne + dossier PDF Ministère.

## 25/11/2026 — « Passeport Sûr » v2 : signature, WhatsApp, caisse, file d'attente
- Signature tactile (doigt/stylet) + photo : enregistrées dans le dossier, visibles à la caisse et en préfecture.
- Accusé WhatsApp avec QR (aperçu + bouton « Envoyer » wa.me + QR téléchargeable) ; lien de suivi `?suivi=N°&code=`. En réel : API WhatsApp Business (compte Meta à ouvrir) pour l'envoi automatique.
- Profil Caisse : scan du QR (jsQR), fiche complète, encaissement (montant saisi, aucun tarif inventé), reçu de paiement + N° d'appel ; encaissement bloqué si alerte grave non examinée.
- File d'attente : ordre du paiement, appel par porte (1 à 4), « rappeler », « absent » ; écran de salle `ecran.html` (numéro, nom, porte, bip + voix française, prochains numéros). 6 états : déposée → payée → reçue → traitement → prête → remise.
- Interprétation : « système de kimatique » = système de file d'attente avec écrans (à confirmer avec Carry).
- Toujours NON mis en ligne (≈41 crédits).

## 25/11/2026 — « Passeport Sûr » v3 : pièces jointes, reprise, retour
- Pièces à joindre : 📷 photo (caméra) ou 📎 fichier (image ou PDF ≤ 3 Mo), plusieurs documents ; stockées sur l'appareil (IndexedDB) dans la démo. Liste INDICATIVE par type de demande (première demande : photo, pièce d'identité, acte de naissance, certificat de nationalité ; renouvellement : photo, pièce d'identité, ancien passeport) → à confirmer avec la Préfecture.
- Dossier incomplet enregistrable ; l'accusé WhatsApp liste les pièces manquantes + lien de suivi ; la caisse ne peut pas encaisser tant que c'est incomplet (elle peut ajouter les pièces sur place) ; le demandeur complète depuis « Suivre mon dossier ».
- Reprise : brouillon sauvegardé automatiquement (champs, pièces, signature) avec bandeau « Reprendre » ; étapes cliquables 1-5 ; bouton ← Retour sur chaque écran et bouton Retour du téléphone (historique).
- Correctif : ids des cartes du guichet renommés gt1-gt5 (conflit avec les graphiques g1-g4).
- Toujours NON mis en ligne (≈41 crédits).

## 25/11/2026 — Passeport Sûr : plusieurs portes
- File d'attente : « Porte 1, Porte 2, … » (6 par défaut, réglable de 1 à 12, nom facultatif par porte). Chaque porte a ses boutons Appeler le suivant / Rappeler / Absent et son numéro en cours.
- Écran de la salle : grand appel en cours (numéro, nom, porte) + grille de toutes les portes avec leur numéro et nom + prochains numéros.
- Interprétation à confirmer avec Carry : « Porte 1, porte 2 … etc » = plusieurs portes numérotées, chacune appelant ses propres numéros.

## Passeport Sûr v4 — système partagé en temps réel (25/11/2026)
- Demande de Carry : écrans de la salle (« kimatique ») reliés à l'application et à la caisse ; après paiement le demandeur reçoit sur son accusé la date de son rendez-vous d'enrôlement ; numéros, noms et portes diffusés en direct dès qu'on allume les écrans.
- Fait et testé en local (PostgreSQL réel, 3 postes + 2 écrans + 1 demandeur) : espace partagé (code à 8 caractères), paiement unique avec numéro d'appel sans doublon et rendez-vous au premier jour ouvré avec de la place, message WhatsApp avec la date, appel aux portes (1 à 12, personnes différentes par porte), écrans « Démarrer » (code + nom d'écran, plein écran, son/voix, bandeau si connexion perdue, reprise automatique), réglages (portes, capacité/jour, délai, jours, heure, créneaux, lieu, date simulée), pièces sur le serveur, lien de suivi du demandeur (accès limité à SON dossier).
- Bug trouvé par les tests et corrigé : capacité/jour dépassée en paiements simultanés (maintenant garantie par l'index unique sur le numéro d'appel).
- NON mis en ligne. Avant tout déploiement Netlify : demander le go de Carry, annoncer ≈ 41 crédits, prévenir que les écrans interrogent le serveur toutes les ~1,5 s (coût en invocations : en production, prévoir un hébergement dédié) ; l'envoi WhatsApp automatique exige un compte WhatsApp Business (Meta) — dans la démo l'envoi est manuel (bouton).
- À confirmer avec Carry : « kimatique » = file d'attente/affichage en salle ; « Porte 1, porte 2… » = plusieurs portes d'appel.

## Passeport Sûr v5 (25/11/2026) — demandes de Carry après v4
- Écran de salle : chaque numéro reste au moins 10 s, les appels simultanés passent un par un dans l'ordre, voix qui annonce numéro + nom + « veuillez vous diriger vers la porte N » (répétée une fois), « + N appels à annoncer » ; un absent repasse en fin de file. Testé (t_file) : 001/002/003 espacés de 10 s, absent après le dernier.
- Style « verre » (acrylique) + transitions de pages façon Windows 11 (zoom, flou, glissement, voile de verre, cascade des cartes) ; désactivé si « mouvement réduit ».
- RÈGLE : aucune mise en ligne Netlify (≈ 41 crédits) sans que Carry ait donné son accord APRÈS vérification complète.

## Passeport Sûr v6 (25/11/2026) — préparation à la mise en ligne (NON déployé)
- Confirmé par Carry : « kimatique » = affichage de la file d'attente en salle ; « Porte 1, porte 2… » = plusieurs portes d'appel. Il veut la perfection AVANT la mise en ligne (≈ 41 crédits Netlify, pas d'aller-retour) ; il testera puis « supprimera son test ».
- Ajouts : guide d'utilisation automatique (choix du profil au premier lancement, visite guidée par profil, « Commencez ici », ❓ Aide + FAQ, mémorisation du dernier profil), rythme de synchro économe (1,5 s → 3 s → 5 s si rien ne bouge ; onglet caché 8 s puis veille), signe de vie des écrans écrit au plus toutes les 15 s, création d'espace en 5 requêtes (insertion groupée), bouton « Effacer définitivement l'espace » (dossiers + pièces, y compris orphelines), lecture « forte » du stockage des pièces, en-têtes noindex + caméra autorisée pour /passeport-demo, lecture MRZ par Tesseract HÉBERGÉ (lib/ocr-5.1.0, plus de site externe) avec corrections O/0, I/1 et caractère en trop/manquant (les clés de contrôle ne sont jamais « réparées »), cibles tactiles ≥ 34 px.
- Bugs trouvés par les tests et corrigés : capacité/jour dépassée en paiements simultanés ; premier appel retardé par un affichage de reprise ; profil non mémorisé au rechargement ; message de panne réseau peu clair ; syntaxe d'un fichier de fonction (attrapée par le bundle esbuild).
- Tests rangés dans tools/tests-passeport/ (LISEZ-MOI.md) : à relancer AVANT toute mise en ligne. Vérifier aussi le bundle : esbuild des 2 fonctions.
- Limites non vérifiables ici : vraie base/stockage Netlify, caméra et lecture de VRAIES pièces sur téléphone, fluidité du verre sur téléphone modeste, voix française de la télévision.
- Supprimer la page après test = un nouveau déploiement : conseiller de la laisser en ligne (non indexée, sans lien) et d'effacer les données avec le bouton.
- Pour un usage réel : hébergement dédié (VPS) + PostgreSQL, hébergement des données conforme aux exigences de l'État ; WhatsApp automatique = API WhatsApp Business (Meta) avec modèles de messages approuvés (payant) ou SMS.

## RÈGLE DE CARRY (25/11/2026) — Passeport Sûr
- Dans TOUS les documents, PDF, guides, vidéos et présentations, TOUJOURS préciser le BUT de l'application (à quoi elle sert, pour qui, quel problème elle résout) : cela doit être connu de tout lecteur/spectateur.
- Carry demande aussi : dossier PDF complet + guide d'utilisation détaillé de A à Z + guide vidéo détaillé + application vraiment fluide (fluidité mesurée : 52-60 i/s à CPU ×2, chargement 3,0 s → 1,5 s, 2,4 → 1,1 Mo).

## Passeport Sûr — documents et vidéo (25/11/2026)
- Livrables dans docs/passeport-sur/ (JAMAIS publics : bloqués dans _redirects) : Passeport-Sur-Dossier-de-presentation.pdf (17 p.), Passeport-Sur-Guide-utilisation-A-a-Z.pdf (26 p.), Passeport-Sur-Guide-video.mp4 (sous-titres, sans voix).
- Sources : tools/documents-passeport/ (capturer.cjs → captures réelles ; fabrique-presentation.cjs ; fabrique-guide.cjs ; fabrique-video.cjs + video-cadre.html ; lib-documents.cjs). Régénérer : serveur de test 8766 + `NODE_PATH=$(npm root -g) node …`.
- RÈGLE DE CARRY : le BUT de l'application est rappelé partout (couverture, bandeau à chaque page, ruban permanent de la vidéo, carte finale).
- Voix off : ElevenLabs non connecté (connexion refusée : Carry doit se reconnecter dans les connecteurs). Alternative testée en lecture seule : vidIQ (150 crédits, voix françaises Victoria/Nicolas/Guillaume/Adina) ; coût d'une narration inconnu → NE PAS dépenser sans l'accord de Carry. Texte de la voix : tools/documents-passeport/video/texte-de-la-voix.txt.
- Fluidité : chargement 3,0 → 1,5 s, 2,4 → 1,1 Mo ; 52-60 i/s (CPU ×2).

## Passeport Sûr v8 → v10 (25/11/2026) — NON déployé, en attente du « go » de Carry (≈ 41 crédits Netlify à annoncer avant)
- Nouveautés : pré-enregistrement du demandeur (inscription.html) + espace Accueil (front office) ; l'accueil valide le paiement (onglets Réception, Caisse, Dossiers) ; comptes + connexion (identifiant/mot de passe, rôles imposés par le SERVEUR, mot de passe oublié via la Préfecture, code de secours Préfecture, blocage après 5 essais) ; montant officiel (saisi une fois dans Réglages, imposé par le serveur) ; alerte de fraude du Ministre en temps réel ; journal de sécurité chaîné (Préfecture + Ministère) + alerte de sécurité ; CSP ; déconnexion après 30 min ; montant sur l'accusé WhatsApp et le suivi.
- Sécurité (demande de Carry : « aucun informaticien ne doit pouvoir contourner ») : intégrité serveur des dossiers (paiement/ticket/rdv/appel posés par le serveur, étapes d'un cran, accueil, historique signé et daté serveur), limites anti-force-brute, fichiers contrôlés par leurs octets, erreurs neutres. 160+ contrôles serveur dont 18 attaques ; tests navigateur sous CSP (t_securite.cjs). LIMITES À DIRE HONNÊTEMENT : base de données/hébergeur non maîtrisés, poste infecté/mot de passe prêté, abus d'un agent habilité, saturation réseau ; pas de double authentification ; audit/pentest indépendant NÉCESSAIRE avant usage réel ; journal à copier vers un stockage à écriture unique.
- Mode « espace sécurisé » = option cochée à la création de l'espace ; un espace de démonstration reste ouvert par son code (voulu, pour les essais et la vidéo).
- DÉCISIONS EN ATTENTE DE CARRY : nom définitif (recommandé : garder « Passeport Sûr » ; pistes « Nzela », « Passeport Clair » — disponibilité marque/domaine NON vérifiée) ; montant officiel (à saisir dans Réglages dès communiqué) ; canal « mot de passe oublié » (courriel/SMS : fournisseur à choisir) ; signature d'un dossier pré-enregistré ; qui est alerté et par quel canal ; WhatsApp Business API (envoi automatique de l'accusé avec le montant : Meta Cloud API, modèles approuvés, payant — aujourd'hui bouton « Envoyer par WhatsApp ») ; hébergement (VPS, pas hébergement mutualisé).
- Voix off Clémence (ElevenLabs, voix LFo5X4P9PhYaOLBA9Hyh) pour la vidéo : connecteur ElevenLabs refusé → Carry doit se reconnecter ; rien n'est dépensé ailleurs (vidIQ/Higgsfield) sans son accord.
- Application légère : 1,4 Mo hors lecteur de pièces (12 Mo, chargé à la demande), images WebP ; compression complémentaire des 3 grandes photos et icône iPhone/installation guidée faites ou à finir (tâche #64).

## Passeport Sûr — v11 (25/11) : installation facile + livrables finaux
- Page `installer.html` (détecte Android / iPhone / ordinateur, QR, partage WhatsApp), bouton jaune « 📲 Installer » en haut, taille du texte réglable (Aide), images allégées (601 Ko au total). Cache `passeport-sur-v16`.
- Deux défauts trouvés et corrigés : (1) la toute première alerte de sécurité sur un espace vierge n'apparaissait pas chez le Ministre ; (2) en espace sécurisé, le bouton Aide était caché. Tests ajoutés : `t_install.cjs`, `t_vigie.cjs`.
- Livrables régénérés dans `docs/passeport-sur/` : dossier de présentation (29 p.), guide A à Z (36 p.), vidéo MP4 (≈ 9 min 40, sous-titrée) + `tools/documents-passeport/video/texte-de-la-voix.txt`.
- EN ATTENTE : voix de Clémence (ElevenLabs refuse la connexion : Carry doit se reconnecter dans les connecteurs) ; aucun déploiement Netlify (~41 crédits) sans son « go ».

## 2026-11-25 (soir) — Passeport Sûr EN LIGNE (PR #86 fusionnée, merge 99a0177) sur le « Go » de Carry
- Lien : https://star-entreprise.netlify.app/passeport-demo/ (page d'installation : /passeport-demo/installer.html). Noindex, données fictives, documents/tools bloqués (404 vérifiés).
- Vérifié EN LIGNE (vraies fonctions + vraie base) : t_vigie, t_install, t_accueil, t_securite (tout OK sauf les en-têtes d'API ci-dessous).
- DÉCOUVERTE : Netlify n'applique PAS `_headers` aux fonctions → en ligne, l'API n'envoie ni CSP « rien » ni `no-store` (elle envoie `no-cache` + nosniff). Correctif PRÊT et testé en local (commit sur la branche, `verrouiller()` dans api-passeport et api-passeport-piece), NON déployé : à grouper avec les retours du test de Carry (un seul déploiement ≈ 41 crédits).
- Espaces de test en ligne effacés (3NYNTYX6, KUEGF8AM, GQEKMPDE). Un espace de démonstration fictif créé par t_accueil via l'interface reste en ligne (code inconnu, sans donnée réelle).
- À faire après le test de Carry : effacer son espace de test (bouton « Effacer l'espace »), saisir le vrai montant officiel, voix de Clémence (reconnexion ElevenLabs).
- (25/11 soir) Demande de Carry : « Alerte avec un son, c'est important ». FAIT et EN LIGNE (PR #87, merge 689feff) : `son-alerte.js` (sirène deux tons + vibration, fraude ET sécurité, rappel « touchez l'écran », bouton 🔔 Son + Aide), en-têtes d'API posés par les fonctions. Cache `passeport-sur-v17`. Testé en local et EN LIGNE (t_son, t_securite). Limites : son seulement quand l'appli est ouverte (pas de notification en arrière-plan : il faudrait le Web Push), téléphone en silencieux possible. Espaces de test en ligne effacés. À faire : régénérer PDF + vidéo avec la phrase sur le son (textes déjà modifiés dans les scripts).
- (25/11 nuit) PRIX : Carry confirme que le passeport coûte **50 000 FCFA** au Congo, sauf changement du gouvernement. Préenregistré partout (première demande ET renouvellement : même montant par défaut, à changer dans Réglages si le renouvellement diffère) : serveur (`tarifs` par défaut), application, démonstration, documents. EN LIGNE (PR #88, merge cd1be08, cache v18), vérifié : un nouvel espace en ligne a bien tarifs 50000/50000. PDF et vidéo régénérés. Les espaces créés AVANT ce déploiement gardent leur ancien réglage (à ressaisir dans Réglages).
- VOIX OFF : la vidéo reste SANS VOIX (sous-titres seulement). ElevenLabs refuse toujours la connexion (Carry doit se reconnecter dans les connecteurs). Alternatives payantes à ne lancer qu'avec son accord : Higgsfield / vidIQ (crédits).

## RÈGLES PERMANENTES DE CARRY (25/11/2026, soir) — à appliquer toujours
- **Tout garder dans le dépôt** : tout le travail (STAR ENTREPRISE et tout ce qui se fait) reste enregistré dans le dépôt GitHub ; une copie de tout ce que Carry fait avec Claude doit être conservée, et Claude doit pouvoir la lui RENVOYER s'il la perd (fichiers via SendUserFile). Pour Passeport Sûr : `bash tools/fabriquer-zip-passeport.sh` refait `docs/passeport-sur/APP-Passeport-de-A-a-Z.zip` (application, serveur, tests, documents, vidéo, historique ; jamais public).
- **Modifications** : seulement sur information/ordre de Carry (par ex. une information venue du Ministère : « connecte-toi puis modifie cette partie »). Claude les fait en toute sécurité, testées, bien faites ; mise en ligne Netlify (≈ 41 crédits) seulement avec son accord.
- **Signaler** à Carry dès que tout est terminé à 100 %.
- **Passeport Sûr — son des alertes** : la sirène dure 2-3 s ; bouton « 🔇 Arrêter le son » pendant qu'elle sonne ; « 🔔 Son » dans le bandeau et dans Aide pour couper/rétablir ; « Marquer comme lues » retire le bandeau et coupe le son. (Bouton d'arrêt codé, testé, cache v19, NON déployé en attendant l'accord de Carry.)
- **Applications des magasins (App Store / Play Store)** : question de Carry, réponse donnée : possible plus tard, au moment opportun (voir compte rendu : Android via PWA/TWA, iPhone via Capacitor ; comptes développeur ; domaine et hébergement définitifs ; compte de l'organisation du Ministère probable). Rien à faire maintenant.
- (25/11 nuit) ESPACE DE DÉMONSTRATION EN LIGNE créé pour le test de Carry : code `63YBNBYP` (espace sécurisé, 100 dossiers fictifs, montant 50 000), 6 comptes `*.demo` (prefecture, ministre, accueil, caisse, agent, porte) avec des mots de passe de démonstration remis à Carry seulement dans le PDF « AVEC mots de passe » (jamais dans le dépôt). Code public de pré-enregistrement : `3KUMJZ6N`. À EFFACER après le test (Préfecture > pastille Espace > Effacer, ou par Claude avec le compte Préfecture). Parcours : `docs/passeport-sur/Passeport-Sur-Parcours-de-test.pdf` (version sans mots de passe).
- (25/11 nuit) AFFICHE Passeport Sûr avec code QR (idée validée par Carry, sur le modèle de l'affiche KOMYO « Scanne-moi ») : couple heureux qui scanne (images fictives générées avec Canva), « Scanne-moi ! », « C'est gratuit ! », le but de l'application, signature STAR ENTREPRISE, mention « Version de démonstration ». Le QR mène à la page d'installation de DÉMONSTRATION ; à refaire avec l'adresse définitive (sources dans `tools/documents-passeport/affiche/`). Fichiers : `docs/passeport-sur/AFFICHE-Passeport-Sur-QR-*`. Le QR a été décodé par ordinateur (même réduit à 360 px de large). Pour télécharger l'image HD de Canva, l'hôte `export-download.canva.com` a été ajouté à l'environnement (accepté).
- (25/11 nuit, suite) AFFICHE v2 sur demande de Carry : personnes africaines (Congolaises), une SEULE jeune femme très belle et heureuse, visage bien visible, image sans pixels. Photo fictive générée avec Canva (2400 x 3600 ; la source native est un peu plus petite : nette à l'écran et en A3, un peu douce en 40 x 60 cm). Higgsfield inutilisable (solde 0,23 crédit, 0,75 par image) ; Canva : quota de crédits épuisé pour de NOUVELLES créations (la page de travail a été réutilisée). Version « couple » abandonnée. Mise en page : titre au-dessus de la tête, visage dégagé, QR grand en bas à droite (décodé par ordinateur), le but affiché, mention « Version de démonstration ».
