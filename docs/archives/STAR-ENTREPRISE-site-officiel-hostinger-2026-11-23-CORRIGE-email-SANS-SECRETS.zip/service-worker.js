/* ============================================================
 *  STAR ENTREPRISE — Service Worker (application installable)
 *  ------------------------------------------------------------
 *  Rôle : le site marche même avec une connexion faible.
 *   - Pages HTML  : réseau d'abord (contenu toujours frais),
 *                   secours cache si hors-ligne.
 *   - Fichiers    : cache d'abord + mise à jour en arrière-plan.
 *   - /api/       : JAMAIS mis en cache (paiements & messages
 *                   doivent toujours partir en direct).
 *  Pour forcer une mise à jour chez les visiteurs : changez
 *  'v1' ci-dessous en 'v2', 'v3', … puis republiez le site.
 * ============================================================ */
const STAR_CACHE = 'star-entreprise-v2'; // v2 : ajout du livre « De l'Ombre à la Lumière » (05-09-2026)

self.addEventListener('install', function () {
    self.skipWaiting();
});

self.addEventListener('activate', function (e) {
    e.waitUntil(
        caches.keys()
            .then(function (cles) {
                return Promise.all(cles.map(function (c) {
                    if (c !== STAR_CACHE) return caches.delete(c);
                }));
            })
            .then(function () { return self.clients.claim(); })
    );
});

self.addEventListener('fetch', function (e) {
    var url;
    try { url = new URL(e.request.url); } catch (err) { return; }

    // On ne s'occupe que des requêtes GET de NOTRE site
    if (e.request.method !== 'GET' || url.origin !== self.location.origin) return;
    // Jamais de cache pour l'API (paiements, messages, admin)
    if (url.pathname.indexOf('/api/') === 0 || url.pathname.indexOf('/backend/') === 0 || url.pathname.indexOf('/admin/') === 0) return;

    // Navigation (pages) : réseau d'abord, secours cache
    if (e.request.mode === 'navigate') {
        e.respondWith(
            fetch(e.request).then(function (rep) {
                if (rep && rep.ok) {
                    var copie = rep.clone();
                    caches.open(STAR_CACHE).then(function (c) { c.put(e.request, copie); });
                }
                return rep;
            }).catch(function () {
                return caches.match(e.request).then(function (m) {
                    return m || caches.match('index.html');
                });
            })
        );
        return;
    }

    // Fichiers statiques (css/js/images) : cache d'abord + rafraîchissement
    e.respondWith(
        caches.match(e.request).then(function (mem) {
            var frais = fetch(e.request).then(function (rep) {
                if (rep && rep.ok) {
                    var copie = rep.clone();
                    caches.open(STAR_CACHE).then(function (c) { c.put(e.request, copie); });
                }
                return rep;
            }).catch(function () { return mem; });
            return mem || frais;
        })
    );
});
