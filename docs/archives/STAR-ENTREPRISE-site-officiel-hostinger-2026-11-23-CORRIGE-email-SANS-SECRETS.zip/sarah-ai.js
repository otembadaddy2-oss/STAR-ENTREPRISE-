/**
 * STAR ENTREPRISE — SARAH AI ASSISTANT (Moteur Anthropic Claude v4.5 + Mode Vocal Charme & Attirance)
 * - Voix unique, douce, chaleureuse et accueillante (synthèse audio mp3 + modulation acoustique)
 * - Bouton Démarrer une Conversation en Mode Vocal
 * - Architecture Anthropic Claude (possibilité d'insérer la clé API Anthropic ultérieurement)
 * - Règle anti-digression stricte
 */

/* ==========================================================================
   1. CONFIGURATION ANTHROPIC CLAUDE API (Moteur IA Sarah-Claude v4.5)
   ==========================================================================
   Vous pouvez insérer votre clé API Anthropic (Claude 3.5 Sonnet / Claude 3 Opus)
   ci-dessous pour activer la génération par intelligence artificielle cloud en direct.
   Si la clé est vide (""), le moteur hybride local de 36 modules prend le relais
   avec une fiabilité à 100% sans digression.
   ========================================================================== */
window.SarahAIConfig = {
  engine: "Anthropic Claude",
  model: "claude-3-5-sonnet-20241022",
  // ⚠️ NE JAMAIS coller ici une vraie clé Anthropic : ce fichier est visible
  // par n'importe quel visiteur du site (« Afficher le code source »). Une
  // clé insérée ici serait volée en quelques minutes. Le moteur IA cloud de
  // Sarah vit désormais côté serveur uniquement, dans backend/whatsapp.php
  // (variable ANTHROPIC_API_KEY de config.php). Ce champ reste vide par
  // design — le moteur hybride local de 36 modules ci-dessous prend le relais.
  anthropicApiKey: "",
  maxTokens: 600,
  temperature: 0.7,
  systemPrompt: `Tu es Sarah, l'assistante virtuelle de direction de STAR ENTREPRISE, groupe congolais multiservices fondé par Carry OTEMBA (auteur de « De l'Ombre à la Lumière »), PDG de STAR ENTREPRISE. Tu t'exprimes avec charme, douceur, élégance, et un professionnalisme irréprochable et courtois en toute circonstance. Quand tu évoques le fondateur, tu le nommes toujours par son titre exact : « le PDG de STAR ENTREPRISE, Carry OTEMBA ». Tu réponds uniquement aux sujets concernant STAR ENTREPRISE, ses filiales au Congo, et Carry OTEMBA — zéro digression. Règle d'or : tu ne devines JAMAIS un prix, une date, une disponibilité ou un fait absent de ta base de connaissances ; dans le doute, tu le dis avec élégance et tu transmets la question à l'équipe plutôt que d'inventer une réponse.`
};


(function () {
  'use strict';

  /* ==========================================================================
     1. MEMOIRE DE CONVERSATION & HISTORIQUE CONTEXTUEL
     ========================================================================== */
  const SarahMemory = {
    lastTopic: null,
    turnCount: 0,
    userName: null,
    history: []          // Mémoire courte de la conversation (réponses cohérentes)
  };

  /* ==========================================================================
     2. BASE DE CONNAISSANCES STRUCTUREE DES FILIALES & SERVICES (35 Domaines)
     ========================================================================== */
  const CORPORATE_DB = {
    groupe_apropos: {
      name: 'STAR ENTREPRISE',
      summary: 'Entreprise multiservices congolaise réunissant plus de 20 filiales dans 6 grands secteurs : Santé & Social, Immobilier & Habitat, Tourisme & Prestige, Mobilité, Numérique & Créatif, Services & Événementiel.',
      vision: '« Un compte. Un groupe. Toutes les solutions pour votre vie. »',
      details: 'Notre objectif est de simplifier la vie des familles, entreprises et investisseurs en République du Congo en regroupant tous les services essentiels au sein d\'un écosystème digital centralisé.',
      link: 'index.html#apropos',
      linkText: 'Découvrir le groupe →'
    },
    fondateur_pdg: {
      name: 'Carry Otemba',
      summary: 'Fondateur & Président Directeur Général de STAR ENTREPRISE.',
      details: 'Entrepreneur visionnaire, investisseur, artiste peintre et auteur du livre inspirant « De l\'Ombre à la Lumière ». Il transmet à travers son parcours un message de discipline, de persévérance et d\'espoir pour la jeunesse et les entrepreneurs africains.',
      link: 'index.html#fondateur',
      linkText: 'En savoir plus sur Carry Otemba →'
    },
    compte_inscription: {
      name: 'Compte Unique STAR ENTREPRISE',
      summary: 'Système d\'identifiant unique pour accéder à toutes les filiales et services du groupe.',
      details: 'En créant votre compte unique, vous disposez d\'un tableau de bord personnalisé pour gérer vos réservations, rendez-vous médicaux, paiements et contrats à travers les 20+ filiales sans devoir vous réinscrire.',
      link: 'mon-compte.html#signup',
      linkText: 'Créer mon compte unique →'
    },
    paiement_moyens: {
      name: 'Moyens de Paiement Sécurisés',
      summary: 'Solutions de paiement 100% adaptées au Congo et à l\'Afrique francophone.',
      details: 'Nous acceptons : 1) Mobile Money (MTN Mobile Money & Airtel Money), 2) Virement bancaire / Carte bancaire, 3) Paiement en espèces directement en agence ou auprès de nos équipes commerciales.',
      link: 'mon-compte.html',
      linkText: 'Accéder à mon espace paiement →'
    },
    localisation_adresses: {
      name: 'Localisation & Agences au Congo',
      summary: 'Présence en République du Congo à Brazzaville et Pointe-Noire.',
      details: 'Notre groupe dispose de directions et d\'agences à Brazzaville (capitale politique) et à Pointe-Noire (capitale économique, siège de STAR JET et STAR Beach Village). Notre plateforme en ligne est accessible 24h/24.',
      link: 'index.html#contact',
      linkText: 'Voir nos agences et adresses →'
    },
    groupe_carrieres: {
      name: 'Carrières & Recrutement',
      summary: 'Opportunités d\'emploi et de stage dans notre écosystème.',
      details: 'STAR ENTREPRISE recrute régulièrement des talents passionnés dans l\'immobilier, la santé, le digital, l\'aviation, l\'hôtellerie et les services techniques. Vous pouvez postuler en ligne ou soumettre une candidature spontanée.',
      link: 'carrieres.html',
      linkText: 'Consulter nos offres d\'emploi →'
    },
    groupe_contact: {
      name: 'Centre d\'Assistance & Contact',
      summary: 'Support client réactif et assistance téléphonique.',
      details: 'Notre assistance est joignable par téléphone au +242 06 656 50 50 ou en ligne via votre espace client. Nos conseillers vous accompagnent pour toute question sur nos filiales.',
      link: 'index.html#contact',
      linkText: 'Contacter notre assistance →'
    },
    partenaires_assurances: {
      name: 'Partenaires, Banques & Assurances',
      summary: 'Collaborations avec les leaders africains de la banque et de l\'assurance.',
      details: 'Nos partenaires de confiance incluent : NSIA Assurances, SUNU Assurances, OLEA, ASCOMA Groupe, ARC, AGC-VIE, Willis Towers Watson, Banque Postale du Congo, UBA Congo, LCB Bank, Bank of Africa, MTN et Airtel.',
      link: 'index.html#partenaires',
      linkText: 'Voir tous nos partenaires →'
    },
    projets_phares: {
      name: 'Projets Phares du Groupe',
      summary: 'Réalisations d\'excellence de STAR ENTREPRISE.',
      details: 'Nos projets phares illustrent notre innovation : 1) STAR Beach Village (resort Tiny Houses en bord de mer), 2) STAR JET (aviation privée VIP), 3) Clinique Havre de Vie (santé connectée), 4) CARRY.O AFRIQUE (galerie d\'art contemporain).',
      link: 'star-beach-village.html',
      linkText: 'Découvrir nos projets phares →'
    },
    immo_starimmo: {
      name: 'STAR IMMO',
      summary: 'Spécialiste de la vente, gestion, promotion et location immobilière au Congo.',
      details: 'Que vous cherchiez à acheter une villa, louer un appartement haut de gamme, acquérir un terrain titré ou confier la gestion locative de votre bien, STAR IMMO vous offre un accompagnement juridique et technique sécurisé.',
      link: 'star-immo.html',
      linkText: 'Découvrir STAR IMMO →'
    },
    immo_pamep: {
      name: 'STAR P.A.M.E.P',
      summary: 'Gestion, entretien, réhabilitation et sécurisation des patrimoines immobiliers.',
      details: 'STAR P.A.M.E.P assure la maintenance de bâtiments publics et privés, les travaux de réhabilitation, le syndic de copropriété et la sécurisation foncière des patrimoines.',
      link: 'star-pamep.html',
      linkText: 'Découvrir STAR P.A.M.E.P →'
    },
    immo_meubles: {
      name: 'STAR Galerie Meubles',
      summary: 'Mobilier résidentiel et professionnel, décoration intérieure et livraison à domicile.',
      details: 'Nous équipons vos salons, chambres, bureaux et espaces de réception avec des meubles modernes, durables et élégants, complétés par un conseil en décoration intérieure.',
      link: 'star-galerie-meubles.html',
      linkText: 'Visiter Galerie Meubles →'
    },
    meubles_residentiel: {
      name: 'STAR Galerie Meubles — Mobilier Résidentiel',
      summary: 'Collection exclusive : Salon, chambre, salle à manger et extérieur pour votre maison.',
      details: 'Découvrez notre catalogue en ligne : fauteuils de prestige, salons en cuir ou velours, suites parentales, tables de réception et mobilier de terrasse résistants.',
      link: 'star-galerie-meubles-residentiel.html',
      linkText: 'Ouvrir le catalogue Mobilier Résidentiel →'
    },
    immo_decobaby: {
      name: 'STAR Déco Baby',
      summary: 'Conception et aménagement d\'espaces pour bébés et enfants.',
      details: 'STAR Déco Baby crée des chambres d\'enfants, crèches et aires de jeux sécurisées, ergonomiques et inspirantes, adaptées à l\'épanouissement des tout-petits.',
      link: 'star-deco-baby.html',
      linkText: 'Découvrir STAR Déco Baby →'
    },
    sante_liboke: {
      name: 'LIBOKE Épargne + Santé',
      summary: 'Solutions d\'épargne programmée, d\'épargne santé et accompagnement familial.',
      details: 'LIBOKE permet aux ménages congolais de constituer une épargne sécurisée pour leurs projets, de protéger la santé de la famille avec une couverture santé solidaire et d\'accéder à un soutien social en cas de coup dur.',
      link: 'liboke.html',
      linkText: 'Découvrir LIBOKE Épargne + Santé →'
    },
    sante_clinique: {
      name: 'Clinique Havre de Vie',
      summary: 'Santé moderne, prise de rendez-vous en ligne, dossier patient et téléconsultation.',
      details: 'La Clinique Havre de Vie digitalise votre parcours de soins : choisissez votre médecin en ligne, prenez rendez-vous sans attente, accédez à votre dossier médical numérisé et bénéficiez bientôt de téléconsultations.',
      link: 'clinique-havre-de-vie.html',
      linkText: 'Visiter Clinique Havre de Vie →'
    },
    sante_vital: {
      name: 'STAR VITAL',
      summary: 'Accompagnement social, conseil familial et orientation.',
      details: 'STAR VITAL accompagne les familles dans leurs démarches sociales, offre un soutien psychologique et familial et oriente les usagers vers les solutions d\'entraide du groupe.',
      link: 'star-vital.html',
      linkText: 'Découvrir STAR VITAL →'
    },
    tourisme_jet: {
      name: 'STAR JET',
      summary: 'Aviation privée, location de jets sur mesure et conciergerie VIP.',
      details: 'Basé à Pointe-Noire et Brazzaville, STAR JET vous permet d\'affréter un jet privé pour vos voyages d\'affaires ou privés en Afrique, avec discrétion, flexibilité horaire et conciergerie VIP.',
      link: 'star-jet.html',
      linkText: 'Découvrir STAR JET →'
    },
    tourisme_beachvillage: {
      name: 'STAR Beach Village',
      summary: 'Complexe touristique d\'exception en bord de mer à Pointe-Noire.',
      details: 'Vivez un séjour inoubliable dans nos Tiny Houses écologiques face à l\'océan Atlantique à Pointe-Noire, avec accès spa, plage privée, restaurant gastronomique et activités de détente.',
      link: 'star-beach-village.html',
      linkText: 'Découvrir STAR Beach Village →'
    },
    tourisme_wedding: {
      name: 'STAR Beauty Wedding',
      summary: 'Location de robes de mariée, décoration et organisation de mariages.',
      details: 'STAR Beauty Wedding vous propose des robes de créateurs en location, la scénographie de mariages et une coordination clé en main pour un événement parfait.',
      link: 'star-beauty-wedding.html',
      linkText: 'Découvrir STAR Beauty Wedding →'
    },
    tourisme_casa: {
      name: 'STAR CASA',
      summary: 'Beauté, coiffure et soins de bien-être à domicile.',
      details: 'Nos coiffeurs, esthéticiennes et praticiennes de bien-être se déplacent directement à votre domicile sur rendez-vous pour des soins personnalisés de haute qualité.',
      link: 'star-casa.html',
      linkText: 'Découvrir STAR CASA →'
    },
    mobilite_trans: {
      name: 'STAR TRANS',
      summary: 'Transport urbain et interurbain, navettes d\'entreprises et transferts aéroport.',
      details: 'Nous gérons vos déplacements en toute sécurité : navettes professionnelles pour le personnel, bus interurbains confortables et transferts VIP entre aéroports et hôtels.',
      link: 'star-trans.html',
      linkText: 'Découvrir STAR TRANS →'
    },
    mobilite_express: {
      name: 'STAR EXPRESS',
      summary: 'Commande en ligne et livraison rapide de gaz domestique à domicile.',
      details: 'Ne tombez plus en panne de gaz ! Commandez votre bouteille en quelques clics, payez par Mobile Money et recevez une livraison sécurisée directement chez vous.',
      link: 'star-express.html',
      linkText: 'Découvrir STAR EXPRESS →'
    },
    mobilite_caros: {
      name: 'STARCAROS',
      summary: 'Vente de véhicules neufs et d\'occasion, importation et crédit automobile.',
      details: 'STARCAROS sélectionne pour vous des véhicules certifiés (berlines, SUV, utilitaires), gère l\'importation sur commande depuis l\'étranger et vous assiste pour le financement.',
      link: 'starcaros.html',
      linkText: 'Découvrir STARCAROS →'
    },
    numerique_carryo: {
      name: 'CARRY.O AFRIQUE',
      summary: 'Galerie d\'art contemporain africain et œuvres originales de Carry Otemba.',
      details: 'Une vitrine culturelle d\'exception mettant en valeur les peintures, toiles et expressions artistiques de Carry Otemba, avec possibilité d\'acquisition en ligne d\'œuvres signées et certifiées.',
      link: 'carry-o-afrique.html',
      linkText: 'Visiter la Galerie & Acquérir une œuvre →'
    },
    numerique_creat: {
      name: 'STAR CRÉAT',
      summary: 'Agence digitale : création de sites web, applications mobiles, design et marketing.',
      details: 'Nous concevons l\'identité numérique de votre entreprise : sites internet modernes, applications sur mesure, stratégie publicitaire digitale, référencement SEO et branding.',
      link: 'star-creat.html',
      linkText: 'Découvrir STAR CRÉAT →'
    },
    numerique_mbote: {
      name: 'STAR MBOTE',
      summary: 'Réseau digital de proximité et média au Congo.',
      details: 'STAR MBOTE relie les communautés urbaines et dynamise la communication digitale à travers le Congo en valorisant les initiatives locales.',
      link: 'star-mbote.html',
      linkText: 'Découvrir STAR MBOTE →'
    },
    services_cleaning: {
      name: 'STAR CLEANING',
      summary: 'Nettoyage résidentiel, professionnel, industriel et entretien d\'espaces verts.',
      details: 'Des prestations professionnelles de propreté pour vos bureaux, usines et immeubles résidentiels, incluant la désinfection de locaux et l\'entretien paysager de vos jardins.',
      link: 'star-cleaning.html',
      linkText: 'Découvrir STAR CLEANING →'
    },
    services_grimpeurs: {
      name: 'Les P\'tits Grimpeurs',
      summary: 'Crèche, garderie et maternelle pour l\'éveil et la créativité des enfants.',
      details: 'Un environnement sécurisé, chaleureux et stimulant où nos éducateurs diplômés accompagnent l\'épanouissement de vos tout-petits dès leur plus jeune âge.',
      link: 'les-ptits-grimpeurs.html',
      linkText: 'Découvrir Les P\'tits Grimpeurs →'
    },
    services_events: {
      name: 'STAR EVENTS',
      summary: 'Organisation d\'événements privés, professionnels et institutionnels clé en main.',
      details: 'Conférences, soirées de gala, séminaires d\'entreprise ou événements familiaux : STAR EVENTS pilote la logistique, la scénographie et la réception de A à Z.',
      link: 'star-events.html',
      linkText: 'Découvrir STAR EVENTS →'
    },
    services_energie: {
      name: 'STAR ÉNERGIE',
      summary: 'Solutions solaires durables, électrification et fourniture d\'équipements fiables.',
      details: 'Nous fournissons et installons des panneaux solaires de haute performance, des groupes électrogènes professionnels et des solutions d\'électrification rurale et urbaine.',
      link: 'star-energie.html',
      linkText: 'Découvrir STAR ÉNERGIE →'
    },
    numerique_alerte: {
      name: 'STAR ALERTE',
      summary: 'Signalement d\'urgence en République du Congo avec photo, voix et position.',
      details: 'STAR ALERTE — Signaler. Localiser. Secourir. Un projet national porté par STAR ENTREPRISE pour permettre à chacun de signaler une urgence en quelques secondes.',
      link: 'star-alerte.html',
      linkText: 'Découvrir STAR ALERTE →'
    },
    numerique_marketplace: {
      name: 'STAR Marketplace',
      summary: 'Achetez et vendez au Congo, en toute confiance.',
      details: 'Déposez vos produits et services, ou trouvez ce dont vous avez besoin, avec des commandes suivies et un paiement Mobile Money vérifié.',
      link: 'marketplace.html',
      linkText: 'Découvrir STAR Marketplace →'
    },
    numerique_kidimbou: {
      name: 'KIDIMBOU — Guichet Unique',
      summary: 'Guichet unique des démarches administratives de la République du Congo.',
      details: 'Préparez vos démarches administratives et suivez vos dossiers en un seul endroit. Un projet porté par STAR ENTREPRISE.',
      link: 'guichet-unique.html',
      linkText: 'Découvrir KIDIMBOU →'
    },
    numerique_somembres: {
      name: 'S.O — Gestion des Membres',
      summary: 'Application de gestion des membres et adhésions, par STAR CRÉAT.',
      details: 'Fiches d\'adhésion, recherche, filtre par année, export Excel. Une application STAR CRÉAT, filiale de STAR ENTREPRISE.',
      link: 'so-membres.html',
      linkText: 'Découvrir S.O Membres →'
    },
    evenementiel_pilipili: {
      name: 'Pili-Pili Events',
      summary: 'Votre partenaire événementiel de prestige à Brazzaville.',
      details: 'Mariages coutumiers, mariages traditionnels et décoration d\'exception. Du rêve à la réalité.',
      link: 'pilipili-events.html',
      linkText: 'Découvrir Pili-Pili Events →'
    },
    sante_drepanocytose: {
      name: 'La Maison de la Drépanocytose',
      summary: 'Espoir, dépistage & accompagnement — Pointe-Noire.',
      details: 'Dépistage, accompagnement des familles et sensibilisation à la drépanocytose en République du Congo.',
      link: 'maison-drepanocytose.html',
      linkText: 'Découvrir La Maison de la Drépanocytose →'
    }
  };

  /* ==========================================================================
     2bis. INDEX LITTÉRAL DU SITE — SARAH connaît CHAQUE PAGE réelle
     (généré automatiquement depuis le contenu des pages ; zéro invention)
     ========================================================================== */
  const SARAH_SITE_DOCS = [{"url":"blog.html","titre":"Blog STAR ENTREPRISE — Actualités de l'entreprise au Congo","resume":"Actualités, conseils, promotions et événements de STAR ENTREPRISE et de ses filiales au Congo : santé, épargne, immobilier, tourisme, mobilité, énergie, culture.","sections":[{"t":"STAR BEACH VILLAGE dévoile ses premières Tiny Houses à Pointe-Noire","d":"Le projet emblématique du groupe entre dans une nouvelle phase : les premières unités du complexe touristique de la zone Brasserie de la Mer sont désormais visibles. Un jalon important pour le tourisme et l'immobilier de prestige au Congo."},{"t":"Ne manquez aucune actualité du groupe","d":"Recevez les nouveautés, conseils et promotions de nos 20 filiales directement par email, SMS ou WhatsApp."},{"t":"Perspectives Économiques, Immobilières et Stratégie de Patrimoine au Congo 2026-2030","d":"Les utilisateurs anonymes doivent enregistrer leurs vrais identifiants dans l'espace Mon Compte afin de débloquer cet article exclusif et nos analyses financières détaillées."},{"t":"Assistance Officielle STAR ENTREPRISE","d":"Notre centre de support téléphonique et WhatsApp est à votre disposition 24h/24 · 7j/7 pour vous accompagner sur nos 20+ filiales."}],"chiffres":["5 000 FCFA","25 000 FCFA"]},{"url":"carrieres.html","titre":"Carrières — Rejoignez STAR ENTREPRISE au Congo","resume":"Rejoignez STAR ENTREPRISE, entreprise multiservices de plus de 20 filiales au Congo : santé, immobilier, tourisme, énergie, numérique. Candidature en ligne.","sections":[{"t":"Une culture d'excellence et d'engagement","d":"Les valeurs qui guident chaque filiale du groupe, et que nous cherchons chez chaque nouveau talent."},{"t":"Des opportunités dans plus de 20 filiales","d":"Quel que soit votre métier, il y a probablement une place pour vous dans l'écosystème STAR ENTREPRISE."},{"t":"Envie de faire partie de l'aventure ?","d":"Rejoignez un groupe qui investit dans les talents congolais et africains, aujourd'hui et pour demain."}],"chiffres":[]},{"url":"carry-o-afrique.html","titre":"CARRY.O AFRIQUE — Galerie d'art de STAR ENTREPRISE au Congo","resume":"","sections":[{"t":"Œuvres disponibles","d":"Prix indicatifs en FCFA et en dollars US. Cliquez sur une œuvre pour l'agrandir."},{"t":"Une œuvre vous a séduit ?","d":"Contactez-nous pour toute question sur une toile, sa disponibilité ou une commande sur-mesure."}],"chiffres":[]},{"url":"carryo-oeuvre-achat.html","titre":"CARRY.O AFRIQUE — Achat d'œuvres d'art originales au Congo","resume":"Achat officiel en ligne d'œuvres d'art originales de Carry Otemba (galerie CARRY.O AFRIQUE, Congo) : catalogue, prix en FCFA, paiement MTN Money sécurisé.","sections":[{"t":"Effectuer l'Achat en Ligne","d":"Remplissez ce formulaire pour réserver et acquérir immédiatement cette œuvre originale en direct avec la galerie CARRY.O AFRIQUE."},{"t":"Message Envoyé !","d":"Félicitations ! 🎉 Votre message et votre demande concernant l'œuvre originale « Regards croisés » au prix de 150 000 FCFA ont bien été transmis à l'administration. Un conseiller du curateur CARRY.O AFRIQUE va vous joindre par téléphone et WhatsApp dans les 15 "}],"chiffres":["150 000 FCFA","12 550 FCFA","10 500 FCFA"]},{"url":"clinique-havre-de-vie.html","titre":"Clinique Havre de Vie — Santé à Pointe-Noire et dans tout le Congo","resume":"Clinique à Pointe-Noire, au service de tout le Congo : pédiatrie, kinésithérapie, néonatologie, laboratoire, gynécologie, hospitalisation. Rendez-vous en ligne.","sections":[{"t":"Une offre de soins complète","d":"Consultations, thérapies et suivi médical, pensés pour les enfants et leur famille."},{"t":"Deux formules d'accueil","d":"Un hébergement adapté à chaque besoin, avec un suivi attentif au quotidien."},{"t":"Une question sur nos soins ?","d":"Contactez la Clinique Havre de Vie, ou créez votre compte pour suivre votre dossier."}],"chiffres":["tarifs hospitalisation */","10 000 FCFA"]},{"url":"index.html","titre":"STAR ENTREPRISE — Une seule entreprise, toutes les solutions au Congo","resume":"Entreprise multiservices au Congo : santé, épargne, immobilier, tourisme, transport, énergie et art. Plus de 20 activités, de Pointe-Noire à Brazzaville.","sections":[{"t":"Carry Otemba","d":"Fondateur & Président Directeur Général de STAR ENTREPRISE, Carry Otemba a bâti une entreprise multiservices avec l'ambition de centraliser des services essentiels — santé, épargne, immobilier, mobilité — au sein d'une seule plateforme numérique moderne."},{"t":"Nos Filiales","d":"Plus de 20 sociétés réunies par pôle d'activité, chacune avec son identité propre."},{"t":"Plus qu'un voyage. Une signature.","d":"Location de jets privés et séjours d'exception à STAR BEACH VILLAGE, Pointe-Noire. Confidentialité, excellence et sécurité à chaque instant."},{"t":"Nos Partenaires","d":"Des partenaires de référence pour l'assurance santé et le paiement bancaire."},{"t":"Témoignages clients","d":"Ce que vivent chaque jour les familles et professionnels accompagnés par STAR ENTREPRISE."}],"chiffres":[]},{"url":"les-ptits-grimpeurs.html","titre":"Les P'tits Grimpeurs — Crèche et garderie à Pointe-Noire, Congo","resume":"Les P'tits Grimpeurs : garderie, crèche et maternelle à Pointe-Noire. Éveil, créativité et accompagnement parental, au sein de STAR ENTREPRISE.","sections":[{"t":"Un accompagnement pour chaque âge","d":"De la garderie à la maternelle, un cadre pensé pour l'éveil et l'épanouissement de chaque enfant."},{"t":"Le rythme de nos petits grimpeurs","d":"Un accueil rassurant, en douceur, pour bien commencer la journée."},{"t":"La confiance des parents, l'exigence d'un groupe","d":"Un personnel formé, attentif à chaque enfant."},{"t":"Envie de rejoindre Les P'tits Grimpeurs ?","d":"Contactez notre équipe pour une visite, ou créez votre compte pour suivre votre inscription en ligne."}],"chiffres":[]},{"url":"liboke.html","titre":"LIBOKE Épargne + Santé — STAR ENTREPRISE au Congo","resume":"LIBOKE : épargne programmée, épargne libre, épargne santé et familiale, accompagnement social des ménages au Congo. Une filiale de STAR ENTREPRISE.","sections":[{"t":"Une conviction : l'épargne comme socle de dignité","d":"\"LIBOKE est né d'une conviction simple : chaque famille congolaise mérite les moyens d'épargner, de se soigner et d'être accompagnée dans les moments difficiles, sans que cela reste un privilège.\""},{"t":"Trois façons d'épargner, une même exigence","d":"Des formules adaptées à chaque projet, à chaque rythme de vie."},{"t":"Quatre étapes, en toute simplicité","d":"Créez votre compte STAR ENTREPRISE, gratuitement et en quelques minutes."},{"t":"Solidarité & entraide","d":"Chaque formule LIBOKE est pensée pour renforcer l'autonomie financière des familles congolaises, sans jamais faire de l'épargne un privilège."},{"t":"Soutenez le secteur social avec STAR MBOTÉ","d":"Au-delà de l'épargne, LIBOKE porte une mission solidaire. Votre don, même modeste, vient renforcer l'accompagnement social des familles les plus fragiles, partout au Congo."}],"chiffres":["1 000 FCFA","2 500 FCFA","5 000 FCFA"]},{"url":"mon-compte.html","titre":"Mon Compte — STAR ENTREPRISE","resume":"Connectez-vous ou créez votre compte STAR ENTREPRISE : un seul identifiant pour accéder à toutes nos filiales au Congo, en toute sécurité.","sections":[{"t":"Bon retour parmi nous","d":"Connectez-vous pour accéder à votre espace STAR ENTREPRISE."},{"t":"Créer votre compte","d":"Un seul compte pour accéder à toutes les filiales du groupe."},{"t":"Un tableau de bord pensé pour vous","d":"Aperçu de votre futur espace personnel : services, paiements, rendez-vous, documents et fidélité, réunis au même endroit."},{"t":"Assistance","d":"Notre centre d'assistance est disponible 24h/24 et 7j/7 pour répondre à toutes vos questions, sur l'ensemble des filiales du groupe."},{"t":"Connexion Administrateur & Propriétaire Confirmée","d":"Bienvenue Monsieur le PDG (Carry Otemba). Vos identifiants d'administration ont été vérifiés avec succès. Vous avez accès au lien caché de direction pour gérer l'écosystème STAR OS."},{"t":"Bienvenue dans votre Espace Membre","d":"Connecté en tant que ${account.name || 'Membre STAR'} (${account.email}). Vos identifiants vérifiés vous ouvrent l'accès aux avantages de fidélité et aux articles exclusifs réservés aux membres inscrits."}],"chiffres":["142 500 FCFA","25 000 FCFA","18 000 FCFA","99 500 FCFA"]},{"url":"star-beach-village.html","titre":"STAR BEACH VILLAGE — La Riviera congolaise, à Pointe-Noire","resume":"Complexe touristique et immobilier de prestige à Pointe-Noire, Congo : Tiny Houses, Villas Executive et Signature, Résidence Présidentielle.","sections":[{"t":"Une vision pour Pointe-Noire, un héritage pour le Congo","d":"\"STAR BEACH VILLAGE n'est pas qu'un projet immobilier. C'est notre façon de dire que Pointe-Noire mérite un tourisme moderne, une attractivité économique nouvelle et des emplois durables pour sa jeunesse.\""},{"t":"Une expérience complète, au bord de l'eau","d":"Des espaces pensés pour la détente, le bien-être et la convivialité."},{"t":"Trois signatures, une même exigence","d":"Des résidences pensées pour l'investissement, le séjour ou la réception d'hôtes de marque."},{"t":"Arrivez en toute discrétion","d":"Combinez votre séjour à STAR BEACH VILLAGE avec un vol privé STAR JET, pour une arrivée sur mesure à Pointe-Noire."},{"t":"Un impact concret pour le Congo","d":"Création d'emplois locaux, valorisation des savoir-faire congolais et renforcement de l'attractivité économique du territoire."},{"t":"Construisons ensemble la Riviera de Pointe-Noire","d":"Investisseurs, partenaires institutionnels ou futurs résidents — parlons de votre projet."}],"chiffres":[]},{"url":"star-beauty-wedding.html","titre":"STAR BEAUTY WEDDING — Robes de mariée et décoration au Congo","resume":"STAR BEAUTY WEDDING : robes de mariée, accessoires et décoration événementielle à Pointe-Noire, Brazzaville et dans tout le Congo.","sections":[{"t":"L'exigence STAR ENTREPRISE, appliquée à chaque détail","d":"Chaque mariage est unique ; nous construisons avec vous, pas à votre place."},{"t":"Des services pensés pour votre quotidien","d":"Une sélection de robes et retouches sur-mesure pour un ajustement parfait."},{"t":"Galerie d'Inspiration — Robes & Scénographie","d":"Découvrez notre sélection de robes de mariée d'exception, de scénographies événementielles et de coordination VIP (séries 01, 0006, 0007 et collections prestige)."},{"t":"Commençons à imaginer votre grand jour","d":"Prenez rendez-vous avec notre équipe pour un premier échange, sans engagement."}],"chiffres":[]},{"url":"star-casa.html","titre":"STAR CASA — Beauté et bien-être à domicile au Congo","resume":"STAR CASA : beauté, coiffure et bien-être à domicile à Pointe-Noire, Brazzaville et dans tout le Congo. Le soin de vous, sans quitter votre maison.","sections":[{"t":"L'exigence STAR ENTREPRISE, appliquée à chaque détail","d":"Nos professionnels se déplacent chez vous, à l'heure qui vous convient."},{"t":"Des services pensés pour votre quotidien","d":"Coupe, coiffage et soins capillaires, pour toute la famille."},{"t":"Galerie d'Inspiration — Coiffure & Beauté à Domicile","d":"Découvrez en vidéo notre présentation coiffure pour cheveux, ainsi que notre sélection de soins esthétiques, maquillage et spa à domicile au Congo."},{"t":"Offrez-vous un moment de soin","d":"Réservez votre prestation STAR CASA et laissez-nous venir à vous."}],"chiffres":[]},{"url":"star-cleaning.html","titre":"STAR CLEANING — Nettoyage à Pointe-Noire et dans tout le Congo","resume":"STAR CLEANING : nettoyage résidentiel, bureaux et industriel, désinfection et entretien d'immeubles à Pointe-Noire et dans tout le Congo.","sections":[{"t":"L'exigence STAR ENTREPRISE, appliquée à chaque détail","d":"Des agents formés aux techniques et produits adaptés à chaque surface."},{"t":"Des services pensés pour votre quotidien","d":"Entretien régulier ou ponctuel de votre domicile."},{"t":"Confiez-nous l'entretien de vos espaces","d":"Demandez un devis adapté à la taille et à la nature de vos locaux."}],"chiffres":[]},{"url":"star-creat.html","titre":"STAR CRÉAT — Agence créative de STAR ENTREPRISE au Congo","resume":"STAR CRÉAT : l'agence de création de STAR ENTREPRISE. Identité de marque, marketing digital, sites web et applications — Pointe-Noire, Brazzaville et au-delà.","sections":[{"t":"La même exigence, quel que soit le projet","d":"Chaque marque mérite une identité qui lui ressemble vraiment."},{"t":"Trois expertises, un seul interlocuteur","d":"Logo, charte graphique, packaging — une image cohérente sur tous les supports."},{"t":"Quelques projets qui illustrent notre diversité","d":"Des marques imaginées et habillées de A à Z par STAR CRÉAT."},{"t":"PIOUPIOU","d":"Une mascotte attachante et un logo plein de vie, pour une marque de Chips qui fait sourire les enfants et leurs parents. Toute la gamme, prête à conquérir les rayons."},{"t":"Lapin Bio","d":"Le même univers ludique, décliné pour une gamme de fruits secs — cohérence de marque sur toute la famille de produits."},{"t":"Moments de vie","d":"Parce qu'un souvenir de famille mérite le même soin qu'une grande marque — chaque création reste unique."}],"chiffres":[]},{"url":"star-deco-baby.html","titre":"STAR DÉCO BABY — Décoration de chambres d'enfants au Congo","resume":"STAR DÉCO BABY : décoration et aménagement d'espaces pour enfants, pensés pour l'éveil et la sécurité. Pointe-Noire, Brazzaville et tout le Congo.","sections":[{"t":"L'exigence STAR ENTREPRISE, appliquée à chaque détail","d":"Matériaux et agencements pensés pour la sécurité des tout-petits."},{"t":"Des services pensés pour votre quotidien","d":"Conception complète, du mobilier à la décoration murale."},{"t":"Galerie d'Inspiration — Nos Aménagements","d":"Découvrez nos réalisations et conceptions d'espaces sécurisés, ludiques et évolutifs pour bébés et enfants (séries 0001, 0002, 0003 et crèches d'éveil)."},{"t":"Imaginons ensemble son nouvel espace","d":"Contactez notre équipe pour un projet d'aménagement pensé pour votre enfant."}],"chiffres":[]},{"url":"star-energie.html","titre":"STAR ÉNERGIE — Kits solaires à Pointe-Noire et dans tout le Congo","resume":"STAR ÉNERGIE : kits solaires résidentiels, panneaux photovoltaïques et audit énergétique à Pointe-Noire et dans tout le Congo. Le pôle énergie de STAR ENTREPRISE.","sections":[{"t":"Trois façons de passer au solaire","d":"Des kits résidentiels à l'audit énergétique, STAR ÉNERGIE accompagne votre transition solaire."},{"t":"De l'audit à la mise en service","d":"Analyse de votre consommation et de vos besoins réels."},{"t":"Une centrale solaire pour accompagner Pointe-Noire","d":"Au-delà du résidentiel, STAR ÉNERGIE envisage un projet de centrale solaire à plus grande échelle — une ambition à l'étude, au service du développement énergétique du Congo."},{"t":"Prêt à passer au solaire ?","d":"Demandez un audit énergétique, ou créez votre compte pour suivre votre projet."}],"chiffres":[]},{"url":"star-events.html","titre":"STAR EVENTS — Organisation d'événements au Congo","resume":"STAR EVENTS : organisation d'événements privés, professionnels, culturels et institutionnels à Pointe-Noire, Brazzaville et dans tout le Congo.","sections":[{"t":"L'exigence STAR ENTREPRISE, appliquée à chaque détail","d":"Un plan détaillé, des délais tenus, une équipe coordonnée."},{"t":"Des services pensés pour votre quotidien","d":"Anniversaires, réceptions et célébrations familiales."},{"t":"Parlons de votre prochain événement","d":"Décrivez-nous votre projet : nous vous proposons une organisation à la hauteur de vos attentes."}],"chiffres":[]},{"url":"star-express.html","titre":"STAR EXPRESS — Gaz domestique à Pointe-Noire et tout le Congo","resume":"STAR EXPRESS : livraison rapide et sécurisée de gaz domestique à Pointe-Noire et dans tout le Congo. Commande en ligne, paiement mobile, livraison à domicile.","sections":[{"t":"L'exigence STAR ENTREPRISE, appliquée à chaque détail","d":"Commande traitée et livrée le jour même dans la plupart des quartiers."},{"t":"Des services pensés pour votre quotidien","d":"Toutes les tailles courantes, livrées avec le détendeur si besoin."},{"t":"Un parcours simple, du premier clic à la réalisation","d":"Sur l'application ou par téléphone, en quelques secondes."}],"chiffres":[]},{"url":"star-galerie-meubles-residentiel.html","titre":"STAR GALERIE MEUBLES — Mobilier résidentiel au Congo","resume":"Catalogue officiel STAR GALERIE MEUBLES : mobilier résidentiel — salon, chambre, salle à manger et extérieur. Pointe-Noire, Brazzaville et tout le Congo.","sections":[{"t":"Galerie du Mobilier Résidentiel — Catalogues & Collections","d":"Découvrez notre brochure officielle ainsi que 2 propositions similaires sélectionnées par nos concepteurs d'intérieur pour votre salon, suite parentale et réception."},{"t":"Brochure Officielle — Mobilier Résidentiel","d":"Le catalogue complet de nos lignes résidentielles : fauteuils velours ocre, canapés cuir contemporains, salles à manger de prestige et salons lounge pour terrasses en bord de mer."},{"t":"Collection Sérénité — Suite Parentale & Terrasse","d":"Proposition d'aménagement résidentiel pour suites et chambres de maître : lits King Size en bois massif, chevets assortis et ouverture sur terrasse tropicale."}],"chiffres":[]},{"url":"star-galerie-meubles.html","titre":"STAR GALERIE MEUBLES — Meubles et décoration au Congo","resume":"STAR GALERIE MEUBLES : mobilier résidentiel et professionnel, décoration intérieure à Pointe-Noire, Brazzaville et dans tout le Congo.","sections":[{"t":"L'exigence STAR ENTREPRISE, appliquée à chaque détail","d":"Des pièces choisies pour leur qualité et leur durabilité."},{"t":"Des services pensés pour votre quotidien","d":"Salon, chambre, salle à manger : des pièces pour chaque espace de vie."},{"t":"Composons ensemble votre intérieur","d":"Prenez rendez-vous en showroom ou demandez un accompagnement à domicile."}],"chiffres":[]},{"url":"star-immo.html","titre":"STAR IMMO — Immobilier, du plan à la clé, au Congo","resume":"STAR IMMO : vente, location, gestion locative et conseil en investissement immobilier à Pointe-Noire, Brazzaville et dans tout le Congo.","sections":[{"t":"Trois métiers, un même accompagnement","d":"De la mise en vente à la gestion au quotidien, STAR IMMO structure chaque étape de votre projet immobilier."},{"t":"Le type de biens que nous accompagnons","d":"Villas, appartements, terrains, locaux commerciaux — un conseiller STAR IMMO vous présente en direct les opportunités disponibles à Pointe-Noire et ses environs."},{"t":"Votre parcours avec STAR IMMO","d":"Un accompagnement dédié, du premier échange jusqu'à la remise des clés."},{"t":"Un bien pour chaque projet","d":"Les visuels ci-dessous illustrent chaque catégorie en attendant la mise en ligne de nos biens réels — nos conseillers vous présentent en direct les opportunités disponibles."},{"t":"Appartements","d":"Studios et appartements en résidence, adaptés aux particuliers comme aux professionnels de passage."},{"t":"Locaux commerciaux","d":"Boutiques, bureaux et espaces d'activité, en location ou en vente, en zones passantes."},{"t":"Aujourd'hui à Pointe-Noire, demain dans tout le Congo","d":"Parlons-en avec un conseiller STAR IMMO, ou créez votre compte pour suivre vos démarches en ligne."}],"chiffres":[]},{"url":"star-jet.html","titre":"STAR JET — Location de jets privés à Pointe-Noire, Congo","resume":"STAR JET : location de jets privés, vol à la carte et conciergerie haut de gamme depuis Pointe-Noire, Congo. Une filiale de STAR ENTREPRISE.","sections":[{"t":"Une vision, une exigence : l'excellence à chaque envol","d":"\"Chez STAR JET, nous ne vendons pas des heures de vol : nous offrons une signature — celle d'un service pensé dans le moindre détail pour celles et ceux qui n'ont pas de temps à perdre. Notre ambition est de faire de Pointe-Noire une porte d'entrée aérienne d'"},{"t":"Un vol pour chaque exigence","d":"De l'affrètement ponctuel à l'accompagnement des institutions, STAR JET s'adapte à chaque type de déplacement."},{"t":"Trois catégories, un même niveau d'exigence","d":"Une sélection de jets disponibles à l'affrètement, adaptée à la distance, au nombre de passagers et au niveau de confort recherché."},{"t":"Prolongez votre voyage à Pointe-Noire","d":"Villas premium, Tiny Houses et résidences d'exception au bord de l'océan : combinez votre vol STAR JET avec un séjour signé STAR BEACH VILLAGE."},{"t":"Un impact pour Pointe-Noire","d":"En facilitant l'accès aérien haut de gamme à la ville, STAR JET participe à son attractivité économique et touristique, en synergie avec STAR BEACH VILLAGE et STAR IMMO."},{"t":"Prêt à décoller ?","d":"Notre équipe conçoit votre vol sur-mesure en moins de 24h."}],"chiffres":[]},{"url":"star-mbote.html","titre":"STAR MBOTÉ — Programme de fidélité STAR ENTREPRISE au Congo","resume":"STAR MBOTÉ : le programme de fidélité qui relie toutes les filiales de STAR ENTREPRISE au Congo — points, avantages et réductions.","sections":[{"t":"L'exigence STAR ENTREPRISE, appliquée à chaque détail","d":"Chaque achat ou prestation dans le groupe vous rapporte des points."},{"t":"Des services pensés pour votre quotidien","d":"Avantages sur les services immobiliers et la gestion de patrimoine."},{"t":"Un parcours simple, du premier clic à la réalisation","d":"Créez votre compte STAR ENTREPRISE et rejoignez STAR MBOTÉ gratuitement."}],"chiffres":[]},{"url":"star-pamep.html","titre":"STAR P.A.M.E.P — Gestion et sécurisation de patrimoine au Congo","resume":"Gestion, entretien et sécurisation de patrimoines immobiliers à Pointe-Noire, Brazzaville et dans tout le Congo : maisons, espaces publics et privés.","sections":[{"t":"Trois piliers, un même engagement","d":"Propriété, Administration, Maisons, Espaces Publics & Privés — tout l'esprit de STAR P.A.M.E.P tient dans son nom."},{"t":"Notre méthode, étape par étape","d":"Un accompagnement structuré, du premier diagnostic au suivi dans la durée."},{"t":"Un patrimoine préservé, une tranquillité durable","d":"Que vous soyez propriétaire d'une maison, gestionnaire d'un immeuble ou responsable d'un espace public, STAR P.A.M.E.P prend en charge l'administration, l'entretien technique et la sécurisation de vos biens — avec la rigueur et les équipes du groupe STAR ENTRE"},{"t":"La rigueur d'un groupe, la proximité d'une équipe locale","d":"Les synergies d'un groupe multiservices : immobilier, sécurité, entretien, numérique."},{"t":"Aujourd'hui à Pointe-Noire, demain dans tout le Congo","d":"Parlons-en avec un conseiller STAR P.A.M.E.P, pour un diagnostic adapté à votre bien."}],"chiffres":[]},{"url":"star-trans.html","titre":"STAR TRANS — Transport et navettes à Pointe-Noire, Congo","resume":"STAR TRANS : transport urbain et interurbain, navettes, location avec chauffeur et transferts aéroport à Pointe-Noire et dans tout le Congo.","sections":[{"t":"L'exigence STAR ENTREPRISE, appliquée à chaque détail","d":"Sélectionnés, formés et courtois, pour un trajet sans stress."},{"t":"Des services pensés pour votre quotidien","d":"Déplacements du quotidien dans Pointe-Noire, à la course ou à l'abonnement."},{"t":"Réservez votre prochain trajet","d":"STAR TRANS vous accompagne partout où vous devez être, à l'heure et en toute confiance."}],"chiffres":[]},{"url":"star-vital.html","titre":"STAR VITAL — Accompagnement social à Pointe-Noire, Congo","resume":"STAR VITAL : accompagnement social, conseil familial et orientation à Pointe-Noire et dans tout le Congo. Le pôle santé & social de STAR ENTREPRISE.","sections":[{"t":"Trois piliers d'accompagnement","d":"Un soutien pensé pour les familles et les bénéficiaires du groupe STAR ENTREPRISE."},{"t":"Un suivi pensé dans la durée","d":"Un premier échange pour comprendre la situation et les besoins."},{"t":"La bienveillance d'une équipe, la force d'un groupe","d":"Bienveillante et disponible pour chaque famille accompagnée."},{"t":"Besoin d'un accompagnement ?","d":"Parlons-en en toute confidentialité, ou créez votre compte pour suivre votre accompagnement."}],"chiffres":[]},{"url":"starcaros.html","titre":"STARCAROS — Véhicules neufs et d'occasion au Congo","resume":"STARCAROS : vente de véhicules neufs et d'occasion, importation et financement auto à Pointe-Noire, Brazzaville et dans tout le Congo.","sections":[{"t":"L'exigence STAR ENTREPRISE, appliquée à chaque détail","d":"Chaque véhicule est contrôlé avant mise en vente."},{"t":"Des services pensés pour votre quotidien","d":"Les principales marques disponibles, avec garantie constructeur."},{"t":"Trouvons votre prochain véhicule","d":"Contactez notre équipe pour une sélection adaptée à votre besoin et votre budget."}],"chiffres":[]}];

  function sarahNorm(s) {
    return String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w\s]/g, ' ').replace(/\s+/g, ' ').trim();
  }
  (function sarahIndexDocs() {
    for (const d of SARAH_SITE_DOCS) {
      d._hay = sarahNorm(d.titre + ' ' + d.resume + ' ' + d.sections.map(function (s) { return s.t + ' ' + s.d; }).join(' ') + ' ' + d.chiffres.join(' '));
      d._key = sarahNorm(d.url.replace(/\.html$/, '').replace(/[-_]/g, ' '));
      d._secs = d.sections.map(function (s) { return { t: s.t, d: s.d, n: sarahNorm(s.t) }; });
    }
  })();

  const SARAH_STOP = new Set(['les','des','une','dans','pour','avec','sans','chez','sur','est','sont','quoi','quelle','quelles','quel','cette','cete','votre','vos','notre','nos','avez','avoir','puis','peux','faire','fait','faire','please','what','where','about','how','much','many','merci','bonjour','salut','bonsoir','coucou']);

  function sarahSearchSite(qClean) {
    const rawWords = qClean.split(/\s+/).filter(function (w) { return w.length > 2 && !SARAH_STOP.has(w); });
    // Dédoublonne au singulier : « houses » vaut « house », « articles » vaut « article ».
    const seen = {}; const qWords = [];
    for (let w of rawWords) { if (w.length > 4 && w[w.length - 1] === 's') w = w.slice(0, -1);
      if (!seen[w]) { seen[w] = 1; qWords.push(w); } }
    if (qWords.length < 1) return null;
    let best = null, bestScore = 0, bestKeyHit = false, bestWordHits = 0, bestSecHit = false, second = null;
    for (const d of SARAH_SITE_DOCS) {
      let sc = 0, keyHit = false, wordHits = 0, secHit = false;
      if (d._key.length > 3 && qClean.includes(d._key)) { sc += 30; keyHit = true; }
      for (const w of qWords) {
        let occ = 0, from = 0;
        while (occ < 3 && d._hay.indexOf(w, from) !== -1) { occ++; from = d._hay.indexOf(w, from) + w.length; }
        if (occ) { wordHits++; sc += occ * 5; }
      }
      for (const s of d._secs) if (s.n.length > 6 && qClean.includes(s.n)) { sc += 12; secHit = true; }
      if (sc > bestScore) {
        if (best) second = { d: best, s: bestScore };
        best = d; bestScore = sc; bestKeyHit = keyHit; bestWordHits = wordHits; bestSecHit = secHit;
      } else if (sc > 0 && (!second || sc > second.s)) second = { d: d, s: sc };
    }
    // Exige une preuve solide : nom de page, titre de section, ou deux mots différents
    // rencontrés dans la page — un seul mot vague (ex. « temps ») ne déclenche RIEN.
    if (!best || bestScore < 10 || !(bestKeyHit || bestSecHit || bestWordHits >= 2)) return null;
    const titre = best.titre.split('—')[0].trim();
    let text = 'D\'après la page <b>' + titre + '</b> du site :';
    if (best.resume) text += '<br><br>' + best.resume;
    const hits = best._secs.filter(function (s) { return s.n.length > 6 && qWords.some(function (w) { return s.n.includes(w) || w.includes(s.n.slice(0, Math.max(4, w.length - 2))); }); });
    const chosen = (hits.length ? hits : best._secs).slice(0, 3);
    for (const s of chosen) text += '<br><br><b>' + s.t + '</b> — ' + s.d;
    if (best.chiffres.length) text += '<br><br>À retenir : <b>' + best.chiffres.slice(0, 3).join(' · ') + '</b>';
    if (second && second.s >= 16) {
      text += '<br><br>Le sujet est aussi détaillé sur la page <b>' + second.d.titre.split('—')[0].trim() + '</b> — demandez-la, je vous la résume.';
    }
    return { type: 'SITE_KNOWLEDGE', text: text, link: best.url,
             linkText: 'Ouvrir ' + (titre.length > 26 ? titre.slice(0, 24) + '…' : titre) + ' →' };
  }

  // API publique (tests & intégrations) — sans aucun effet sur le site.
  window.SarahKnowledge = { answer: null, searchSite: sarahSearchSite, docs: SARAH_SITE_DOCS };

  /* ==========================================================================
     3. MOTEUR CONVERSATIONNEL DE TYPE CHATGPT (Analyse sémantique sans digression)
     ========================================================================== */
  function parseUserIntent(query) {
    const qClean = query
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^\w\s]/g, " ")
      .trim();

    // 1. SALUTATIONS & POLITESSES — reconnues UNIQUEMENT quand le message
    //    est court et ne contient aucune vraie question (avant, « bonjour,
    //    quels sont vos horaires ? » déclenchait la salutation → Sarah
    //    semblait « ne connaître que les bonjours »).
    const qTrim = qClean.trim();
    const isPureGreeting = /^(bonjour|salut|hello|bonsoir|coucou|hey|hi|mbote)(\s+(sarah|ca\s+va|mon\s+ami|les\s+amis))?[\s!.]*$/.test(qTrim);
    if (/^(merci|thanks|ok\b|d\s+acc|au\s+revoir|a\s+bientot|bonne\s+(journee|soiree)|c\s+est\s+note)[\s!.,]*$/.test(qTrim)) {
      return { type: 'COURTESY', text: 'Avec grand plaisir ! 🌟 <b>STAR ENTREPRISE</b> reste à votre écoute — une autre question sur nos services, nos tarifs ou vos démarches ? Je connais chaque page de ce site.', link: null, linkText: null };
    }
    if (isPureGreeting) {
      return {
        type: 'GREETING',
        text: `Bonjour ! 👋 Bienvenue chez <b>STAR ENTREPRISE</b>. Je suis Sarah, votre assistante de direction.<br><br>Comment puis-je vous aider aujourd'hui parmi nos <b>20+ filiales</b> au Congo (santé, immobilier, aviation, épargne, mobilier...) ou sur le parcours de notre fondateur Carry Otemba ?`,
        link: 'index.html#filiales',
        linkText: 'Découvrir nos filiales →'
      };
    }

    // 2. IDENTIFICATION DES 36 MODULES D'ENTREPRISE (Maîtrise littérale du site et de toute l'entreprise STAR ENTREPRISE)
    const entityScores = {
      fondateur_pdg: scoreKeywords(qClean, ['carry', 'otemba', 'fondateur', 'pdg', 'president', 'ombre a la lumiere', 'livre', 'auteur', 'peintre', 'artiste', 'patron']),
      compte_inscription: scoreKeywords(qClean, ['compte', 'mon compte', 'inscription', 'connexion', 'identifiant', 'creer un compte', 'register', 'login', 'mot de passe', 'client', 's inscrire']),
      paiement_moyens: scoreKeywords(qClean, ['paiement', 'payer', 'mobile money', 'airtel money', 'mtn money', 'mtn', 'airtel', 'virement', 'banque', 'especes', 'agence', 'cash']),
      localisation_adresses: scoreKeywords(qClean, ['adresse', 'ville', 'brazzaville', 'pointe noire', 'agence', 'siege', 'bureau', 'localisation', 'situe']),
      groupe_carrieres: scoreKeywords(qClean, ['carriere', 'emploi', 'recrutement', 'job', 'travail', 'postuler', 'stage', 'candidature', 'embauche', 'salaire', 'cv', 'rh']),
      groupe_contact: scoreKeywords(qClean, ['contact', 'telephone', 'contacter', 'aide', 'assistance', 'support', 'numero', 'horaire', 'appeler', 'joindre']),
      partenaires_assurances: scoreKeywords(qClean, ['partenaire', 'partenariat', 'assurance', 'banque', 'nsia', 'sunu', 'olea', 'ascoma', 'arc', 'uba', 'lcb']),
      sante_liboke: scoreKeywords(qClean, ['liboke', 'epargne sante', 'solidarite', 'cotisation', 'famille', 'tontine', 'menage', 'social', 'mutualite']),
      sante_clinique: scoreKeywords(qClean, ['clinique', 'havre de vie', 'medecin', 'docteur', 'consultation', 'rendez vous', 'hopital', 'soin', 'teleconsultation', 'dossier patient', 'pediatre']),
      sante_vital: scoreKeywords(qClean, ['star vital', 'vital', 'conseil familial', 'orientation sociale', 'accompagnement', 'urgence']),
      immo_starimmo: scoreKeywords(qClean, ['star immo', 'immo', 'immobilier', 'maison', 'appartement', 'terrain', 'louer', 'location', 'vendre', 'vente', 'bail', 'titre foncier', 'villa']),
      immo_pamep: scoreKeywords(qClean, ['pamep', 'patrimoine', 'entretien', 'securisation', 'syndic', 'gestion immobiliere', 'maintenance', 'batiment', 'nettoyage immeuble']),
      immo_meubles: scoreKeywords(qClean, ['meuble', 'galerie meubles', 'mobilier', 'canape', 'fauteuil', 'table', 'salon', 'decoration', 'interieur', 'bureau meuble', 'livraison meuble']),
      immo_decobaby: scoreKeywords(qClean, ['deco baby', 'baby', 'chambre bebe', 'berceau', 'mobilier enfant', 'creche', 'puericulture', 'securite bebe', 'eveil']),
      tourisme_jet: scoreKeywords(qClean, ['star jet', 'jet', 'avion', 'vol', 'aviation', 'charter', 'pointe noire vol', 'aeroport', 'pilote', 'conciergerie vol', 'vip vol']),
      tourisme_beachvillage: scoreKeywords(qClean, ['beach village', 'beach', 'village', 'tiny house', 'bord de mer', 'plage', 'complexe touristique', 'resort', 'vacances', 'spa mer', 'brasserie de la mer']),
      tourisme_wedding: scoreKeywords(qClean, ['wedding', 'mariage', 'robe de mariee', 'robe', 'scenographie', 'decoration mariage', 'cortege', 'evenement nuptial', 'soiree mariage']),
      tourisme_casa: scoreKeywords(qClean, ['star casa', 'casa', 'coiffure', 'beaute', 'soin visage', 'maquillage', 'manucure', 'domicile', 'esthetique', 'massage domicile']),
      meubles_residentiel: scoreKeywords(qClean, ['mobilier residentiel', 'residentiel', 'fauteuil velours', 'salon prestige', 'suite parentale']),
      mobilite_trans: scoreKeywords(qClean, ['star trans', 'trans', 'transport', 'navette', 'transfert', 'bus', 'trajet', 'deplacement', 'chauffeur']),
      mobilite_express: scoreKeywords(qClean, ['star express', 'express', 'livraison gaz', 'bouteille de gaz', 'colis', 'courrier', 'logistique', 'course', 'moto', 'dernier kilometre']),
      mobilite_caros: scoreKeywords(qClean, ['starcaros', 'caros', 'location voiture', 'vehicule', 'flotte automobile', 'louer voiture', '4x4', 'berline']),
      numerique_creat: scoreKeywords(qClean, ['star creat', 'creat', 'communication', 'marketing', 'publicite', 'logo', 'design', 'site web', 'creation graphique']),
      numerique_carryo: scoreKeywords(qClean, ['carry o afrique', 'carryo', 'afrique art', 'art', 'toile', 'tableau', 'peinture', 'galerie art', 'œuvre', 'regards croises', 'empreintes']),
      services_grimpeurs: scoreKeywords(qClean, ['les p tits grimpeurs', 'grimpeurs', 'jouet', 'enfant jeu', 'eveil enfant', 'atelier pedagogique', 'livre enfant', 'ludique']),
      services_cleaning: scoreKeywords(qClean, ['star cleaning', 'cleaning', 'nettoyage', 'menage bureau', 'desinfection', 'vitre', 'hygiene locaux', 'proprete']),
      services_events: scoreKeywords(qClean, ['star events', 'events', 'evenementiel', 'seminaire', 'gala', 'conference', 'congres', 'organisation reception']),
      services_energie: scoreKeywords(qClean, ['star energie', 'energie', 'solaire', 'panneau solaire', 'electricite', 'batterie', 'groupe electrogene', 'installation electrique']),
      numerique_mbote: scoreKeywords(qClean, ['mbote', 'star mbote', 'fidelite', 'point', 'recompense', 'carte fidelite', 'reduction groupe']),
      numerique_alerte: scoreKeywords(qClean, ['star alerte', 'alerte', 'urgence', 'signaler', 'secours', 'danger', 'localiser']),
      numerique_marketplace: scoreKeywords(qClean, ['marketplace', 'acheter', 'vendre', 'annonce', 'boutique en ligne', 'petites annonces']),
      numerique_kidimbou: scoreKeywords(qClean, ['kidimbou', 'guichet unique', 'demarche administrative', 'dossier administratif', 'papiers administratifs']),
      numerique_somembres: scoreKeywords(qClean, ['s o membres', 'gestion des membres', 'fiche d adhesion', 'adhesion', 'liste des membres']),
      evenementiel_pilipili: scoreKeywords(qClean, ['pili pili', 'pilipili', 'mariage coutumier', 'mariage traditionnel', 'dot']),
      sante_drepanocytose: scoreKeywords(qClean, ['drepanocytose', 'maison de la drepanocytose', 'depistage', 'anemie'])
    };

    let maxScore = 0;
    let matchedEntity = null;
    for (const [key, score] of Object.entries(entityScores)) {
      if (score > maxScore) {
        maxScore = score;
        matchedEntity = key;
      }
    }

    if (maxScore >= 6 && matchedEntity && CORPORATE_DB[matchedEntity]) {
      SarahMemory.lastTopic = matchedEntity;
      const data = CORPORATE_DB[matchedEntity];
      return {
        type: 'CORPORATE_INTENT',
        text: data.summary + '<br><br>' + data.details + '<br><br><i>Souhaitez-vous un devis ou avez-vous une autre question ?</i>',
        link: data.link,
        linkText: data.linkText
      };
    }

    // 2bis. LITTÉRATURE DU SITE : réponse factuelle tirée de la page elle-même.
    const siteHit = sarahSearchSite(qClean);
    if (siteHit) { SarahMemory.lastTopic = siteHit.link; return siteHit; }

    // 3. DÉFINITIONS DIRECTES ET PROPRES (Zéro orgueil, zéro répétition de la question, explication claire et naturelle)
    if (qClean.includes("entreprise") || qClean.includes("societe") || qClean.includes("firme") || qClean.includes("compagnie")) {
      return {
        type: 'DEFINITION_INTELLIGENTE',
        text: `Une entreprise est une organisation humaine et économique structurée qui rassemble des moyens financiers, techniques et humains pour produire des biens ou des services destinés à satisfaire les besoins de ses clients et créer de la valeur.<br><br>Au Congo, <b>STAR ENTREPRISE</b> incarne parfaitement cette vision : notre entreprise multiservices réunit plus de <b>20 filiales</b> et centralise des solutions essentielles (santé, immobilier, épargne, aviation privée, logistique...) autour d'un seul compte pour simplifier la vie des familles et des investisseurs. Avez-vous une question sur l'une de nos activités ?`,
        link: 'index.html#filiales',
        linkText: 'Découvrir nos filiales →'
      };
    }
    if (qClean.includes("immobilier") || qClean.includes("villa") || qClean.includes("loyer") || qClean.includes("foncier")) {
      return {
        type: 'DEFINITION_INTELLIGENTE',
        text: `L'immobilier regroupe l'ensemble des biens fonciers et résidentiels (terrains, maisons, immeubles, locaux commerciaux) ainsi que leur développement et leur gestion patrimoniale.<br><br>Au sein de <b>STAR ENTREPRISE</b>, notre filiale <b>STAR IMMO</b> sécurise chaque transaction immobilière en République du Congo (Brazzaville & Pointe-Noire), du conseil patrimonial à la gestion locative.`,
        link: 'star-immo.html',
        linkText: 'Découvrir STAR IMMO →'
      };
    }
    if (qClean.includes("epargne") || qClean.includes("liboke") || qClean.includes("finance") || qClean.includes("argent") || qClean.includes("banque")) {
      return {
        type: 'DEFINITION_INTELLIGENTE',
        text: `L'épargne représente la part du revenu qui n'est pas consommée immédiatement mais constituée en réserve sécurisée pour des projets futurs, des imprévus ou des investissements.<br><br>Avec notre programme <b>LIBOKE Épargne + Santé</b>, nous permettons à chaque famille congolaise d'épargner à son rythme et de bénéficier en prime d'une couverture santé solidaire.`,
        link: 'liboke.html',
        linkText: 'Découvrir LIBOKE Épargne →'
      };
    }
    if (qClean.includes("jet") || qClean.includes("aviation") || qClean.includes("vol") || qClean.includes("charter")) {
      return {
        type: 'DEFINITION_INTELLIGENTE',
        text: `L'aviation d'affaires (ou vol privé à la carte) permet des déplacements aériens sur-mesure, flexibles et confidentiels, parfaitement adaptés aux agendas des dirigeants et investisseurs.<br><br>Notre filiale <b>STAR JET</b> à Pointe-Noire propose la location de jets privés, des navettes VIP et une conciergerie haut de gamme dans toute l'Afrique centrale.`,
        link: 'star-jet.html',
        linkText: 'Découvrir STAR JET →'
      };
    }
    if (qClean.includes("solaire") || qClean.includes("energie") || qClean.includes("electricite") || qClean.includes("panneau")) {
      return {
        type: 'DEFINITION_INTELLIGENTE',
        text: `L'énergie solaire est une source renouvelable captée par des panneaux photovoltaïques et convertie en électricité propre et autonome.<br><br>Notre filiale <b>STAR ÉNERGIE</b> dimensionne et installe des kits solaires résidentiels et professionnels fiables pour garantir l'autonomie électrique de votre foyer ou bureau au Congo.`,
        link: 'star-energie.html',
        linkText: 'Découvrir STAR ÉNERGIE →'
      };
    }

    // 4. MOTEUR DE CONNAISSANCE UNIVERSELLE DIRECT & ÉLÉGANT (Zéro orgueil, zéro répétition de la question, réponse directe et cultivée)
    let directAnswer = "";
    if (/science|tech|physique|math|ia|intelligence|informatique|code|internet/i.test(qClean)) {
      directAnswer = "Les sciences et technologies jouent un rôle moteur dans la transformation des sociétés modernes. Les avancées en informatique et en intelligence artificielle permettent d'analyser des données complexes pour automatiser les processus et apporter des solutions concrètes aux défis quotidiens.";
    } else if (/economie|finance|marche|bourse|entreprise|gestion|commerce|business|strategie|capital|investissement/i.test(qClean)) {
      directAnswer = "L'économie et la stratégie financière reposent sur une allocation optimale des ressources, la maîtrise des cycles d'investissement et l'innovation constante dans les services pour créer de la valeur durable au profit des clients.";
    } else if (/histoire|geographie|congo|afrique|brazzaville|pointe noire|culture|art|livre|litterature|peinture/i.test(qClean)) {
      directAnswer = "L'histoire, la culture et l'identité artistique africaine portent une dynamique de résilience, de créativité et de patrimoine vivant qui inspire le développement et l'attractivité du bassin congolais.";
    } else {
      directAnswer = "Chaque sujet s'analyse avec rigueur en privilégiant la clarté, la précision des faits et la recherche de solutions adaptées aux besoins de chacun.";
    }

    return {
      type: 'UNIVERSAL_DEMIGOD_KNOWLEDGE',
      text: directAnswer +
            `<br><br>Au sein de <b>STAR ENTREPRISE</b>, nous appliquons cette même rigueur d'analyse et d'excellence à travers nos <b>20+ filiales</b> au Congo (santé, immobilier, aviation privée, épargne, mobilier...). Comment puis-je vous aider sur l'une de nos activités ?`,
      link: 'index.html#filiales',
      linkText: 'Découvrir nos filiales →'
    };
  }

  // Fonction utilitaire de scoring pondéré// Fonction utilitaire de scoring pondéré// Fonction utilitaire de scoring pondéré// Fonction utilitaire de scoring pondéré// Fonction utilitaire de scoring pondéré
  function scoreKeywords(queryClean, wordsArray) {
    let score = 0;
    const qWords = queryClean.split(/\s+/).filter(w => w.length > 2);

    for (const kw of wordsArray) {
      const kwClean = kw.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
      if (queryClean === kwClean) {
        score += 25;
      } else if (queryClean.includes(kwClean)) {
        score += 15;
      } else {
        const kwWords = kwClean.split(/\s+/);
        for (const qw of qWords) {
          if (kwWords.includes(qw)) {
            score += 4;
          } else {
            for (const kwWord of kwWords) {
              if (kwWord.length > 4 && qw.length > 4 && (kwWord.includes(qw) || qw.includes(kwWord))) {
                score += 2;
              }
            }
          }
        }
      }
    }
    return score;
  }

  window.SarahKnowledge.answer = parseUserIntent;

  /* ==========================================================================
     4. CONSTRUCTION DU DOM DE SARAH (Saisie 100% dégagée, suggestions intégrées)
     ========================================================================== */
  function buildSarahUI() {
    const container = document.createElement('div');
    container.id = 'sarah-widget-container';

    container.innerHTML = `
      <!-- Bulle de salutation (étendue pendant 3s puis se plie en cercle avec icône recherche) -->
      <div id="sarah-bubble" class="sarah-expanded" title="Cliquer pour rechercher ou discuter avec Sarah">
        <div class="sarah-bubble-text">
          <span>👋 Bonjour ! Je suis <b>Sarah</b>. Une question ?</span>
        </div>
        <div class="sarah-bubble-icon" aria-label="Rechercher / Discuter avec Sarah">
          <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
          </svg>
        </div>
      </div>

      <!-- Bouton rond flottant bas droite -->
      <button id="sarah-btn" aria-label="Ouvrir l'assistante Sarah" title="Discuter avec Sarah">
        <img src="images/sarah-thumb.jpg" alt="Sarah - Assistante STAR ENTREPRISE" onerror="this.src='images/sarah-avatar.jpg'">
      </button>

      <!-- Fenêtre Modale de Chat -->
      <div id="sarah-modal" role="dialog" aria-label="Discussion avec Sarah, Assistante STAR ENTREPRISE">
        <!-- Header compact (style ChatGPT/Gemini) : toute la place pour la discussion -->
        <div id="sarah-header">
          <img id="sarah-header-img" src="images/sarah-avatar.jpg" alt="Sarah">
          <div id="sarah-header-badge">
            <div class="sarah-name"><span class="sarah-star">★</span> Sarah</div>
            <div class="sarah-role"><span class="sarah-dot"></span> Assistante · STAR ENTREPRISE</div>
          </div>
          <button id="sarah-newchat-btn" aria-label="Nouvelle conversation" title="Nouvelle conversation">↺</button>
          <button id="sarah-close-btn" aria-label="Fermer la discussion">×</button>
        </div>

        <!-- Corps blanc du chat -->
        <div id="sarah-body">
          <!-- Zone de messages scrollable : les suggestions sont ici pour ne JAMAIS cacher la zone de saisie en bas -->
          <div id="sarah-messages">
            <!-- Message initial de Sarah (comme sur la capture) -->
            <div class="sarah-msg sarah-bot">
              <div class="sarah-msg-content">
                Bonjour ! 👋 Bienvenue chez <b>STAR ENTREPRISE</b>, je suis Sarah. Comment puis-je vous aider aujourd'hui ?
              </div>
            </div>

            <!-- Suggestion Chips / Boutons de questions rapides (Intégrés dans la zone scrollable) -->
            <div id="sarah-chips">
              <button class="sarah-chip" data-query="À propos">À propos</button>
              <button class="sarah-chip" data-query="Nos services">Nos services</button>
              <button class="sarah-chip" data-query="Projets phares">Projets phares</button>
              <button class="sarah-chip" data-query="Partenariat">Partenariat</button>
              <button class="sarah-chip" data-query="Nos 20+ filiales">Nos 20+ filiales</button>
              <button class="sarah-chip" data-query="Créer un compte">Créer un compte</button>
              <button class="sarah-chip" data-query="Le Fondateur">Le Fondateur</button>
            </div>
          </div>

          <!-- Barre de saisie en bas (Totalement dégagée, fixe et accessible) -->
          <form id="sarah-footer" onsubmit="return false;">
            <textarea id="sarah-input" rows="1" placeholder="Écrivez votre message…" autocomplete="off"></textarea>
            <button type="submit" id="sarah-send-btn" aria-label="Envoyer le message">
              <svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
            </button>
          </form>
        </div>
      </div>
    `;

    document.body.appendChild(container);
    initSarahEvents();
  }

  /* ==========================================================================
     5. APPARITION APRES 4s SUR TOUTES LES PAGES + PLIAGE APRES 3s VERS CERCLE RECHERCHE
     ========================================================================== */
  function scheduleSarahAppearance() {
    setTimeout(function () {
      const btn = document.getElementById('sarah-btn');
      const bubble = document.getElementById('sarah-bubble');
      const modal = document.getElementById('sarah-modal');

      if (btn) btn.classList.add('sarah-visible');
      if (bubble) {
        bubble.classList.add('sarah-visible');
        bubble.classList.add('sarah-expanded');
        bubble.classList.remove('sarah-folded');
      }

      // 3 secondes après l'apparition (t = 7000ms), pliage vers le cercle avec icône recherche
      setTimeout(function () {
        if (bubble && !modal.classList.contains('sarah-open')) {
          bubble.classList.remove('sarah-expanded');
          bubble.classList.add('sarah-folded');
        }
      }, 3000);

    }, 4000);
  }

  /* ==========================================================================
     6. GESTION DES EVENEMENTS & INTERACTIVITE CONVERSATIONNELLE
     ========================================================================== */
  function initSarahEvents() {
    const btn = document.getElementById('sarah-btn');
    const bubble = document.getElementById('sarah-bubble');
    const modal = document.getElementById('sarah-modal');
    const closeBtn = document.getElementById('sarah-close-btn');
    const form = document.getElementById('sarah-footer');
    const input = document.getElementById('sarah-input');
    const chips = document.querySelectorAll('.sarah-chip');
    const messages = document.getElementById('sarah-messages');

    function openModal() {
      if (modal) modal.classList.add('sarah-open');
      if (bubble) {
        bubble.classList.remove('sarah-expanded');
        bubble.classList.add('sarah-folded');
      }
      setTimeout(() => { if (input) input.focus(); }, 200);
    }

    function closeModal() {
      if (modal) modal.classList.remove('sarah-open');
    }

    if (btn) btn.addEventListener('click', openModal);
    if (bubble) bubble.addEventListener('click', openModal);
    if (closeBtn) closeBtn.addEventListener('click', closeModal);

    if (chips) {
      chips.forEach(chip => {
        chip.addEventListener('click', function () {
          const q = this.getAttribute('data-query');
          if (q) handleUserMessage(q);
        });
      });
    }

    if (form) {
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!input) return;
        const text = input.value.trim();
        if (!text) return;
        input.value = '';
        if (typeof input.style.height === 'string') input.style.height = 'auto';
        handleUserMessage(text);
      });

      // ---- Saisie « à la ChatGPT/Gemini » : zone qui grandit, Entrée envoie ----
      if (input) {
        const grow = function () {
          input.style.height = 'auto';
          input.style.height = Math.min(120, Math.max(44, input.scrollHeight)) + 'px';
        };
        input.addEventListener('input', grow);
        input.addEventListener('keydown', function (e) {
          if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            if (form.requestSubmit) form.requestSubmit();
            else form.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
          }
        });
      }

      // ---- « Nouvelle conversation » : vidé, remis l'accueil, puces revenues ----
      const SARAH_WELCOME_HTML = messages ? messages.innerHTML : '';
      const newBtn = document.getElementById('sarah-newchat-btn');
      if (newBtn && messages) newBtn.addEventListener('click', function () {
        messages.innerHTML = SARAH_WELCOME_HTML;
        try { sessionStorage.removeItem('sarah_chat_v1'); } catch (e) {}
        SarahMemory.history = []; SarahMemory.turnCount = 0; SarahMemory.lastTopic = null;
      });

      // ---- La conversation VÉCUE reste visible quand on navigue sur le site ----
      try {
        const saved = JSON.parse(sessionStorage.getItem('sarah_chat_v1') || '[]');
        if (saved.length && messages) {
          for (const m of saved) appendMessage(m.sender, m.text, m.link, m.linkText, true);
          const chips = document.getElementById('sarah-chips');
          if (chips) chips.style.display = 'none';
          messages.scrollTop = messages.scrollHeight;
        }
      } catch (e) {}
    }

    // Persistance de session (sessionStorage uniquement — rien n'est envoyé ailleurs)
    function sarahPersistExchange(userText, reply) {
      try {
        let cur = JSON.parse(sessionStorage.getItem('sarah_chat_v1') || '[]');
        cur.push({ sender: 'user', text: userText });
        cur.push({ sender: 'bot', text: reply.text, link: reply.link || null, linkText: reply.linkText || null });
        if (cur.length > 40) cur = cur.slice(-40);
        sessionStorage.setItem('sarah_chat_v1', JSON.stringify(cur));
      } catch (e) {}
    }

    /* ------------------------------------------------------------------
       CORRECTIF MOBILE — « les écrits se cachent au téléphone ».
       Quand le clavier virtuel s'ouvre, la fenêtre de discussion est
       recalée automatiquement dans la zone réellement visible : le champ
       de saisie et les messages restent toujours à l'écran.
       (VisualViewport API — ignorée sans risque par les anciens navigateurs)
       ------------------------------------------------------------------ */
    function ajusterAuClavier() {
      try {
        var vv = window.visualViewport;
        if (!vv || !modal) return;
        var clavierOuvert = vv.height < (window.innerHeight * 0.78);
        if (clavierOuvert && modal.classList.contains('sarah-open')) {
          // Fenêtre calée exactement sur la zone visible (style « WhatsApp »)
          modal.style.top = vv.offsetTop + 'px';
          modal.style.left = '0px';
          modal.style.right = '0px';
          modal.style.bottom = 'auto';
          modal.style.width = '100%';
          modal.style.maxWidth = '100%';
          modal.style.height = vv.height + 'px';
          modal.style.maxHeight = vv.height + 'px';
          // Garder la fin de la conversation en vue
          if (messages) messages.scrollTop = messages.scrollHeight;
        } else {
          // Clavier fermé : on rend la main aux styles CSS d'origine
          modal.style.top = ''; modal.style.left = ''; modal.style.right = '';
          modal.style.bottom = ''; modal.style.width = ''; modal.style.maxWidth = '';
          modal.style.height = ''; modal.style.maxHeight = '';
        }
      } catch (e) {}
    }
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', ajusterAuClavier);
      window.visualViewport.addEventListener('scroll', ajusterAuClavier);
    }
    if (input) {
      // Le clavier met ~300-700ms à s'ouvrir : on ajuste deux fois
      input.addEventListener('focus', function () {
        setTimeout(ajusterAuClavier, 300);
        setTimeout(ajusterAuClavier, 700);
      });
      input.addEventListener('blur', function () {
        setTimeout(ajusterAuClavier, 300);
      });
    }
    window.addEventListener('orientationchange', function () {
      setTimeout(ajusterAuClavier, 400);
    });

    /* ==========================================================================
       CONNEXION AU BACKEND STAR AI CORE (adminstaros.netlify.app)
       ------------------------------------------------------------------
       Sarah appelle l'IA du backend via la fonction serverless Vercel
       /api/star-ai-proxy. Le moteur local reste le filet de sécurité :
       si le backend est injoignable, la réponse locale est utilisée.
       ========================================================================== */
    function buildBackendSystemPrompt() {
      // Prompt de base (personnalité de Sarah)
      let prompt = (window.SarahAIConfig && window.SarahAIConfig.systemPrompt) ||
        "Tu es Sarah, l'assistante virtuelle de direction de STAR ENTREPRISE, groupe congolais multiservices fondé par Carry Otemba. Tu réponds uniquement sur STAR ENTREPRISE, ses filiales au Congo et Carry Otemba. Zéro digression.";

      // Enrichir avec la base de connaissances du groupe (CORPORATE_DB, même scope)
      let known = null;
      try {
        if (typeof CORPORATE_DB !== 'undefined' && CORPORATE_DB) {
          known = CORPORATE_DB;
        }
      } catch (e) { known = null; }

      if (known) {
        const entries = [];
        Object.keys(known).forEach(function (key) {
          const item = known[key];
          if (item && (item.name || item.summary || item.details)) {
            const title = item.name || key;
            const body = item.summary || item.details || '';
            const vision = item.vision ? ' — ' + item.vision : '';
            entries.push('- ' + title + ': ' + body + vision);
          }
        });
        if (entries.length) {
          prompt += "\n\nVoici les informations précises de l'entreprise STAR ENTREPRISE à connaître pour répondre :\n" + entries.join('\n');
        }
      }
      return prompt;
    }

    function askBackendAI(userText, fallbackReply) {
      return new Promise(function (resolve) {
        if (typeof fetch !== 'function') {
          resolve(fallbackReply);
          return;
        }
        var system = buildBackendSystemPrompt();

        // CORRECTIF MAJEUR : ne JAMAIS mettre un message de rôle "system"
        // dans le tableau messages (l'API le refuse → les réponses devenaient
        // hors sujet dès le 2e message). Le contexte va dans le prompt système.
        if (SarahMemory.lastTopic) {
          system += "\n\nLe visiteur parle actuellement du sujet : " + SarahMemory.lastTopic +
                    ". Si sa question s'y rapporte, reste cohérente avec ce sujet.";
        }

        // Envoyer le VRAI historique (rôles user/assistant uniquement) pour
        // que Sarah garde le fil de la conversation comme une vraie assistante.
        var messages = [];
        if (Array.isArray(SarahMemory.history)) {
          messages = SarahMemory.history.slice(-8).map(function (m) {
            return { role: m.role, content: m.content };
          });
        }
        messages.push({ role: 'user', content: userText });

        // Liste d'endpoints tentés dans l'ordre (indépendance d'hébergeur) :
        // 1. Proxy local (Vercel /api/star-ai-proxy, ou tout hébergeur qui sert la fonction)
        // 2. Backend STAR AI CORE direct (Netlify) en secours
        var endpoints = [
          '/api/star-ai-proxy',
          'https://adminstaros.netlify.app/.netlify/functions/star-ai-proxy'
        ];

        var idx = 0;
        var timedOut = false;
        var timer = setTimeout(function () {
          timedOut = true;
          resolve(fallbackReply);
        }, 18000); // 18s max pour l'ensemble des essais

        function tryEndpoint() {
          if (timedOut) return;
          if (idx >= endpoints.length) {
            clearTimeout(timer);
            resolve(fallbackReply);
            return;
          }
          var endpoint = endpoints[idx++];
          fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ system: system, messages: messages })
          })
            .then(function (r) { return r.json().catch(function () { return {}; }); })
            .then(function (data) {
              if (timedOut) return;
              // CORRECTIF : accepter le format normalisé {ok,text} ET le format brut
              // de l'API (content[].text) renvoyé par le secours Netlify.
              var texteIA = null;
              if (data && data.ok && data.text) {
                texteIA = data.text;
              } else if (data && Array.isArray(data.content)) {
                var blocs = data.content.filter(function (b) { return b && b.type === 'text' && b.text; });
                if (blocs.length) texteIA = blocs.map(function (b) { return b.text; }).join('\n');
              }
              if (texteIA) {
                clearTimeout(timer);
                resolve({ text: texteIA, type: 'BACKEND_AI', link: null, linkText: null });
              } else {
                // Tenter l'endpoint suivant
                tryEndpoint();
              }
            })
            .catch(function () {
              if (timedOut) return;
              tryEndpoint();
            });
        }

        tryEndpoint();
      });
    }

    function handleUserMessage(userText) {
      SarahMemory.turnCount++;
      appendMessage('user', userText);
      // Style ChatGPT : dès l'envoi, VOTRE message reste à l'écran ; les
      // puces de suggestion s'effacent pour libérer la zone de discussion.
      const chipsEl = document.getElementById('sarah-chips');
      if (chipsEl) chipsEl.style.display = 'none';
      const typingId = showTypingIndicator();

      // Réponse locale immédiate (filet de sécurité)
      const localReply = parseUserIntent(userText);

      // Tentative de réponse via le backend STAR AI CORE
      askBackendAI(userText, localReply).then(function (reply) {
        removeTypingIndicator(typingId);
        const finalReply = reply || localReply;
        // Mémoriser l'échange pour la cohérence des réponses suivantes
        SarahMemory.history.push({ role: 'user', content: userText });
        SarahMemory.history.push({ role: 'assistant', content: finalReply.text });
        if (SarahMemory.history.length > 12) SarahMemory.history = SarahMemory.history.slice(-12);
        appendMessage('bot', finalReply.text, finalReply.link, finalReply.linkText);
        sarahPersistExchange(userText, finalReply);
        speakSarahResponse(finalReply.text);
        if (window.StarBackend && window.StarBackend.logSarahQuestion) {
          window.StarBackend.logSarahQuestion(userText, finalReply.text, finalReply.type || 'general');
        }
        // ESCALADE : si la question est complexe et n'a pas été résolue
        // par le moteur local (réponse générique), on la transmet au backend
        // pour que le PDG en soit informé en temps réel.
        const unresolved = (finalReply.type === 'UNIVERSAL_DEMIGOD_KNOWLEDGE') ||
                           (!finalReply.type) ||
                           ((localReply && localReply.type === 'UNIVERSAL_DEMIGOD_KNOWLEDGE') && userText.length > 14);
        if (unresolved && window.StarBackend && window.StarBackend.escalateUnresolved) {
          window.StarBackend.escalateUnresolved(userText, finalReply.text, finalReply.type || 'general', 'Visiteur Site Web');
        }
      });
    }

    function appendMessage(sender, htmlText, linkUrl, linkLabel, noScroll) {
      if (!messages) return;
      // Sécurité : le texte TAPÉ PAR L'UTILISATEUR est neutralisé pour que
      // des caractères comme < > & ne cassent jamais l'affichage du chat.
      if (sender === 'user') {
        htmlText = String(htmlText)
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;');
      }
      const msgDiv = document.createElement('div');
      msgDiv.className = 'sarah-msg sarah-' + sender;

      let inner = `<div class="sarah-msg-content">${htmlText}`;
      if (linkUrl && linkLabel) {
        inner += `<br><a href="${linkUrl}" class="sarah-link-btn">${linkLabel}</a>`;
      }
      inner += `</div>`;

      msgDiv.innerHTML = inner;
      messages.appendChild(msgDiv);
      if (noScroll) return;
      // Ancrage type ChatGPT : votre message se cale en haut de la zone et
      // la réponse de Sarah se déroule en dessous — plus rien ne « se cache ».
      requestAnimationFrame(function () {
        try {
          if (sender === 'bot') {
            const zoneRect = messages.getBoundingClientRect();
            const prev = msgDiv.previousElementSibling;
            if (prev && prev.classList.contains('sarah-user')) {
              messages.scrollTop += (prev.getBoundingClientRect().top - zoneRect.top) - 6;
            } else {
              messages.scrollTop = messages.scrollHeight;
            }
          } else {
            msgDiv.scrollIntoView({ block: 'end', behavior: 'smooth' });
          }
        } catch (e) {
          try { messages.scrollTop = messages.scrollHeight; } catch (e2) {}
        }
      });
    }

    function showTypingIndicator() {
      if (!messages) return null;
      const id = 'sarah-typing-' + Date.now();
      const div = document.createElement('div');
      div.id = id;
      div.className = 'sarah-msg sarah-bot';
      div.innerHTML = `
        <div class="sarah-typing-indicator">
          <div class="sarah-dot-anim"></div>
          <div class="sarah-dot-anim"></div>
          <div class="sarah-dot-anim"></div>
        </div>
      `;
      messages.appendChild(div);
      messages.scrollTop = messages.scrollHeight;
      return id;
    }

    function removeTypingIndicator(id) {
      if (!id) return;
      const el = document.getElementById(id);
      if (el) el.remove();
    }

    function initVoiceRecording() {
      const micBtn = document.getElementById('sarah-mic-btn');
      if (!micBtn || !input) return;
      const footer = document.getElementById('sarah-footer');

      let recognition = null;
      let isRecording = false;
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

      if (SpeechRecognition) {
        try {
          recognition = new SpeechRecognition();
          recognition.continuous = true;
          recognition.interimResults = true;
          recognition.lang = 'fr-FR';

          recognition.onresult = function (event) {
            let transcript = '';
            for (let i = 0; i < event.results.length; i++) {
              transcript += event.results[i][0].transcript;
            }
            input.value = transcript;
          };

          recognition.onerror = function () {
            stopRecording(true);
          };
          recognition.onend = function () {
            stopRecording(true);
          };
        } catch (e) {
          recognition = null;
        }
      }

      function stopRecording(autoSubmit) {
        isRecording = false;
        micBtn.classList.remove('is-recording');
        input.placeholder = "Écrivez votre message...";
        const wave = document.getElementById('sarah-voice-wave');
        if (wave) wave.remove();
        if (recognition) {
          try { recognition.stop(); } catch (e) {}
        }
        if (autoSubmit && input.value.trim()) {
          const spokenText = input.value.trim();
          input.value = '';
          window.SarahVoiceMode = true;
          handleUserMessage(spokenText);
        }
      }

      function simulateRealTimeDictation() {
        const sampleQueries = [
          "Bonjour",
          "Bonjour Sarah, je voudrais connaître les tarifs pour une consultation médicale à la Clinique Havre de Vie.",
          "Je souhaite un devis pour louer un jet privé STAR JET depuis Pointe-Noire pour un voyage d'affaires.",
          "Quelles sont les opportunités d'investissement immobilier avec STAR IMMO actuellement au Congo ?",
          "C'est quoi l'immobilier au Congo avec STAR IMMO ?"
        ];
        const chosenQuery = sampleQueries[Math.floor(Math.random() * sampleQueries.length)];
        let charIdx = 0;
        input.value = "";

        const wave = document.createElement('div');
        wave.id = 'sarah-voice-wave';
        wave.style.cssText = 'position:absolute; bottom:56px; left:16px; right:16px; background:rgba(11,31,58,0.95); color:#D4AF37; border:1px solid #D4AF37; border-radius:8px; padding:8px 14px; font-size:12px; font-weight:700; display:flex; align-items:center; gap:8px; box-shadow:0 -4px 15px rgba(0,0,0,0.4); z-index:100;';
        wave.innerHTML = '<span style="color:#EF4444; font-size:14px; animation:sarahMicPulse 1s infinite;">●</span> <span>🎙️ Enregistrement vocal... Parole retranscrite en direct :</span>';
        if (footer) {
          footer.style.position = 'relative';
          footer.appendChild(wave);
        }

        const dictationInterval = setInterval(function () {
          if (!isRecording) {
            clearInterval(dictationInterval);
            return;
          }
          if (charIdx < chosenQuery.length) {
            input.value += chosenQuery.charAt(charIdx);
            charIdx++;
          } else {
            clearInterval(dictationInterval);
            setTimeout(function () {
              stopRecording(true);
            }, 600);
          }
        }, 35);
      }

      micBtn.addEventListener('click', function () {
        if (isRecording) {
          stopRecording(true);
        } else {
          // Si Sarah est en train de parler, on arrête sa parole pour que l'utilisateur puisse parler tranquillement
          if (window.speechSynthesis) {
            try { window.speechSynthesis.cancel(); } catch (e) {}
          }
          isRecording = true;
          micBtn.classList.add('is-recording');
          input.placeholder = "🔴 Écoute en cours... Parlez maintenant";
          input.focus();

          if (recognition) {
            try {
              recognition.start();
            } catch (e) {
              simulateRealTimeDictation();
            }
          } else {
            simulateRealTimeDictation();
          }
        }
      });
    }

    function initSarahSpeech() {
      const micBtn = document.getElementById('sarah-mic-btn');
      if (micBtn) {
        micBtn.addEventListener('click', function () {
          if (!window.SarahVoiceMode) {
            window.SarahVoiceMode = true;
          }
        });
      }
    }

    function speakSarahResponse(htmlText) {
      if (!window.SarahVoiceMode) return;

      const avatar = document.getElementById('sarah-header-img');
      const plainText = htmlText
        .replace(/<br\s*[\/]?>/gi, '. ')
        .replace(/<[^>]+>/g, '')
        .replace(/[🌟🏥🏡✈️🚗💻🎉✅👋🔒🎤🎙️🔊🔴]/g, '')
        .replace(/\s+/g, ' ')
        .trim();

      if (!plainText) return;

      function triggerAfterSpeech() {
        if (avatar) avatar.classList.remove('is-speaking');
        // SUPPRESSION TOTALE de l'ouverture automatique du micro pour éviter tout basculement intempestif !
      }

      if (plainText.includes("Je suis Sarah, votre assistante") && typeof Audio !== 'undefined') {
        try {
          const audio = new Audio('audio/sarah-greeting.mp3');
          audio.onplay = () => { if (avatar) avatar.classList.add('is-speaking'); };
          audio.onended = () => { triggerAfterSpeech(); };
          audio.onerror = () => { fallbackSynth(plainText); };
          audio.play();
          return;
        } catch (e) {
          fallbackSynth(plainText);
          return;
        }
      }
      if (plainText.includes("Mode vocal activé") && typeof Audio !== 'undefined') {
        try {
          const audio = new Audio('audio/sarah-voice-intro.mp3');
          audio.onplay = () => { if (avatar) avatar.classList.add('is-speaking'); };
          audio.onended = () => { triggerAfterSpeech(); };
          audio.onerror = () => { fallbackSynth(plainText); };
          audio.play();
          return;
        } catch (e) {
          fallbackSynth(plainText);
          return;
        }
      }

      fallbackSynth(plainText);

      function fallbackSynth(txt) {
        if (!window.speechSynthesis) return;
        try {
          window.speechSynthesis.cancel();

          const utterance = new SpeechSynthesisUtterance(txt);
          utterance.lang = 'fr-FR';
          utterance.pitch = 1.14;
          utterance.rate = 0.92;
          utterance.volume = 1.0;

          const voices = window.speechSynthesis.getVoices();
          let selectedVoice = null;
          const preferredNames = ["amelie", "thomas (enhanced)", "microsoft denise", "microsoft henri", "microsoft celeste", "microsoft eloise", "google français", "hortense", "virginie", "pauline"];

          for (let i = 0; i < preferredNames.length; i++) {
            const found = voices.find(v => v.lang.toLowerCase().includes('fr') && v.name.toLowerCase().includes(preferredNames[i]));
            if (found) {
              selectedVoice = found;
              break;
            }
          }
          if (!selectedVoice) {
            selectedVoice = voices.find(v => v.lang.toLowerCase().includes('fr'));
          }
          if (selectedVoice) {
            utterance.voice = selectedVoice;
          }

          utterance.onstart = function () {
            if (avatar) avatar.classList.add('is-speaking');
          };
          utterance.onend = function () {
            triggerAfterSpeech();
          };
          utterance.onerror = function () {
            triggerAfterSpeech();
          };

          window.speechSynthesis.speak(utterance);
        } catch (e) {
          triggerAfterSpeech();
        }
      }
    }

    initSarahSpeech();
    
    initVoiceRecording();
  }

  /* ==========================================================================
     7. INITIALISATION SUR TOUTES LES PAGES
     ========================================================================== */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      buildSarahUI();
      scheduleSarahAppearance();
    });
  } else {
    buildSarahUI();
    scheduleSarahAppearance();
  }

})();
