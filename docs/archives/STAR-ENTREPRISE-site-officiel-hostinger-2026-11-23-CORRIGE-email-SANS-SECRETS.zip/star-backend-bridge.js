/**
 * STAR ENTREPRISE — UNIVERSAL BACKEND SYNC & AI CORRELATION BRIDGE
 * Corrélation complète en temps réel entre le site web et le backend STAR OS.
 *
 * Points clés :
 *  - Écriture DIRECTE dans Supabase depuis le navigateur (aucune fonction
 *    serveur requise → fonctionne sur TOUT hébergeur : Vercel, Netlify,
 *    GitHub Pages, cPanel, etc.)
 *  - File de synchronisation avec retry automatique (si perte réseau)
 *  - Escalade automatique des questions complexes que Sarah ne peut résoudre
 *  - Capture de toutes les commandes / achats / formulaires
 *  - Notifications temps réel via Supabase Realtime + BroadcastChannel
 *  - Compatible avec l'architecture existante (adminstaros.netlify.app)
 */

(function () {
  'use strict';

  // ------------------------------------------------------------------
  // CONFIGURATION SUPABASE (partagée avec le backend adminstaros.netlify.app)
  // ------------------------------------------------------------------
  // ✔ MISE À JOUR : le projet Supabase d'origine n'existe plus (DNS inexistant).
  //    Désactivé pour éviter les erreurs réseau silencieuses en console.
  //    Toutes les données vont désormais au backend Hostinger (api/star-os).
  var SUPABASE_URL = "";
  var SUPABASE_KEY = "";
  var TABLE_NAME = "star_data";
  // IMPORTANT : le backend lit star_data par le user_id du compte connecté (PDG).
  // Pour garantir que le PDG voie les données du site en temps réel, définissez
  // ici le user_id Supabase exact de votre compte admin/PDG (colonne user_id).
  // Si vous laissez vide (""), le champ user_id est omis (mode anonyme/global),
  // ce qui correspond au comportement du bridge d'origine.
  var STAR_BACKEND_USER_ID = "";

  // ------------------------------------------------------------------
  // CONFIGURATION DU BACKEND PHP (STAR OS) — recommandé
  // ------------------------------------------------------------------
  // Point d'entrée de l'API PHP du backend. Déployez le dossier "backend/"
  // sur votre hébergeur (Hostinger) puis indiquez son URL ici.
  // Exemple Hostinger : "https://votresite.com/backend/api.php"
  // Ce backend stocke en base, envoie les e-mails et alimente le tableau
  // de bord temps réel. Laissez "" pour désactiver (fallback Supabase).
  // ✔ MISE À JOUR : l'ancien hébergeur gratuit (ifree.page) est mort.
  //    Le backend vit désormais sur Hostinger, AU MÊME DOMAINE que le site :
  //    l'adresse relative "/api/star-os" (essayée en premier ci-dessous) suffit.
  //    Laissez "" ici — ne remplissez QUE si site et backend sont sur 2 domaines différents.
  var STAR_BACKEND_API_URL = "";   // ex. si besoin : "https://votredomaine.com/backend/api.php"
  var STAR_BACKEND_API_KEY = "star-os-live-2026-secret-key"; // doit correspondre à config.php du backend

  // Broadcast Channel pour sync live (même backend)
  var bc = null;
  try {
    if (typeof BroadcastChannel !== 'undefined') {
      bc = new BroadcastChannel('star_os_sync');
    }
  } catch (e) {}

  // ------------------------------------------------------------------
  // HELPERS localStorage
  // ------------------------------------------------------------------
  function getLocalList(key) {
    try {
      var item = localStorage.getItem(key);
      return item ? JSON.parse(item) : [];
    } catch (e) {
      return [];
    }
  }

  function saveLocalList(key, list) {
    var jsonStr = JSON.stringify(list);
    var keysToSave = [key, "star_data_" + key, "star_os_" + key, "star_admin_" + key];
    keysToSave.forEach(function (k) {
      try { localStorage.setItem(k, jsonStr); } catch (e) {}
    });
    if (bc) {
      try { bc.postMessage({ type: 'SYNC_UPDATE', key: key, data: list }); } catch (e) {}
    }
  }

  // ------------------------------------------------------------------
  // FILE DE SYNCHRONISATION UNIVERSELLE (retry automatique)
  // ------------------------------------------------------------------
  // Chaque clé est synchronisée sur Supabase. Si l'écriture échoue,
  // on la remet dans une file pour un nouvel essai (rétention 5 min).
  var PENDING = {}; // { key: timestampDernierEssai }

  async function syncToSupabase(key, dataValue) {
    if (!SUPABASE_URL || !SUPABASE_KEY) return;
    try {
      var url = SUPABASE_URL + "/rest/v1/" + TABLE_NAME;
      var payload = {
        key: key,
        value: dataValue,
        updated_at: new Date().toISOString()
      };
      if (STAR_BACKEND_USER_ID) { payload.user_id = STAR_BACKEND_USER_ID; }
      var res = await fetch(url, {
        method: "POST",
        headers: {
          "apikey": SUPABASE_KEY,
          "Authorization": "Bearer " + SUPABASE_KEY,
          "Content-Type": "application/json",
          "Prefer": "return=representation,resolution=merge-duplicates"
        },
        body: JSON.stringify(payload)
      });
      // Si échec, planifier un retry
      if (!res.ok) {
        scheduleRetry(key, dataValue);
      } else {
        delete PENDING[key];
      }
    } catch (e) {
      scheduleRetry(key, dataValue);
    }
  }

  function scheduleRetry(key, dataValue) {
    // Limiter les retries : un essai max toutes les 45s par clé
    var now = Date.now();
    if (PENDING[key] && (now - PENDING[key]) < 45000) return;
    PENDING[key] = now;
    setTimeout(function () {
      if (navigator.onLine !== false) {
        syncToSupabase(key, dataValue);
      } else {
        // Réessayer quand le réseau revient
        window.addEventListener('online', function () {
          syncToSupabase(key, dataValue);
        }, { once: true });
      }
    }, 45000);
  }

  // ------------------------------------------------------------------
  // ÉVÉNEMENT TEMPS RÉEL (émission dédiée pour notifications instantanées)
  // ------------------------------------------------------------------
  // Écrit une "ligne événement" dans star_data pour que le backend
  // affiche immédiatement la notification (postgres_changes / realtime).
  function pushRealtimeEvent(eventObj) {
    if (!SUPABASE_URL || !SUPABASE_KEY) return;
    try {
      var url = SUPABASE_URL + "/rest/v1/" + TABLE_NAME;
      var payload = {
        key: eventObj.key || ('live_' + Date.now()),
        value: eventObj,
        updated_at: new Date().toISOString()
      };
      if (STAR_BACKEND_USER_ID) { payload.user_id = STAR_BACKEND_USER_ID; }
      fetch(url, {
        method: "POST",
        headers: {
          "apikey": SUPABASE_KEY,
          "Authorization": "Bearer " + SUPABASE_KEY,
          "Content-Type": "application/json",
          "Prefer": "return=minimal,resolution=merge-duplicates"
        },
        body: JSON.stringify(payload)
      }).catch(function () {});
      // Diffusion locale immédiate
      if (bc) {
        try { bc.postMessage({ type: 'REALTIME_EVENT', data: eventObj }); } catch (e) {}
      }
    } catch (e) {}
  }

  // ------------------------------------------------------------------
  // ENVOI VERS LE BACKEND PHP (STAR OS) — e-mail + temps réel
  // ------------------------------------------------------------------
  // Envoie un événement à l'API PHP du backend (api.php). Le backend
  // stocke en base, envoie un e-mail d'alerte et alimente le tableau de bord.
  function sendToPhpBackend(action, data) {
    if (typeof fetch !== 'function') return Promise.resolve(null);

    var payload = JSON.stringify({ action: action, data: data, api_key: STAR_BACKEND_API_KEY });

    // Essayer d'abord le relais Vercel /api/star-os (même origine → pas de CORS,
    // la fonction Vercel relaie côté serveur vers le backend freeinfinity).
    // Ceci contourne le blocage navigateur (erreur 000) vers freeinfinity.
    var endpoints = ['/api/star-os', '/backend/api.php'];
    if (STAR_BACKEND_API_URL) {
      endpoints.push(STAR_BACKEND_API_URL);
    }

    function attempt(i) {
      if (i >= endpoints.length) return Promise.resolve(null);
      var url = endpoints[i];
      var opts = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: payload
      };
      // Le relais Vercel gère l'auth côté serveur ; pour l'appel direct,
      // on envoie la clé Bearer.
      if (url.indexOf('/api/star-os') === -1 && STAR_BACKEND_API_KEY) {
        opts.headers['Authorization'] = 'Bearer ' + STAR_BACKEND_API_KEY;
      }
      return fetch(url, opts)
        .then(function (r) { return r.json().catch(function () { return {}; }); })
        .then(function (json) {
          if (json && json.ok) return json;
          return attempt(i + 1);
        })
        .catch(function () { return attempt(i + 1); });
    }
    return attempt(0);
  }

  // ------------------------------------------------------------------
  // 1. ENVOI D'UNE REQUÊTE / COMMANDE AU BACKEND
  // ------------------------------------------------------------------
  function sendClientRequest(options) {
    var opts = options || {};
    var now = new Date();
    var isoDate = now.toISOString();
    var dateFormatted = now.toLocaleDateString('fr-FR', {
      day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
    });

    // Détecter si c'est une COMMANDE (achat) → priorité haute
    var isCommand = /achat|commande|acquérir|acquiérir|reserver|réserver|acheter|purchase|buy|payer|order/i.test(
      (opts.type || '') + ' ' + (opts.subject || '') + ' ' + (opts.message || '')
    );

    var entryObj = {
      id: 'req_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
      date: isoDate,
      dateFormatted: dateFormatted,
      type: opts.type || 'Contact / Message Client',
      client: opts.name || opts.client || 'Client en ligne',
      email: opts.email || 'non précisé',
      telephone: opts.phone || opts.telephone || 'non précisé',
      ville: opts.city || opts.ville || 'Brazzaville / Pointe-Noire',
      sujet: opts.subject || opts.sujet || 'Nouvelle requête depuis le site web',
      message: opts.message || 'Demande enregistrée via formulaire ou assistant IA.',
      status: 'Nouveau',
      isCommand: isCommand,
      source: opts.source || window.location.pathname
    };

    // Enregistrer dans 'entries'
    var entries = getLocalList('entries');
    entries.unshift(entryObj);
    if (entries.length > 200) entries.pop();
    saveLocalList('entries', entries);
    syncToSupabase('entries', entries);

    // Alerte pour le PDG/Admin (visible dans backend)
    var alertObj = {
      id: 'alt_' + Date.now(),
      date: isoDate,
      title: (isCommand ? '🛒 NOUVELLE COMMANDE : ' : 'Nouvelle Requête : ') + entryObj.type,
      message: entryObj.client + ' — ' + (entryObj.sujet || entryObj.message).substr(0, 90),
      type: isCommand ? 'commande' : 'info',
      read: false
    };
    var alertes = getLocalList('alertes');
    alertes.unshift(alertObj);
    if (alertes.length > 100) alertes.pop();
    saveLocalList('alertes', alertes);
    syncToSupabase('alertes', alertes);

    // Événement temps réel dédié (notif instantanée)
    pushRealtimeEvent({
      id: alertObj.id,
      kind: isCommand ? 'commande' : 'requete',
      title: alertObj.title,
      message: alertObj.message,
      client: entryObj.client,
      details: entryObj.message,
      page: window.location.pathname,
      ts: isoDate
    });

    // Client (si identité fournie)
    if (opts.name || opts.email || opts.phone) {
      var clients = getLocalList('clients');
      var exists = clients.some(function (c) {
        return (c.email && c.email === opts.email) || (c.nom && c.nom === opts.name);
      });
      if (!exists) {
        clients.unshift({
          id: 'cli_' + Date.now(),
          nom: opts.name || 'Client',
          email: opts.email || '',
          telephone: opts.phone || '',
          ville: opts.city || 'Congo',
          created_at: isoDate
        });
        if (clients.length > 150) clients.pop();
        saveLocalList('clients', clients);
        syncToSupabase('clients', clients);
      }
    }

    // Activité
    var activites = getLocalList('activites');
    activites.unshift({
      id: 'act_' + Date.now(),
      date: isoDate,
      action: isCommand ? 'Nouvelle commande client' : 'Nouvelle requête client',
      user: entryObj.client,
      details: entryObj.type + ' — ' + entryObj.sujet
    });
    if (activites.length > 100) activites.pop();
    saveLocalList('activites', activites);
    syncToSupabase('activites', activites);

    // Envoyer aussi au backend PHP (e-mail + temps réel)
    var phpPromise = sendToPhpBackend('request', {
      type: entryObj.type,
      client: entryObj.client,
      email: entryObj.email,
      telephone: entryObj.telephone,
      ville: entryObj.ville,
      sujet: entryObj.sujet,
      message: entryObj.message,
      is_command: !!entryObj.isCommand,
      notify: !!opts.notify,
      from_form: !!opts.from_form,
      kind_hint: opts.kind_hint || '',
      page: window.location.pathname
    });

    entryObj._php = phpPromise;
    return entryObj;
  }

  // ------------------------------------------------------------------
  // 2. JOURNAL SARAH AI — Question + Réponse + ESCALADE
  // ------------------------------------------------------------------
  function logSarahQuestion(questionText, answerText, intentName, clientInfo) {
    if (!questionText) return;
    var now = new Date();
    var isoDate = now.toISOString();

    var convItem = {
      id: 'msg_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
      timestamp: isoDate,
      timeFormatted: now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
      sender: 'client',
      question: questionText,
      answer: answerText || '',
      intent: intentName || 'general',
      page: window.location.pathname,
      client: clientInfo || 'Visiteur Site Web'
    };

    var conversation = getLocalList('conversation');
    conversation.push(convItem);
    if (conversation.length > 300) conversation.shift();
    saveLocalList('conversation', conversation);
    syncToSupabase('conversation', conversation);

    // Envoyer la conversation au backend PHP
    sendToPhpBackend('conversation', {
      question: questionText,
      answer: answerText || '',
      intent: intentName || 'general',
      client: clientInfo || 'Visiteur Site Web',
      page: window.location.pathname
    });

    // CORRECTIF COHÉRENCE : une question posée à Sarah reste DANS LE MODULE IA.
    // (Avant : une copie partait en « demande » au client — avec le mot « prix »
    //  ou « payer » elle atterrissait même chez Paiements, et créait une fausse
    //  fiche « Utilisateur Sarah AI ». Supprimé : la vraie conversation est
    //  déjà envoyée ci-dessus ; l'escalade, elle, passe par escalateUnresolved.)
  }

  // ------------------------------------------------------------------
  // 3. ESCALADE D'UNE QUESTION COMPLEXE NON RÉSOLUE PAR L'IA
  // ------------------------------------------------------------------
  // À appeler quand Sarah n'a PAS pu répondre (réponse générique/fallback).
  // Le message est transmis au backend pour que le PDG puisse répondre.
  function escalateUnresolved(questionText, answerText, intentName, clientInfo) {
    if (!questionText) return;
    var now = new Date();
    var isoDate = now.toISOString();

    var title = '⚠️ QUESTION NON RÉSOLUE par Sarah — ' + (intentName || 'Question complexe');
    var messageText = 'Un visiteur a posé une question que l\'IA n\'a pas pu traiter :\n"' +
      questionText + '"\n\nRéponse partielle : "' + (answerText || '') +
      '"\n\n→ Répondez à ce client depuis votre backend.';

    // Ajouter une alerte prioritaire 'urgente'
    var alertes = getLocalList('alertes');
    alertes.unshift({
      id: 'alt_' + Date.now(),
      date: isoDate,
      title: title,
      message: messageText,
      type: 'urgente',
      unresolved: true,
      question: questionText,
      read: false
    });
    if (alertes.length > 100) alertes.pop();
    saveLocalList('alertes', alertes);
    syncToSupabase('alertes', alertes);

    // Escalade = événement de l'IA : envoyé au module SARAH (action
    // 'unresolved' → badge Sarah, file « à traiter »), JAMAIS en demande
    // générale ni en fiche client.
    sendToPhpBackend('unresolved', {
      question: questionText,
      partial_answer: answerText || '',
      intent: intentName || 'général',
      client: 'Visiteur Site Web',
      page: window.location.pathname
    });

    // Événement temps réel dédié (son/notification dans backend)
    pushRealtimeEvent({
      id: 'esc_' + Date.now(),
      kind: 'escalade',
      title: title,
      message: messageText,
      question: questionText,
      client: clientInfo || 'Visiteur',
      page: window.location.pathname,
      ts: isoDate
    });

    // Envoi dédié au backend PHP (question non résolue → e-mail ⚠️ + temps réel)
    sendToPhpBackend('unresolved', {
      question: questionText,
      partial_answer: answerText || '',
      intent: intentName || 'general',
      client: clientInfo || 'Visiteur Site Web',
      page: window.location.pathname
    });

    // Diffusion locale (si un onglet backend est ouvert)
    if (bc) {
      try { bc.postMessage({ type: 'UNRESOLVED_QUESTION', data: { question: questionText, answer: answerText, intent: intentName } }); } catch (e) {}
    }
  }

  // ------------------------------------------------------------------
  // 4. NOTIFICATION VISUELLE
  // ------------------------------------------------------------------
  function showBackendNotification(msgText) {
    var existing = document.getElementById('star-backend-toast');
    if (existing && existing.parentNode) existing.remove();
    var toast = document.createElement('div');
    toast.id = 'star-backend-toast';
    toast.style.cssText = 'position:fixed; bottom:24px; left:24px; background:linear-gradient(135deg,#0B1F3A,#071224); color:#fff; border:1px solid #D4AF37; border-radius:12px; padding:14px 20px; box-shadow:0 12px 36px rgba(0,0,0,0.45); z-index:999999; display:flex; align-items:center; gap:12px; font-size:13.5px; font-weight:600; font-family:Manrope,sans-serif; max-width:400px; animation:starToastSlide 0.3s ease-out;';
    toast.innerHTML = '<span style="font-size:20px;">✅</span><div><div style="color:#D4AF37; font-weight:800; font-size:11px; text-transform:uppercase; letter-spacing:0.05em; margin-bottom:2px;">STAR OS — Tableau de bord PDG</div><div style="line-height:1.4;">' + (msgText || 'Requête et questions transmises au backend en temps réel.') + '</div></div>';
    document.body.appendChild(toast);
    setTimeout(function () { if (toast && toast.parentNode) toast.remove(); }, 5000);
  }

  // ------------------------------------------------------------------
  // 5. INTERCEPTION UNIVERSEL DES FORMULAIRES
  // ------------------------------------------------------------------
  function formAIgnorer(form) {
    if (!form) return true;
    if (form.getAttribute('data-star-skip') === '1') return true;
    if (form.id === 'candFormEl' || form.id === 'rdvFormEl' || form.id === 'purchaseArtForm') return true;
    if (form.closest('#stp-overlay')) return true;
    var path = String(window.location.pathname || '').toLowerCase();
    if (path.indexOf('mon-compte') !== -1) return true;
    return false;
  }

  function initFormInterceptors() {
    document.querySelectorAll('form').forEach(function (form) {
      if (form._starBackendBound) return;
      form._starBackendBound = true;
      if (formAIgnorer(form)) return;

      form.addEventListener('submit', function () {
        try {
          var fd = new FormData(form);
          var dataObj = {};
          fd.forEach(function (value, key) { dataObj[key] = value; });

          var nameVal = dataObj.nom || dataObj.name || dataObj.fullname || dataObj['Nom complet'] || dataObj.client || '';
          var emailVal = dataObj.email || dataObj.mail || dataObj['Adresse email'] || '';
          var phoneVal = dataObj.telephone || dataObj.phone || dataObj.tel || dataObj['Numéro de téléphone'] || '';
          var subjectVal = dataObj.sujet || dataObj.subject || dataObj.title || 'Formulaire web : ' + (form.id || form.className || 'contact');
          var messageVal = dataObj.message || dataObj.msg || dataObj.comment || JSON.stringify(dataObj);

          var sent = sendClientRequest({
            type: 'Formulaire Web (' + (form.id || 'Soumission') + ')',
            name: nameVal || 'Visiteur en ligne',
            email: emailVal,
            phone: phoneVal,
            subject: subjectVal,
            message: messageVal,
            source: window.location.pathname,
            notify: true,
            from_form: true
          });
          if (sent && sent._php && typeof sent._php.then === 'function') {
            sent._php.then(function (r) {
              if (r && r.ok) showBackendNotification('Votre message a bien été transmis à STAR ENTREPRISE.');
            }).catch(function () {});
          }
        } catch (err) {}
      });
    });
  }

  // Le formulaire d'achat CARRY.O est envoyé par la page elle-même (éviter un double e-mail).
  function initPurchaseInterceptors() {}

  // Les e-mails « PAIEMENT REÇU » ne partent QUE du backend PHP (paiement.php)
  // après encaissement OpenPay réel. Le navigateur n'envoie plus d'alerte paiement.

  // ------------------------------------------------------------------
  // API PUBLIQUE
  // ------------------------------------------------------------------
  window.StarBackend = {
    sendClientRequest: sendClientRequest,
    sendAlert: function (opts) {
      var alertes = getLocalList('alertes');
      alertes.unshift({
        id: 'alt_' + Date.now(),
        date: new Date().toISOString(),
        title: opts.title || 'Notification STAR OS',
        message: opts.message || '',
        type: opts.type || 'info',
        read: false
      });
      saveLocalList('alertes', alertes);
      syncToSupabase('alertes', alertes);
      pushRealtimeEvent({ id: 'alt_' + Date.now(), kind: 'alerte', title: opts.title || 'Notification', message: opts.message || '', ts: new Date().toISOString() });
    },
    logSarahQuestion: logSarahQuestion,
    escalateUnresolved: escalateUnresolved,
    sendToPhpBackend: sendToPhpBackend,
    envoyerFormulaire: function (payload) {
      payload = payload || {};
      payload.notify = true;
      payload.from_form = true;
      payload.page = payload.page || (window.location.pathname || '');
      return sendToPhpBackend('request', payload);
    },
    getStats: function () {
      return {
        entriesCount: getLocalList('entries').length,
        alertesCount: getLocalList('alertes').length,
        conversationCount: getLocalList('conversation').length,
        clientsCount: getLocalList('clients').length
      };
    },
    initFormInterceptors: initFormInterceptors,
    initPurchaseInterceptors: initPurchaseInterceptors,
    syncNow: function () {
      // Synchronise immédiatement toutes les listes vers Supabase
      ['entries', 'alertes', 'clients', 'activites', 'conversation'].forEach(function (k) {
        syncToSupabase(k, getLocalList(k));
      });
    }
  };

  // ------------------------------------------------------------------
  // INITIALISATION
  // ------------------------------------------------------------------
  function init() {
    initFormInterceptors();
    initPurchaseInterceptors();
    // Sync immédiate au chargement
    window.StarBackend.syncNow();
    // Sync périodique de secours toutes les 2 min
    setInterval(function () { window.StarBackend.syncNow(); }, 120000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
