<?php
/**
 * ============================================================
 *  STAR OS — ASSISTANT D'INSTALLATION
 * ============================================================
 *  Ouvrez ce fichier UNE SEULE FOIS après l'envoi sur Hostinger :
 *      https://votredomaine.com/install.php
 *  Il vérifie tout et prépare la base de données.
 *  ⚠️ SUPPRIMEZ ce fichier après utilisation !
 * ============================================================
 */

require_once __DIR__ . '/config.php';

// ============================================================
//  📨 TEST RÉEL D'ENVOI D'E-MAIL (protégé par le mot de passe admin)
// ============================================================
$testMail = null; // ['ok'|'ko', message]
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ($_POST['action'] ?? '') === 'test_mail') {
    $mdp = (string)($_POST['mdp'] ?? '');
    if (!password_verify($mdp, ADMIN_PASSWORD_HASH)) {
        $testMail = ['ko', '⛔ Mot de passe admin incorrect — AUCUN e-mail envoyé.'];
    } else {
        $sujet = '🔔 STAR OS — E-mail de test depuis install.php';
        $corps = "Bravo ! Si vous lisez ceci, les alertes e-mail de votre site fonctionnent.\nChaque commande, achat et paiement arrivera dans cette boîte automatiquement.\n— Test envoyé le " . date('d/m/Y à H:i');
        $envoye = false; $detail = '';
        if (defined('BREVO_API_KEY') && strpos(BREVO_API_KEY, 'METTEZ') === false && function_exists('curl_init')) {
            $ch = curl_init('https://api.brevo.com/v3/smtp/email');
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode([
                    'sender' => ['name' => BREVO_SENDER_NAME, 'email' => BREVO_SENDER_EMAIL],
                    'to' => [['email' => STAR_NOTIFY_EMAIL]],
                    'subject' => $sujet, 'textContent' => $corps,
                ], JSON_UNESCAPED_UNICODE),
                CURLOPT_HTTPHEADER => ['api-key: ' . BREVO_API_KEY, 'Content-Type: application/json'],
                CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_TIMEOUT => 20,
            ]);
            $res = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
            if ($res !== false && $code >= 200 && $code < 300) {
                $envoye = true; $detail = "Brevo a accepté l'envoi (HTTP $code).";
            } else {
                $detail = "Brevo a répondu HTTP $code : " . substr((string)$res, 0, 160);
            }
        }
        if (!$envoye) {
            $secours = @mail(STAR_NOTIFY_EMAIL, '=?UTF-8?B?' . base64_encode($sujet) . '?=', $corps, 'From: ' . STAR_FROM_EMAIL . "\r\nContent-Type: text/plain; charset=utf-8");
            $detail .= $secours ? ' · Secours mail() utilisé.' : ($detail ? '' : ' · Secours mail() indisponible.');
            $envoye = $secours;
        }
        $testMail = [$envoye ? 'ok' : 'ko', ($envoye ? '✅ ' . $detail . ' Regardez la boîte ' . STAR_NOTIFY_EMAIL . ' (pensez au dossier Spam/Promotions).' : '⛔ ' . $detail)];
    }
}

$etapes = [];

// 1. Version de PHP
$pv = PHP_VERSION;
$etapes[] = [ version_compare($pv, '7.4', '>='), "Version de PHP : $pv", version_compare($pv, '8.1', '>=') ? '' : 'Version ancienne — dans hPanel, choisissez PHP 8.1 ou plus (Avancé → Configuration PHP).'];

// 2. MySQLi disponible
$etapes[] = [ extension_loaded('mysqli'), 'Extension MySQLi (connexion base de données)', ''];

// 3. Connexion à la base + création des tables
$dbOk = false; $dbMsg = '';
try {
    if (!defined('STAR_INSTALL_MODE')) define('STAR_INSTALL_MODE', true);
    require_once __DIR__ . '/backend/db.php';
    $db = star_db();
    $dbOk = true;
    $cnt = $db->query("SELECT COUNT(*) c FROM star_events")->fetch_assoc()['c'];
    $dbMsg = "Tables prêtes · $cnt événement(s) enregistré(s)";
} catch (Throwable $e) {
    $dbMsg = 'Erreur : ' . $e->getMessage();
}
$etapes[] = [ $dbOk, 'Connexion MySQL + tables', $dbOk ? $dbMsg : "⛔ $dbMsg — vérifiez DB_NAME / DB_USER / DB_PASS dans config.php" ];

// 4. Paramètres encore « par défaut » ?
$etapes[] = [ strpos(DB_NAME, 'u000000000') === false, 'Nom de base de données personnalisé', strpos(DB_NAME, 'u000000000') !== false ? '⛔ Remplacez u000000000_staros par votre vrai nom de base (hPanel → Bases de données MySQL).' : '' ];
$etapes[] = [ strpos(STAR_NOTIFY_EMAIL, 'votre-email') === false, 'E-mail de notification personnalisé', strpos(STAR_NOTIFY_EMAIL, 'votre-email') !== false ? 'Conseillé : mettez votre vraie adresse e-mail dans config.php pour recevoir les commandes par mail.' : '' ];

// 5. HTTPS actif ?
$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
$etapes[] = [ true, 'HTTPS (cadenas sécurisé)', $https ? '✅ Actif' : "Pas encore actif — activez le SSL gratuit : hPanel → Sécurité → SSL. (Bloquant seulement si vous activez la redirection forcée du .htaccess racine)" ];

// 6. Écriture envoi mail
$etapes[] = [ true, 'Fonction e-mail PHP', function_exists('mail') ? 'Disponible' : 'Non disponible chez cet hébergeur — les alertes e-mail seront désactivées, le reste fonctionne.' ];

// 7. Paiement MTN Money (OpenPay) configuré ?
$payOk = defined('OPENPAY_API_KEY') && OPENPAY_API_KEY !== '' && strpos(OPENPAY_API_KEY, 'METTEZ') === false;
$etapes[] = [ true, '💰 Paiement MTN Money (OpenPay)', $payOk
    ? 'Clé API présente — mode « ' . OPENPAY_MODE . ' ». Testez : /api/star-pay?ping=1'
    : 'Pas de clé — collez votre clé OpenPay dans config.php (OPENPAY_API_KEY) pour activer les paiements.' ];

// 8. E-mail via Brevo configuré ?
$brevoOk = defined('BREVO_API_KEY') && BREVO_API_KEY !== '' && strpos(BREVO_API_KEY, 'METTEZ') === false;
$etapes[] = [ true, '✉️ E-mails via Brevo', $brevoOk
    ? 'Clé Brevo présente — les alertes partiront via l\'API Brevo vers ' . STAR_NOTIFY_EMAIL
    : 'Pas de clé Brevo — ajoutez BREVO_API_KEY dans config.php (compte gratuit sur brevo.com). Sans cela, le secours mail() est utilisé s\'il existe.' ];

// 9. Vérification VIVANTE du compte Brevo (simple lecture, aucun envoi)
if ($brevoOk && function_exists('curl_init')) {
    $ch = curl_init('https://api.brevo.com/v3/account');
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_HTTPHEADER => ['api-key: ' . BREVO_API_KEY], CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_TIMEOUT => 15]);
    $resAcc = curl_exec($ch); $codeAcc = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    $acc = json_decode((string)$resAcc, true);
    $quota = '';
    if (is_array($acc) && !empty($acc['plan'][0]['credits'])) $quota = ' · quota : ' . (int)$acc['plan'][0]['credits'] . ' e-mails/jour';
    $etapes[] = [ $codeAcc === 200, 'Compte Brevo joignable', $codeAcc === 200
        ? 'Le compte répond ✔' . $quota . ' — expéditeur : ' . (string)($acc['email'] ?? BREVO_SENDER_EMAIL)
        : "Brevo répond HTTP $codeAcc — la clé est peut-être invalide, les alertes passeront par le secours mail()." ];
}

// 10. Domaine actuel (rappel : appels même-domaine = aucun réglage CORS)
$etapes[] = [ true, 'Domaine de ce backend', htmlspecialchars($_SERVER['HTTP_HOST'] ?? '?') . ' — site et backend vivent ici ensemble : aucun réglage CORS nécessaire ✔' ];

$toutBon = !in_array(false, array_column($etapes, 0), true) && $dbOk;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Installation — STAR OS</title>
<style>
 body{font-family:system-ui,sans-serif;background:#0a0e1a;color:#eef1f8;display:flex;justify-content:center;padding:40px 20px}
 .box{max-width:620px;width:100%;background:#121a30;border:1px solid #223058;border-radius:16px;padding:36px}
 h1{font-size:22px;margin-bottom:6px} h1 span{color:#f5b301}
 p.sub{color:#93a0c2;font-size:13.5px;margin-bottom:26px}
 .step{display:flex;gap:12px;padding:13px 15px;border-radius:10px;margin-bottom:10px;background:#0d1428;border:1px solid #1c2750;font-size:14px;align-items:flex-start}
 .step.ok{border-color:rgba(61,220,151,.35)} .step.ko{border-color:rgba(255,107,107,.5)}
 .step .i{font-size:17px} .step small{display:block;color:#93a0c2;margin-top:3px;line-height:1.5}
 .final{text-align:center;padding:22px;border-radius:12px;margin-top:22px;font-size:15px;line-height:1.7}
 .final.ok{background:rgba(61,220,151,.08);border:1px solid rgba(61,220,151,.4)}
 .final.ko{background:rgba(255,159,67,.08);border:1px solid rgba(255,159,67,.4)}
 .final a{color:#ffd75e}
 code{background:#0d1428;padding:2px 8px;border-radius:6px;font-size:13px}
</style>
</head>
<body>
<div class="box">
    <h1>Installation <span>STAR OS</span></h1>
    <p class="sub">Vérification automatique de votre backend — version <?= STAR_BACKEND_VERSION ?></p>

    <?php foreach ($etapes as $etape): [$ok, $label, $info] = $etape; ?>
        <div class="step <?= $ok ? 'ok' : 'ko' ?>">
            <span class="i"><?= $ok ? '✅' : '❌' ?></span>
            <div><?= htmlspecialchars($label) ?>
            <?php if ($info): ?><small><?= htmlspecialchars($info) ?></small><?php endif; ?></div>
        </div>
    <?php endforeach; ?>

    <!-- 📨 TEST RÉEL D'ENVOI D'E-MAIL -->
    <div class="step <?= $testMail ? ($testMail[0] === 'ok' ? 'ok' : 'ko') : '' ?>" style="display:block">
        <strong>📨 Test d'envoi d'e-mail RÉEL</strong>
        <small>Entrez votre mot de passe admin (celui de /admin/ : <code>Good24</code> d'origine) puis cliquez. Un vrai e-mail partira vers <code><?= htmlspecialchars(STAR_NOTIFY_EMAIL) ?></code>.</small>
        <form method="post" style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap">
            <input type="hidden" name="action" value="test_mail">
            <input type="password" name="mdp" placeholder="Mot de passe admin" required
                   style="flex:1;min-width:180px;padding:10px 12px;border-radius:8px;border:1px solid #223058;background:#0d1428;color:#eef1f8">
            <button type="submit" style="padding:10px 18px;border:none;border-radius:8px;background:#f5b301;color:#0a0e1a;font-weight:700;cursor:pointer">
                📨 Envoyer l'e-mail de test
            </button>
        </form>
        <?php if ($testMail): ?><small style="margin-top:10px;display:block"><?= htmlspecialchars($testMail[1]) ?></small><?php endif; ?>
    </div>

    <div class="final <?= $toutBon ? 'ok' : 'ko' ?>">
        <?php if ($toutBon): ?>
            🎉 <strong>Tout est prêt !</strong><br>
            🔎 Vérifications instantanées : <a href="api/star-os?ping=1" target="_blank">ping messages</a> · <a href="api/star-pay?ping=1" target="_blank">ping paiement</a><br>
            1️⃣ <a href="admin/">Connectez-vous à l'administration</a> (admin / Good24)<br>
            2️⃣ Dans l'admin, cliquez « ⚡ Tester la connexion » puis changez votre mot de passe<br>
            3️⃣ Test réel client : ouvrez votre site, envoyez un message → il apparaît dans « Demandes » + e-mail reçu<br>
            4️⃣ Test paiement : <a href="paiement-test.html" target="_blank">/paiement-test.html</a> → payez 100 FCFA avec un téléphone MTN<br>
            5️⃣ <strong>Supprimez le fichier <code>install.php</code></strong> par sécurité
        <?php else: ?>
            ⚠️ <strong>Quelques réglages restent à faire.</strong><br>
            Corrigez les lignes ❌ ci-dessus dans <code>config.php</code>, puis rechargez cette page.
        <?php endif; ?>
    </div>
</div>
</body>
</html>
