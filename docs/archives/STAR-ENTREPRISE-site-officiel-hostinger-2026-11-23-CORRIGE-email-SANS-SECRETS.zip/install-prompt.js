/* STAR ENTREPRISE — Invitation d'installation (PWA)
 * ------------------------------------------------------------------
 * Affiche une proposition "Installer l'application" sur toutes les pages.
 *
 * Timing demandé (mis à jour) :
 *   - Apparaît 5 secondes après que l'IA Sarah s'affiche (Sarah apparaît
 *     à t=4s → l'invitation apparaît à t=9s après le chargement).
 *   - Reste visible 10 secondes, puis disparaît.
 *   - Réapparaît 5 minutes après, disparaît après 10 s, et ainsi de suite.
 *
 * Détection de l'appareil :
 *   - Android/Chrome : utilise l'événement beforeinstallprompt pour
 *     installer directement la version adaptée.
 *   - iPhone/iOS : affiche des instructions (Partager → Ajouter à
 *     l'écran d'accueil) car iOS ne propose pas beforeinstallprompt.
 *   - Desktop : affiche aussi la proposition (installe sur Windows/Mac).
 *
 * Ne modifie AUCUN autre comportement du site.
 */
(function () {
  'use strict';

  var IA_DELAY = 4000;            // durée avant l'apparition de l'IA Sarah (t=4s)
  var SHOW_AFTER_IA = 5000;       // invitation 5s APRÈS l'IA → première apparition à t=9s
  var VISIBLE_MS = 10000;         // reste visible 10 secondes
  var PAUSE_MS = 5 * 60 * 1000;   // puis 5 minutes de pause avant la réapparition

  var deferredPrompt = null;   // l'événement beforeinstallprompt Android
  var promptShown = false;

  // Détection du type d'appareil
  function detectDevice() {
    var ua = navigator.userAgent || '';
    var isIOS = /iphone|ipad|ipod/i.test(ua);
    var isAndroid = /android/i.test(ua);
    var isStandalone = window.matchMedia('(display-mode: standalone)').matches;
    var isInstalled = isStandalone ||
      (window.navigator.standalone === true) ||
      (window.matchMedia && window.matchMedia('(display-mode: window-controls-overlay)').matches);
    return {
      isIOS: isIOS,
      isAndroid: isAndroid,
      isMobile: isIOS || isAndroid,
      isInstalled: isInstalled
    };
  }

  // Crée le conteneur de la proposition (une seule fois)
  function getPromptEl() {
    var el = document.getElementById('star-install-prompt');
    if (el) return el;

    var dev = detectDevice();
    var wrap = document.createElement('div');
    wrap.id = 'star-install-prompt';
    wrap.setAttribute('role', 'dialog');
    wrap.setAttribute('aria-label', "Installer l'application STAR ENTREPRISE");
    wrap.style.cssText =
      'position:fixed;left:50%;bottom:20px;transform:translateX(-50%);z-index:500000;' +
      'background:linear-gradient(135deg,#0B1F3A,#123361);color:#fff;border:1px solid #D4AF37;' +
      'border-radius:16px;padding:16px 18px;max-width:360px;width:calc(100% - 32px);' +
      'box-shadow:0 20px 50px rgba(0,0,0,.55);font-family:Manrope,sans-serif;display:none;' +
      'text-align:left;';

    var title = '📱 Installer STAR ENTREPRISE';
    var message = 'Installez l\'application pour un accès rapide, hors ligne et direct depuis votre téléphone.';
    if (dev.isIOS) {
      message = 'Touchez l\'icône <b style="color:#D4AF37;">Partager</b> (carré avec une flèche ↑) puis choisissez <b style="color:#D4AF37;">"Ajouter à l\'écran d\'accueil"</b> pour installer l\'application.';
    } else if (dev.isAndroid) {
      message = 'Installez l\'application STAR ENTREPRISE pour un accès rapide et hors ligne depuis votre téléphone.';
    }

    wrap.innerHTML =
      '<div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;">' +
        '<div style="width:40px;height:40px;border-radius:10px;flex-shrink:0;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#D4AF37,#C59B27);color:#0B1F3A;font-size:20px;">★</div>' +
        '<div><div style="font-weight:800;font-size:14.5px;color:#E8CD7A;">' + title + '</div>' +
        '<div style="font-size:12px;color:#B9C2D6;">Application officielle</div></div>' +
      '</div>' +
      '<div style="font-size:13px;color:#CBD5E1;line-height:1.5;margin-bottom:14px;">' + message + '</div>' +
      '<div style="display:flex;gap:10px;">' +
        (dev.isAndroid || !dev.isMobile
          ? '<button id="star-install-btn" style="flex:1;background:linear-gradient(135deg,#D4AF37,#C59B27);color:#0B1F3A;font-weight:800;font-size:13px;padding:11px 0;border:none;border-radius:10px;cursor:pointer;">Installer</button>'
          : '') +
        '<button id="star-install-later" style="flex:1;background:rgba(255,255,255,.1);color:#fff;font-weight:700;font-size:13px;padding:11px 0;border:1px solid rgba(255,255,255,.2);border-radius:10px;cursor:pointer;">Plus tard</button>' +
      '</div>';

    document.body.appendChild(wrap);

    // Bouton "Plus tard" : masque la proposition (le cycle reprendra)
    var later = document.getElementById('star-install-later');
    if (later) {
      later.addEventListener('click', function () {
        wrap.style.display = 'none';
        // Mémorise le choix pour ne pas harceler le visiteur à chaque cycle
        try { sessionStorage.setItem('starInstallDismissed', '1'); } catch (e) {}
      });
    }

    // Bouton "Installer" (Android/Desktop)
    var installBtn = document.getElementById('star-install-btn');
    if (installBtn) {
      installBtn.addEventListener('click', function () {
        if (deferredPrompt) {
          deferredPrompt.prompt();
          deferredPrompt.userChoice.then(function () {
            deferredPrompt = null;
          });
        } else if (dev.isIOS) {
          // Instructions iOS déjà affichées dans le message
          wrap.style.display = 'none';
        }
      });
    }

    return wrap;
  }

  // Vérifie si la fenêtre de discussion de Sarah est ouverte
  function sarahEstOuverte() {
    var m = document.getElementById('sarah-modal');
    return !!(m && m.classList.contains('sarah-open'));
  }

  // Affiche la proposition
  function showPrompt() {
    var el = getPromptEl();
    if (!el) return;
    // Ne pas réafficher si l'app est déjà installée
    if (detectDevice().isInstalled) return;
    // Ne pas réafficher si le visiteur a cliqué « Plus tard » durant cette session
    try { if (sessionStorage.getItem('starInstallDismissed') === '1') return; } catch (e) {}
    // RÈGLE D'OR : jamais par-dessus la conversation de Sarah
    if (sarahEstOuverte()) return;
    promptShown = true;
    el.style.display = 'block';
  }

  // Masque la proposition
  function hidePrompt() {
    var el = getPromptEl();
    if (el) el.style.display = 'none';
  }

  // Capture l'événement beforeinstallprompt (Android / Chrome)
  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
    deferredPrompt = e;
    // Si la proposition est visible, le bouton Installer peut utiliser l'événement
  });

  // Si l'application est déjà installée, ne rien afficher
  if (detectDevice().isInstalled) {
    return;
  }

  // Quand Sarah s'ouvre, la bannière s'efface aussitôt pour laisser la place au chat.
  // Quand Sarah se ferme, rien ne change (pas de réaffichage intempestif).
  function watchSarah() {
    var sarahModal = document.getElementById('sarah-modal');
    if (!sarahModal) return;
    if (window.MutationObserver) {
      new MutationObserver(function () {
        if (sarahModal.classList.contains('sarah-open')) {
          hidePrompt();
        }
      }).observe(sarahModal, { attributes: true, attributeFilter: ['class'] });
    }
    // Clic direct sur le bouton Sarah : masque la bannière immédiatement
    var sarahBtn = document.getElementById('sarah-btn');
    if (sarahBtn) sarahBtn.addEventListener('click', hidePrompt);
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', watchSarah);
  } else {
    // Le script est « defer » : le DOM est déjà prêt, mais Sarah peut
    // être créée une frame plus tard → on patiente un court instant.
    setTimeout(watchSarah, 800);
  }

  // Cycle temporel (nouveau) :
  //  - à (IA_DELAY + SHOW_AFTER_IA) = 9s : afficher
  //  - après 10 s : masquer
  //  - après 5 min de pause : réafficher 10 s, et ainsi de suite
  function cycleInvite() {
    showPrompt();                                   // apparaît
    setTimeout(hidePrompt, VISIBLE_MS);             // disparaît après 10 s
    setTimeout(cycleInvite, VISIBLE_MS + PAUSE_MS); // revient après la pause de 5 min
  }
  setTimeout(cycleInvite, IA_DELAY + SHOW_AFTER_IA);
})();
