/* ====================================================================
 * STAR PAIEMENT — Paiement MTN Money via OpenPay (star-paiement.js)
 * --------------------------------------------------------------------
 *  Une seule fonction à appeler depuis n'importe quelle page du site :
 *
 *      starPaiement({
 *          montant : 150000,
 *          article : 'Œuvre « Regards croisés »',
 *          client  : 'Nom du client'      (optionnel),
 *          telephone : '065556789'        (optionnel, pré-rempli)
 *      });
 *
 *  Le client reçoit une demande de paiement sur SON téléphone MTN,
 *  valide avec son code secret, et votre tableau de bord /admin/
 *  affiche « 💰 PAIEMENT REÇU » en direct.
 * ====================== NE RIEN MODIFIER CI-DESSOUS ============== */
(function () {
    'use strict';

    var STAR_PAY_API_KEY = 'star-os-live-2026-secret-key'; // identique à star-backend-bridge.js
    var ENDPOINTS = ['/api/star-pay', '/backend/paiement.php', 'backend/paiement.php', '../backend/paiement.php'];

    // ------------------------------ STYLE ------------------------------
    function injecterStyle() {
        if (document.getElementById('star-pay-style')) return;
        var st = document.createElement('style');
        st.id = 'star-pay-style';
        st.textContent =
'#stp-overlay{position:fixed;inset:0;background:rgba(10,22,40,.62);backdrop-filter:blur(4px);z-index:99990;display:flex;align-items:center;justify-content:center;padding:16px;font-family:\'Inter\',system-ui,sans-serif}' +
'#stp-overlay .stp-card{background:#fff;border-radius:22px;width:100%;max-width:440px;box-shadow:0 30px 80px rgba(10,22,40,.45);overflow:hidden;animation:stpIn .28s ease}' +
'@keyframes stpIn{from{transform:translateY(26px);opacity:0}to{transform:none;opacity:1}}' +
'#stp-overlay .stp-head{background:linear-gradient(135deg,#0B1F3A,#132c52);color:#fff;padding:20px 24px;display:flex;align-items:center;gap:14px}' +
'#stp-overlay .stp-badge{width:46px;height:46px;border-radius:12px;background:#FFCC00;color:#1a1a1a;font-weight:900;display:flex;align-items:center;justify-content:center;font-size:13px;letter-spacing:.02em;flex:none}' +
'#stp-overlay .stp-head h3{margin:0;font-size:17px;font-weight:800}' +
'#stp-overlay .stp-head p{margin:2px 0 0;font-size:12px;opacity:.75}' +
'#stp-overlay .stp-body{padding:22px 24px}' +
'#stp-overlay .stp-amount{background:#F8F5EC;border:1px solid #EAD98B;border-radius:14px;padding:14px 16px;margin-bottom:16px}' +
'#stp-overlay .stp-amt-l{font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:#8a6d1d;font-weight:700}' +
'#stp-overlay .stp-amt-v{font-size:26px;font-weight:900;color:#0B1F3A}' +
'#stp-overlay .stp-amt-a{font-size:12.5px;color:#64748B;margin-top:2px}' +
'#stp-overlay label{display:block;font-size:12.5px;font-weight:700;color:#334155;margin:0 0 6px}' +
'#stp-overlay .stp-tel-wrap{display:flex;align-items:center;border:2px solid #E2E8F0;border-radius:12px;overflow:hidden;transition:.15s;background:#fff}' +
'#stp-overlay .stp-tel-wrap:focus-within{border-color:#0B1F3A;box-shadow:0 0 0 3px rgba(11,31,58,.12)}' +
'#stp-overlay .stp-prefix{padding:13px 10px 13px 14px;font-weight:800;color:#0B1F3A;background:#F1F5F9;border-right:1px solid #E2E8F0;white-space:nowrap;font-size:15px}' +
'#stp-overlay input{border:none;outline:none;padding:13px 14px;font-size:16px;width:100%;font-family:inherit}' +
'#stp-overlay .stp-help{font-size:11.5px;color:#94A3B8;margin-top:6px}' +
'#stp-overlay .stp-btn{width:100%;margin-top:18px;border:none;border-radius:12px;padding:15px;font-size:15px;font-weight:800;cursor:pointer;font-family:inherit;background:linear-gradient(135deg,#F2C31B,#D4A017);color:#1a1a1a;transition:.15s}' +
'#stp-overlay .stp-btn:hover{transform:translateY(-1px);box-shadow:0 10px 22px rgba(212,160,23,.35)}' +
'#stp-overlay .stp-btn:disabled{opacity:.5;cursor:not-allowed;transform:none;box-shadow:none}' +
'#stp-overlay .stp-cancel{display:block;width:100%;text-align:center;margin-top:12px;background:none;border:none;color:#94A3B8;font-size:13px;cursor:pointer;font-family:inherit}' +
'#stp-overlay .stp-cancel:hover{color:#0B1F3A}' +
'#stp-overlay .stp-erreur{background:#FEF2F2;border:1px solid #FECACA;color:#B91C1C;border-radius:10px;padding:10px 12px;font-size:13px;margin-top:14px;display:none}' +
'#stp-overlay .stp-secure{text-align:center;font-size:11px;color:#94A3B8;margin-top:14px}' +
'#stp-overlay .stp-wait{text-align:center;padding:8px 0 2px}' +
'#stp-overlay .stp-phone-ico{font-size:44px;animation:stpPulse 1.4s infinite}' +
'@keyframes stpPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.15)}}' +
'#stp-overlay .stp-wait h4{margin:14px 0 6px;font-size:16.5px;color:#0B1F3A}' +
'#stp-overlay .stp-wait p{font-size:13.5px;color:#64748B;line-height:1.55;margin:0}' +
'#stp-overlay .stp-wait code{background:#F1F5F9;border-radius:8px;padding:3px 9px;font-weight:700;color:#0B1F3A}' +
'#stp-overlay .stp-ok-ico{width:66px;height:66px;border-radius:50%;margin:6px auto 4px;display:flex;align-items:center;justify-content:center;font-size:32px;color:#fff;background:#16A34A;animation:stpPop .35s ease}' +
'#stp-overlay .stp-ko-ico{width:66px;height:66px;border-radius:50%;margin:6px auto 4px;display:flex;align-items:center;justify-content:center;font-size:30px;color:#fff;background:#DC2626;animation:stpPop .35s ease}' +
'@keyframes stpPop{from{transform:scale(.4);opacity:0}to{transform:none;opacity:1}}' +
'#stp-overlay .stp-ref{margin-top:10px;font-size:12px;color:#64748B}' +
'#stp-overlay .stp-ref b{color:#0B1F3A}';
        document.head.appendChild(st);
    }

    // --------------------------- UTILITAIRES ---------------------------
    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }
    function fcfa(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' FCFA'; }

    function api(action, payload, cb) {
        var i = 0;
        function essayer() {
            if (i >= ENDPOINTS.length) { cb(null, new Error('serveur injoignable')); return; }
            var url = ENDPOINTS[i++];
            var corps = { action: action, api_key: STAR_PAY_API_KEY };
            if (action === 'pay_start') corps.data = payload;
            else corps.reference = payload.reference;
            fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(corps)
            }).then(function (r) { return r.json(); })
              .then(function (j) { if (j && j.error === 'action_inconnue' && i < ENDPOINTS.length) essayer(); else cb(j); })
              .catch(function () { essayer(); });
        }
        essayer();
    }

    // ------------------------------ MODALE ------------------------------
    window.starPaiement = function (options) {
        injecterStyle();
        var o = options || {};
        var montant = parseInt(String(o.montant).replace(/[^0-9]/g, ''), 10) || 0;
        var article = o.article || 'Achat site web';
        if (montant < 100) { alert('Montant de paiement invalide.'); return; }

        var ancienne = document.getElementById('stp-overlay');
        if (ancienne) ancienne.remove();

        var ov = document.createElement('div');
        ov.id = 'stp-overlay';
        ov.innerHTML =
            '<div class="stp-card" role="dialog" aria-modal="true">' +
            '  <div class="stp-head">' +
            '    <div class="stp-badge">MTN<br>MoMo</div>' +
            '    <div><h3>Paiement MTN Money</h3><p>CARRY-O AFRIQUE · sécurisé par OpenPay</p></div>' +
            '  </div>' +
            '  <div class="stp-body" id="stp-body"></div>' +
            '</div>';
        document.body.appendChild(ov);
        document.body.style.overflow = 'hidden';

        var body = ov.querySelector('#stp-body');
        var pollTimer = null;

        function fermer() {
            if (pollTimer) { clearTimeout(pollTimer); pollTimer = null; }
            ov.remove(); document.body.style.overflow = '';
        }
        ov.addEventListener('click', function (e) { if (e.target === ov) fermer(); });

        // ------------------------- ÉTAPE 1 : SAISIE -------------------------
        body.innerHTML =
            '<div class="stp-amount"><div class="stp-amt-l">Montant à payer</div>' +
            '<div class="stp-amt-v">' + esc(fcfa(montant)) + '</div>' +
            '<div class="stp-amt-a">' + esc(article) + '</div></div>' +
            '<label for="stp-tel">Votre numéro MTN Money *</label>' +
            '<div class="stp-tel-wrap"><span class="stp-prefix">+242</span>' +
            '<input type="tel" id="stp-tel" inputmode="numeric" autocomplete="tel" placeholder="06 555 12 34" maxlength="14" value="' + esc(o.telephone || '') + '"></div>' +
            '<div class="stp-help">Une demande de paiement sera envoyée sur ce numéro — composez votre code secret MTN pour valider.</div>' +
            '<div class="stp-erreur" id="stp-err"></div>' +
            '<button class="stp-btn" id="stp-go">Payer ' + esc(fcfa(montant)) + ' →</button>' +
            '<button class="stp-cancel" type="button" id="stp-x">Annuler</button>' +
            '<div class="stp-secure">🔒 Transaction chiffrée · OpenPay · Aucun frais caché</div>';

        var telEl = body.querySelector('#stp-tel');
        var errEl = body.querySelector('#stp-err');
        var goEl = body.querySelector('#stp-go');
        telEl.focus();
        body.querySelector('#stp-x').onclick = fermer;

        function erreur(m) { errEl.style.display = 'block'; errEl.textContent = m; goEl.disabled = false; }

        goEl.onclick = function () {
            errEl.style.display = 'none';
            var tel = telEl.value.replace(/[^0-9+]/g, '');
            if (tel.replace(/[^0-9]/g, '').length < 8) { erreur('Entrez un numéro MTN Money valide (ex. 06 555 12 34).'); return; }
            goEl.disabled = true;
            etapeAttente();
            api('pay_start', {
                montant: montant, article: article,
                client: o.client || '', telephone: tel,
                ville: o.ville || '', page: o.page || location.pathname.split('/').pop(),
                metadata: { origine: 'star-paiement.js' }
            }, function (rep, err) {
                if (err || !rep) { etapeEchec('Le serveur de paiement ne répond pas. Vérifiez votre connexion et réessayez.'); return; }
                if (!rep.ok) { etapeEchec(rep.message || 'Le paiement n\'a pas pu être lancé.'); return; }
                if (rep.statut === 'succes') { etapeSucces(rep); return; }
                if (rep.statut === 'echec') { etapeEchec(rep.message || 'Paiement refusé (solde insuffisant ou numéro invalide).'); return; }
                // attente → on surveille la validation
                surveiller(rep.reference, 0);
            });
        };

        // ----------------------- ÉTAPE 2 : ATTENTE -----------------------
        function etapeAttente() {
            body.innerHTML =
                '<div class="stp-wait"><div class="stp-phone-ico">📱</div>' +
                '<h4>Validez sur votre téléphone MTN…</h4>' +
                '<p>Une demande de <b>' + esc(fcfa(montant)) + '</b> vient d\'être envoyée.<br>' +
                'Composez votre <code>code secret MTN Money</code> pour confirmer.<br><br>' +
                '⏳ Cette fenêtre se fermera toute seule après validation…</p></div>' +
                '<button class="stp-cancel" type="button" id="stp-x">Annuler la surveillance (le paiement reste enregistré)</button>';
            body.querySelector('#stp-x').onclick = fermer;
        }

        function surveiller(ref, essais) {
            if (pollTimer) clearTimeout(pollTimer);
            if (essais > 40) { etapeEchec('Temps d\'attente dépassé. Si vous avez validé, votre paiement apparaîtra quand même dans nos registres — appelez-nous au +242 06 656 50 50.', ref); return; }
            pollTimer = setTimeout(function () {
                api('pay_status', { reference: ref }, function (rep) {
                    if (rep && rep.ok && rep.payment) {
                        if (rep.payment.statut === 'succes') { etapeSucces({ reference: ref, montant: rep.payment.montant, article: rep.payment.article, client: rep.payment.client, telephone: rep.payment.telephone, event_enregistre: !!rep.payment.event_enregistre }); return; }
                        if (rep.payment.statut === 'echec') { etapeEchec('Le paiement a été refusé ou a expiré.'); return; }
                    }
                    surveiller(ref, essais + 1);
                });
            }, 4000);
        }

        // ----------------------- ÉTAPE 3 : RÉSULTAT -----------------------
        function etapeSucces(rep) {
            if (pollTimer) { clearTimeout(pollTimer); pollTimer = null; }
            body.innerHTML =
                '<div class="stp-wait"><div class="stp-ok-ico">✔</div>' +
                '<h4>Paiement confirmé !</h4>' +
                '<p>🎉 Merci ! Votre paiement de <b>' + esc(fcfa(montant)) + '</b> a bien été reçu.<br>' +
                'La galerie CARRY-O AFRIQUE a été notifiée instantanément.</p>' +
                (rep.reference ? '<div class="stp-ref">Référence : <b>' + esc(rep.reference) + '</b></div>' : '') +
                '</div>' +
                '<button class="stp-btn" id="stp-f">Terminer ✔</button>';
            body.querySelector('#stp-f').onclick = fermer;
            if (typeof o.onSucces === 'function') { try { o.onSucces(rep); } catch (e) {} }
            try { document.dispatchEvent(new CustomEvent('star-paiement-succes', { detail: rep })); } catch (e) {}
        }

        function etapeEchec(msg, ref) {
            if (pollTimer) { clearTimeout(pollTimer); pollTimer = null; }
            body.innerHTML =
                '<div class="stp-wait"><div class="stp-ko-ico">✖</div>' +
                '<h4>Paiement non abouti</h4>' +
                '<p>' + esc(msg) + '</p>' +
                (ref ? '<div class="stp-ref">Référence : <b>' + esc(ref) + '</b></div>' : '') +
                '</div>' +
                '<button class="stp-btn" id="stp-r">↻ Réessayer</button>' +
                '<button class="stp-cancel" type="button" id="stp-x">Fermer</button>';
            body.querySelector('#stp-r').onclick = fermerToutEtRouvrir;
            body.querySelector('#stp-x').onclick = fermer;
        }

        function fermerToutEtRouvrir() { fermer(); window.starPaiement(o); }
    };
})();
