/* ====================================================================
 * STAR PAIEMENT LIBRE — petite extension au-dessus de star-paiement.js
 * --------------------------------------------------------------------
 * Ne modifie JAMAIS star-paiement.js (fichier verrouillé, testé 118/118).
 * Ce fichier ajoute uniquement la possibilité de demander un montant
 * libre (devis, acompte, don) avant d'ouvrir la même fenêtre de
 * paiement MTN Money déjà utilisée pour le livre et les œuvres —
 * un seul et même canal de paiement pour tout le site.
 *
 *  Utilisation :
 *      starPaiementLibre({
 *          article : 'STAR EXPRESS — Paiement en ligne',
 *          presets : [5000, 10000, 20000]   (optionnel)
 *      });
 * ==================================================================== */
(function () {
    'use strict';

    window.starPaiementLibre = function (options) {
        if (typeof window.starPaiement !== 'function') {
            alert('Le module de paiement est en cours de chargement, réessayez dans un instant.');
            return;
        }
        var o = options || {};
        var article = o.article || 'STAR ENTREPRISE — Paiement en ligne';
        var page = o.page || location.pathname.split('/').pop();
        var presets = o.presets || null;

        var suggestion = presets && presets.length
            ? '\nMontants suggérés : ' + presets.map(function (p) { return p + ' FCFA'; }).join(' / ')
            : '';
        var defaut = presets && presets.length ? String(presets[0]) : '';

        var saisie = window.prompt('Montant à payer pour « ' + article + ' » (en FCFA)' + suggestion, defaut);
        if (saisie === null) return; // annulé par le client

        var montant = parseInt(String(saisie).replace(/[^0-9]/g, ''), 10) || 0;
        if (montant < 100) {
            alert('Merci d’indiquer un montant valide (minimum 100 FCFA).');
            return;
        }
        window.starPaiement({ montant: montant, article: article, page: page });
    };
})();
