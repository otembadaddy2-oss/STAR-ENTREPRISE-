<?php
/**
 * ============================================================
 *  STAR OS — PAIEMENT MOBILE MONEY (OpenPay → MTN Money)
 * ============================================================
 *  Ce fichier est appelé par le site web (star-paiement.js) quand
 *  un client paye une œuvre CARRY-O AFRIQUE (ou tout autre achat).
 *
 *  🔐 SÉCURITÉ : la clé API OpenPay ne quitte JAMAIS ce fichier —
 *     elle n'est jamais envoyée au navigateur (doc officielle OpenPay).
 *
 *  Actions publiques (avec la clé STAR_API_KEY du site) :
 *    - pay_start   : lance un paiement MTN Money
 *    - pay_status  : vérifie l'état d'un paiement (référence)
 *    - ping        : test de vie
 *
 *  Jolie URL site : /api/star-pay  (voir .htaccess)
 * ============================================================
 */

require_once __DIR__ . '/db.php';

star_cors();

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// ---- PING PUBLIC (le site vérifie que le module de paiement tourne) ----
if ($method === 'GET' && isset($_GET['ping'])) {
    star_json_ok([
        'service'  => 'STAR PAIEMENT',
        'version'  => '1.0',
        'provider' => 'MTN Money',
        'mode'     => 'live (paiements réels uniquement — aucune simulation)',
        'cle_live' => OPENPAY_API_KEY !== '' && strpos(OPENPAY_API_KEY, 'METTEZ') === false ? 'configurée' : 'ABSENTE',
        'time'     => date('c'),
    ]);
}

$in     = ($method === 'POST') ? star_read_json_body() : $_GET;
$action = strtolower(trim((string)($in['action'] ?? '')));

// Clé du site obligatoire pour toutes les actions
if ($action === 'pay_start' || $action === 'pay_status') {
    star_require_api_key();
} else {
    star_json_error('action_inconnue', "Action « $action » inconnue.", 404);
}

$db = star_db();

// ============================================================
//  pay_status — le site interroge l'état d'un paiement
// ============================================================
if ($action === 'pay_status') {
    $ref = star_cut($in['reference'] ?? $in['ref'] ?? '', 60);
    if ($ref === '') star_json_error('reference_requise', 'Référence du paiement requise.');
    $stmt = $db->prepare("SELECT reference, article, montant, telephone, statut, mode, created_at FROM star_paiements WHERE reference = ? LIMIT 1");
    $stmt->bind_param('s', $ref); $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc(); $stmt->close();
    if (!$row) star_json_error('introuvable', 'Paiement inconnu.', 404);
    $row['event_enregistre'] = true; // ce paiement est en base → pas besoin d'alarme de secours côté site
    star_json_ok(['payment' => $row]);
}

// ============================================================
//  pay_start — lancement d'un paiement MTN Money
// ============================================================
star_rate_limit();

$d = $in['data'] ?? $in;               // accepte { data: {...} } ou directement le plat
if (is_string($d)) { $decoded = json_decode($d, true); $d = is_array($decoded) ? $decoded : []; }
if (!is_array($d)) $d = [];

// ---- Lecture & validation des champs ----
$article = star_cut($d['article'] ?? $d['title'] ?? 'Achat site web', 180);
$montant = (int)preg_replace('/[^0-9]/', '', (string)($d['montant'] ?? $d['amount'] ?? '0'));
$client  = star_cut($d['client'] ?? $d['nom'] ?? $d['name'] ?? '', 180);
$ville   = star_cut($d['ville'] ?? $d['city'] ?? '', 110);
$tel     = star_normaliser_tel((string)($d['telephone'] ?? $d['phone'] ?? $d['payment_phone_number'] ?? ''));
$page    = star_cut($d['page'] ?? '', 250);
$meta    = '';
if (isset($d['metadata']) && is_array($d['metadata'])) {
    $meta = star_cut(json_encode($d['metadata'], JSON_UNESCAPED_UNICODE), 900);
}

if ($montant < 100 || $montant > 99999999) {
    star_json_error('montant_invalide', 'Le montant doit être compris entre 100 et 99 999 999 FCFA.');
}
if ($tel === null) {
    star_json_error('telephone_invalide', 'Numéro MTN Money invalide. Exemples valides : 06 555 12 34, 05 123 45 67, +242 06 …');
}
if ($client === '') $client = 'Client Site Web';

// ============================================================
//  🔒 CATALOGUE SERVEUR — le montant DOIT correspondre au prix officiel
//  ------------------------------------------------------------
//  C'est LE verrou demandé : aucun achat n'est possible avec un montant
//  différent du prix affiché sur le site. Le SERVEUR fait foi, jamais le
//  navigateur : même en falsifiant la requête, le montant est refusé
//  (403) et aucun paiement n'est lancé.
// ============================================================
$prixCatalogue = star_prix_catalogue($article);
if ($prixCatalogue === null) {
    star_json_error('article_inconnu', 'Article non reconnu par le catalogue officiel du site. Achat refusé.', 403);
}
if ($montant !== $prixCatalogue) {
    star_json_error('montant_non_conforme',
        'Montant refusé : le prix officiel de cet article est de ' . number_format($prixCatalogue, 0, ',', ' ') .
        ' FCFA, pas ' . number_format($montant, 0, ',', ' ') . ' FCFA. Achat bloqué.', 403);
}
$montant = $prixCatalogue;   // le serveur impose le prix, quoi qu'envoie le navigateur

$ip        = substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 60);
$reference = 'STAR-' . date('ymd-His') . '-' . strtoupper(bin2hex(random_bytes(3)));

// ============================================================
//  LIVE UNIQUEMENT — aucune simulation (pas d'e-mail fallacieux)
// ============================================================
if (OPENPAY_MODE === 'demo') {
    star_json_error('demo_desactive', 'Les paiements simulés sont désactivés. Seuls les vrais paiements MTN Money (OpenPay) sont acceptés.', 503);
}
if (OPENPAY_API_KEY === '' || strpos(OPENPAY_API_KEY, 'METTEZ') !== false) {
    star_json_error('paiement_indisponible', 'Le paiement en ligne n\'est pas encore configuré (clé OpenPay manquante dans config.php).', 503);
}
[$statut, $refOpenPay, $detailOpenPay] = star_openpay_pay($montant, $tel, $client, $reference, $article);
$mode     = 'live';
$refFinal = $refOpenPay ?: $reference;
$details  = $detailOpenPay;

// ---- Enregistrement en base ----
$stmt = $db->prepare("INSERT INTO star_paiements
    (reference, article, montant, telephone, client, provider, statut, mode, details, page, ip)
    VALUES (?,?,?,?,?, 'MTN', ?,?,?,?,?)");
$montantS = $montant;
$stmt->bind_param('ssisssssss', $refFinal, $article, $montantS, $tel, $client, $statut, $mode, $details, $page, $ip);
$stmt->execute(); $stmt->close();

// ---- Trace dans le flux d'activité STAR OS (+ CRM + e-mail) ----
$fcfa = number_format($montant, 0, ',', ' ');
if ($statut === 'succes') {
    $titre  = "💰 PAIEMENT REÇU — $article — $fcfa FCFA — $client";
    $msg    = "Montant : $fcfa FCFA (XAF)\nArticle : $article\nClient : $client\nTéléphone payeur : $tel\nRéférence : $refFinal\nMode : " . ($mode === 'demo' ? 'DÉMO (simulation)' : 'RÉEL (OpenPay/MTN)') . ($ville ? "\nVille : $ville" : '') . ($page ? "\nPage : $page" : '');
    $kind   = 'paiement';
} elseif ($statut === 'attente') {
    $titre  = "⏳ Paiement initié — $article — $fcfa FCFA — $client (en attente de validation)";
    $msg    = "Le client $client ($tel) doit valider le paiement sur son téléphone.\nRéférence : $refFinal";
    $kind   = 'paiement';
} else {
    $titre  = "❌ Paiement échoué — $article — $fcfa FCFA — $client";
    $msg    = "Le paiement n'a pas abouti.\nDétail : $details\nRéférence : $refFinal";
    $kind   = 'paiement';
}
$stmt = $db->prepare("INSERT INTO star_events (kind, title, message, client, telephone, ville, page, ip) VALUES (?,?,?,?,?,?,?,?)");
$stmt->bind_param('ssssssss', $kind, $titre, $msg, $client, $tel, $ville, $page, $ip);
$stmt->execute(); $stmt->close();

star_upsert_client($db, $client, '', $tel, $ville);
// E-mail « PAIEMENT REÇU » UNIQUEMENT si OpenPay a réellement encaissé (live + succes).
if ($statut === 'succes' && $mode === 'live') star_notify_email($titre, $msg, $client, '', $tel);

star_json_ok([
    'reference'        => $refFinal,
    'statut'           => $statut,          // succes | attente | echec
    'montant'          => $montant,
    'devise'           => 'XAF',
    'mode'             => $mode,
    'event_enregistre' => true,             // le backend a enregistré ce paiement (+ e-mail admin si succès)
    // 📖 Livre : jeton signé émis SEULEMENT après succès → déverrouille
    //    /api/telecharger-livre (preuve secondaire, la BDD suffit ici).
    'dl_token'         => $statut === 'succes'
        ? hash_hmac('sha256', $refFinal . '|livre-carryo-otemba', OPENPAY_API_KEY)
        : null,
    'message'          => $statut === 'succes'
        ? 'Paiement confirmé. Merci !'
        : ($statut === 'attente'
            ? 'Validez le paiement sur votre téléphone MTN…'
            : (trim((string)$details) !== '' ? $details : 'Le paiement a échoué.')),
        // ↑ en cas d'échec, le client voit le VRAI motif renvoyé par MTN
        //   (ex. « Solde insuffisant ») au lieu d'un message vague.
]);

// ============================================================
//  FONCTIONS DU MODULE
// ============================================================

/* star_normaliser_tel(), star_catalogue(), star_normaliser_libelle() et
   star_prix_catalogue() vivent désormais dans db.php (partagées avec
   cinetpay.php, qui doit valider les mêmes prix officiels sans dupliquer
   le catalogue une troisième fois). */

/** Appel RÉEL à l'API OpenPay — renvoie [statut(star), référenceOpenPay|null, détail] */
function star_openpay_pay(int $montant, string $tel, string $client, string $refExterne, string $article): array
{
    if (!function_exists('curl_init')) {
        return ['echec', null, 'Extension cURL absente du serveur PHP.'];
    }
    $payload = json_encode([
        'amount'               => $montant,
        'payment_phone_number' => $tel,
        'provider'             => 'MTN',
        'customer_external_id' => $refExterne,
        'customer'             => ['name' => $client, 'phone' => $tel],
        'metadata'             => ['article' => $article, 'source' => 'starentreprise.com', 'reference' => $refExterne],
    ], JSON_UNESCAPED_UNICODE);

    $ch = curl_init(OPENPAY_API_URL);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTPHEADER     => [
            'XO-API-KEY: ' . OPENPAY_API_KEY,
            'Content-Type: application/json',
            'Accept: application/json',
        ],
        CURLOPT_CONNECTTIMEOUT => 15,
        // Généreux : MTN peut attendre la validation du client sur son téléphone
        CURLOPT_TIMEOUT        => 75,
    ]);
    $body = curl_exec($ch);
    $err  = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($body === false) return ['echec', null, "Réseau indisponible ($err). Réessayez."];

    $json = json_decode((string)$body, true);
    if (!is_array($json)) return ['echec', null, "Réponse inattendue d'OpenPay (HTTP $code)."];

    $refOp  = star_cut((string)($json['reference'] ?? $json['id'] ?? ''), 60);
    $msg    = star_cut((string)($json['message'] ?? $json['detail'] ?? $json['error'] ?? ''), 400);
    $status = strtolower((string)($json['status'] ?? ''));

    if ($code >= 400) {
        return ['echec', $refOp !== '' ? $refOp : null, $msg !== '' ? $msg : "Erreur OpenPay HTTP $code : vérifiez solde / numéro / clé API."];
    }
    if (star_openpay_est_encaisse($status, $msg)) {
        return ['succes', $refOp !== '' ? $refOp : null, $msg !== '' ? $msg : 'Paiement effectué avec succès.'];
    }
    if (in_array($status, ['pending', 'processing', 'initiated', 'waiting', 'attente', 'queued'], true)
        || $status === 'success'
        || ($status === '' && $refOp !== '')) {
        // HTTP 200 / status=success sans preuve d'encaissement = push USSD envoyé, PAS d'argent reçu.
        return ['attente', $refOp !== '' ? $refOp : null, $msg !== '' ? $msg : 'En attente de validation sur le téléphone.'];
    }

    return ['echec', $refOp !== '' ? $refOp : null, $msg !== '' ? $msg : 'Paiement refusé.'];
}

/** Argent réellement encaissé — pas un simple accusé de réception de la requête. */
function star_openpay_est_encaisse(string $status, string $msg): bool
{
    if (in_array($status, ['paid', 'completed', 'complete', 'successful', 'succes'], true)) {
        return true;
    }
    if ($status !== 'success') return false;
    if ($msg === '') return false;
    if (preg_match('/initi[eé]|en attente|pending|processing|envoy[eé]|validez|ussd|push/i', $msg)) return false;
    // Doc OpenPay CG : status=success + « Paiement effectué avec succès. » après PIN MTN.
    return (bool)preg_match('/effectu[ée].*succ[eè]s|paiement\s+(réussi|reussi|confirm[eé])|successfully\s+(paid|completed)|paid\s+successfully/i', $msg);
}
