<?php
/**
 * ============================================================
 *  STAR OS — PAIEMENT PAR CARTE BANCAIRE (Visa/Mastercard) + Mobile Money
 *  via CinetPay — agrégateur présent en République du Congo.
 * ------------------------------------------------------------
 *  Contrairement à OpenPay (push USSD synchrone sur le téléphone),
 *  CinetPay fonctionne par REDIRECTION : le client est envoyé sur une
 *  page de paiement hébergée par CinetPay où il choisit lui-même sa
 *  méthode (carte bancaire internationale OU Mobile Money MTN/Airtel),
 *  puis revient sur le site. La confirmation définitive arrive par un
 *  webhook serveur-à-serveur (notify_url) — jamais crue telle quelle :
 *  on revérifie TOUJOURS auprès de CinetPay (apikey + site_id +
 *  transaction_id) avant de considérer un paiement comme réel, exactement
 *  comme pour OpenPay.
 *
 *  L'argent payé par carte ou Mobile Money arrive sur le compte marchand
 *  CinetPay, puis se retire vers le Mobile Money (MTN/Airtel) de STAR
 *  ENTREPRISE depuis le tableau de bord CinetPay — ensuite, retrait cash
 *  normal, comme pour n'importe quel dépôt Mobile Money.
 *
 *  Actions publiques (clé STAR_API_KEY du site) :
 *    - pay_start : crée la transaction et renvoie l'URL de paiement CinetPay
 *    - ping      : test de vie
 *  Appelé par CinetPay (sans clé API — revérifié par rappel serveur) :
 *    - notify (POST ?notify=1) : webhook de confirmation
 *
 *  La vérification du statut APRÈS le retour sur le site réutilise
 *  l'action "pay_status" déjà existante dans paiement.php : les deux
 *  moyens de paiement écrivent dans la MÊME table star_paiements, donc
 *  tout le reste du site (téléchargement du livre, compteur anti-fraude,
 *  tableau de bord admin) fonctionne sans aucune modification.
 *
 *  ⚠️ IMPLÉMENTATION BASÉE SUR LA DOCUMENTATION PUBLIQUE CinetPay Checkout
 *  API v2 (api-checkout.cinetpay.com). Le site officiel docs.cinetpay.com
 *  n'a pas pu être consulté directement depuis cet environnement (réseau
 *  bloqué) — à tester avec de vraies clés dès réception de votre compte
 *  marchand, et à ajuster si CinetPay a fait évoluer un nom de champ.
 * ============================================================
 */

require_once __DIR__ . '/db.php';

star_cors();

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// ---- PING PUBLIC ----
if ($method === 'GET' && isset($_GET['ping'])) {
    star_json_ok([
        'service'  => 'STAR PAIEMENT CARTE',
        'version'  => '1.0',
        'provider' => 'CinetPay',
        'cle_live' => (CINETPAY_APIKEY !== '' && strpos(CINETPAY_APIKEY, 'METTEZ') === false
            && CINETPAY_SITE_ID !== '' && strpos(CINETPAY_SITE_ID, 'METTEZ') === false) ? 'configurée' : 'ABSENTE',
        'time'     => date('c'),
    ]);
}

// ============================================================
//  WEBHOOK — CinetPay → nous (notify_url)
// ============================================================
if ($method === 'POST' && isset($_GET['notify'])) {
    $brut = file_get_contents('php://input');
    $postDecode = [];
    if ($brut !== '') { parse_str($brut, $postDecode); }
    $transactionId = star_cut($postDecode['cpm_trans_id'] ?? $_POST['cpm_trans_id'] ?? $_GET['cpm_trans_id'] ?? '', 60);
    if ($transactionId !== '') {
        cinetpay_confirmer($transactionId);
    }
    // Toujours répondre 200 : un code d'erreur ferait boucler les
    // nouvelles tentatives de CinetPay sans rien résoudre de plus.
    http_response_code(200);
    echo 'OK';
    exit;
}

$in     = ($method === 'POST') ? star_read_json_body() : $_GET;
$action = strtolower(trim((string)($in['action'] ?? '')));

if ($action !== 'pay_start') {
    star_json_error('action_inconnue', "Action « $action » inconnue.", 404);
}

star_require_api_key();
star_rate_limit();

if (!function_exists('curl_init')) {
    star_json_error('serveur_incomplet', 'Extension cURL absente du serveur PHP.', 500);
}
if (CINETPAY_APIKEY === '' || strpos(CINETPAY_APIKEY, 'METTEZ') !== false
    || CINETPAY_SITE_ID === '' || strpos(CINETPAY_SITE_ID, 'METTEZ') !== false) {
    star_json_error('paiement_indisponible', 'Le paiement par carte bancaire n\'est pas encore configuré (clé CinetPay manquante dans config.php).', 503);
}

$d = $in['data'] ?? $in;
if (is_string($d)) { $decoded = json_decode($d, true); $d = is_array($decoded) ? $decoded : []; }
if (!is_array($d)) $d = [];

$article = star_cut($d['article'] ?? $d['title'] ?? 'Achat site web', 180);
$montant = (int)preg_replace('/[^0-9]/', '', (string)($d['montant'] ?? $d['amount'] ?? '0'));
$client  = star_cut($d['client'] ?? $d['nom'] ?? $d['name'] ?? 'Client Site Web', 180);
$ville   = star_cut($d['ville'] ?? $d['city'] ?? '', 110);
$telRaw  = (string)($d['telephone'] ?? $d['phone'] ?? '');
$telNorm = star_normaliser_tel($telRaw);
$tel     = $telNorm ?? preg_replace('/[^0-9]/', '', $telRaw);
$email   = star_cut($d['email'] ?? '', 180);
$page    = star_cut($d['page'] ?? '', 250);
$retour  = star_cut($d['return_url'] ?? '', 500);

// ============================================================
//  🔒 CATALOGUE SERVEUR — même verrou que paiement.php : le montant DOIT
//  correspondre au prix officiel, quoi qu'envoie le navigateur.
// ============================================================
$prixCatalogue = star_prix_catalogue($article);
if ($prixCatalogue === null) {
    star_json_error('article_inconnu', 'Article non reconnu par le catalogue officiel du site. Achat refusé.', 403);
}
if ($montant !== $prixCatalogue) {
    star_json_error('montant_non_conforme',
        'Montant refusé : le prix officiel de cet article est de ' . number_format($prixCatalogue, 0, ',', ' ') .
        ' FCFA, pas ' . number_format($montant, 0, ',', ' ') . ' FCFA. Achat bloqué.', 403);
}
$montant = $prixCatalogue;

$db = star_db();
$ip = substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 60);
$reference = 'STAR-' . date('ymd-His') . '-' . strtoupper(bin2hex(random_bytes(3)));

// Enregistrement immédiat en « attente » — le webhook (ou pay_status au
// retour du client) fera évoluer le statut.
$stmt = $db->prepare("INSERT INTO star_paiements
    (reference, article, montant, telephone, client, provider, statut, mode, details, page, ip)
    VALUES (?,?,?,?,?, 'CINETPAY', 'attente', 'live', '', ?, ?)");
$stmt->bind_param('ssisss', $reference, $article, $montant, $tel, $page, $ip);
$stmt->execute();
$stmt->close();

$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host   = $_SERVER['HTTP_HOST'] ?? 'www.starentreprise.com';
$notifyUrl = $scheme . '://' . $host . '/backend/cinetpay.php?notify=1';
$returnUrl = $retour !== '' ? $retour : ($scheme . '://' . $host . '/carryo-oeuvre-achat.html');
// La référence revient dans l'URL de retour pour que le site sache quelle
// transaction vérifier après la redirection (voir carryo-oeuvre-achat.html).
$returnUrl .= (strpos($returnUrl, '?') === false ? '?' : '&') . 'cp_ref=' . urlencode($reference);

$payload = [
    'apikey'                 => CINETPAY_APIKEY,
    'site_id'                => CINETPAY_SITE_ID,
    'transaction_id'         => $reference,
    'amount'                 => $montant,
    'currency'               => CINETPAY_DEVISE,
    'description'            => star_cut($article, 255),
    'notify_url'             => $notifyUrl,
    'return_url'             => $returnUrl,
    'channels'               => 'ALL', // carte bancaire ET Mobile Money, au choix du client
    'customer_name'          => $client !== '' ? $client : 'Client',
    'customer_surname'       => 'STAR ENTREPRISE',
    'customer_phone_number'  => $tel,
    'customer_email'         => $email !== '' ? $email : 'contact.starentreprise@gmail.com',
    'customer_address'       => $ville !== '' ? $ville : 'Pointe-Noire',
    'customer_city'          => $ville !== '' ? $ville : 'Pointe-Noire',
    'customer_country'       => 'CG',
    'customer_state'         => 'CG',
    'customer_zip_code'      => '000',
];

$ch = curl_init('https://api-checkout.cinetpay.com/v2/payment');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE),
    CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
    CURLOPT_CONNECTTIMEOUT => 10,
    CURLOPT_TIMEOUT        => 25,
]);
$res  = curl_exec($ch);
curl_close($ch);

$data       = json_decode((string)$res, true);
$paymentUrl = $data['data']['payment_url'] ?? null;

if (!$paymentUrl) {
    $raison = (string)($data['description'] ?? $data['message'] ?? 'Erreur inconnue de CinetPay.');
    $stmt = $db->prepare("UPDATE star_paiements SET statut='echec', details=? WHERE reference=?");
    $stmt->bind_param('ss', $raison, $reference);
    $stmt->execute();
    $stmt->close();
    star_json_error('cinetpay_echec', 'Impossible de préparer le paiement par carte : ' . $raison, 502);
}

star_json_ok([
    'reference'   => $reference,
    'payment_url' => $paymentUrl,
    'statut'      => 'attente',
    'message'     => 'Vous allez être redirigé vers la page de paiement sécurisée CinetPay.',
]);

// ============================================================
//  Revérification + confirmation d'un paiement (appelée par le webhook,
//  et peut aussi être rappelée sans risque — ne retraite jamais un
//  paiement déjà confirmé « succes »).
// ============================================================
function cinetpay_confirmer(string $transactionId): void
{
    $db = star_db();
    $stmt = $db->prepare("SELECT * FROM star_paiements WHERE reference = ? LIMIT 1");
    $stmt->bind_param('s', $transactionId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$row) return;                        // transaction inconnue : on ignore proprement
    if ($row['statut'] === 'succes') return;   // déjà confirmé — jamais retraiter deux fois
    if (!function_exists('curl_init')) return;

    // 🔒 On ne fait JAMAIS confiance au contenu du webhook : on revérifie
    // directement auprès de CinetPay avec apikey + site_id + transaction_id.
    $ch = curl_init('https://api-checkout.cinetpay.com/v2/payment/check');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode([
            'apikey'         => CINETPAY_APIKEY,
            'site_id'        => CINETPAY_SITE_ID,
            'transaction_id' => $transactionId,
        ], JSON_UNESCAPED_UNICODE),
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT        => 25,
    ]);
    $res = curl_exec($ch);
    curl_close($ch);
    $data = json_decode((string)$res, true);
    $v = is_array($data['data'] ?? null) ? $data['data'] : [];
    $statutCinetpay = strtoupper((string)($v['status'] ?? ''));

    // 🔒 Double verrou : même si CinetPay confirme, le montant réellement
    // encaissé doit correspondre au prix officiel déjà enregistré pour
    // cette référence — jamais une confiance aveugle au montant reçu.
    $montantEncaisse = (int)($v['amount'] ?? $v['montant'] ?? 0);
    $valide = ($statutCinetpay === 'ACCEPTED') && $montantEncaisse === (int)$row['montant'];

    $statut  = $valide ? 'succes' : 'echec';
    $moyen   = (string)($v['payment_method'] ?? $v['channel'] ?? '');
    $details = star_cut('Statut CinetPay : ' . $statutCinetpay . ($moyen !== '' ? ' — moyen : ' . $moyen : ''), 500);

    $stmt = $db->prepare("UPDATE star_paiements SET statut=?, details=? WHERE reference=?");
    $stmt->bind_param('sss', $statut, $details, $transactionId);
    $stmt->execute();
    $stmt->close();

    $fcfa    = number_format((int)$row['montant'], 0, ',', ' ');
    $article = (string)$row['article'];
    $client  = (string)$row['client'];
    $tel     = (string)$row['telephone'];
    $page    = (string)$row['page'];

    if ($statut === 'succes') {
        $titre = "💳 PAIEMENT CARTE/MOBILE REÇU — $article — $fcfa FCFA — $client";
        $msg   = "Montant : $fcfa FCFA (XAF)\nArticle : $article\nClient : $client\nTéléphone : $tel\nRéférence : $transactionId\n$details";
    } else {
        $titre = "❌ Paiement carte/mobile échoué — $article — $fcfa FCFA — $client";
        $msg   = "$details\nRéférence : $transactionId";
    }
    $ipVide = '';
    $kind = 'paiement';
    $stmt = $db->prepare("INSERT INTO star_events (kind, title, message, client, telephone, page, ip) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param('sssssss', $kind, $titre, $msg, $client, $tel, $page, $ipVide);
    $stmt->execute();
    $stmt->close();

    star_upsert_client($db, $client, '', $tel, '');
    if ($statut === 'succes') star_notify_email($titre, $msg, $client, '', $tel);
}
