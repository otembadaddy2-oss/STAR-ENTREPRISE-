<?php
/**
 * ============================================================
 *  STAR OS — COUCHE BASE DE DONNÉES (NE PAS MODIFIER)
 *  Connexion MySQL + création automatique des tables.
 * ============================================================
 */

require_once __DIR__ . '/../config.php';

/** Connexion MySQL unique (lazy) */
function star_db(): mysqli
{
    static $db = null;
    if ($db instanceof mysqli) return $db;

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    try {
        $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        $db->set_charset(DB_CHARSET);
    } catch (Throwable $e) {
        if (defined('STAR_INSTALL_MODE') && STAR_INSTALL_MODE) {
            throw $e;
        }
        star_json_error('base_injoignable', 'Connexion à la base impossible. Vérifiez config.php (DB_HOST/DB_NAME/DB_USER/DB_PASS).', 500);
    }

    // Création automatique des tables au premier appel
    star_db_migrate($db);
    return $db;
}

/** Création des tables si elles n'existent pas */
function star_db_migrate(mysqli $db): void
{
    static $done = false;
    if ($done) return;
    $done = true;

    $db->query("CREATE TABLE IF NOT EXISTS star_events (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        kind VARCHAR(40) NOT NULL DEFAULT 'request',
        title VARCHAR(255) NOT NULL DEFAULT '',
        message TEXT,
        client VARCHAR(190) DEFAULT '',
        email VARCHAR(190) DEFAULT '',
        telephone VARCHAR(60) DEFAULT '',
        ville VARCHAR(120) DEFAULT '',
        page VARCHAR(255) DEFAULT '',
        status VARCHAR(20) NOT NULL DEFAULT 'nouveau',
        is_read TINYINT(1) NOT NULL DEFAULT 0,
        ip VARCHAR(60) DEFAULT '',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_created (created_at),
        INDEX idx_kind (kind),
        INDEX idx_status (status),
        INDEX idx_read (is_read)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->query("CREATE TABLE IF NOT EXISTS star_clients (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        nom VARCHAR(190) NOT NULL DEFAULT '',
        email VARCHAR(190) DEFAULT '',
        telephone VARCHAR(60) DEFAULT '',
        ville VARCHAR(120) DEFAULT '',
        requests_count INT UNSIGNED NOT NULL DEFAULT 1,
        last_seen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_email (email),
        INDEX idx_tel (telephone),
        INDEX idx_last (last_seen)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // ---- PAIEMENTS MOBILE MONEY (OpenPay / MTN) ----
    $db->query("CREATE TABLE IF NOT EXISTS star_paiements (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        reference VARCHAR(60) NOT NULL DEFAULT '',
        article VARCHAR(190) NOT NULL DEFAULT '',
        montant INT UNSIGNED NOT NULL DEFAULT 0,
        devise VARCHAR(8) NOT NULL DEFAULT 'XAF',
        telephone VARCHAR(30) DEFAULT '',
        client VARCHAR(190) DEFAULT '',
        provider VARCHAR(12) NOT NULL DEFAULT 'MTN',
        statut VARCHAR(12) NOT NULL DEFAULT 'attente',
        mode VARCHAR(8) NOT NULL DEFAULT 'live',
        details TEXT,
        page VARCHAR(255) DEFAULT '',
        ip VARCHAR(60) DEFAULT '',
        telecharge_compte INT UNSIGNED NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_reference (reference),
        INDEX idx_statut (statut),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Table déjà existante sur un site en ligne (avant l'ajout du compteur
    // anti-fraude) : on ajoute la colonne si elle manque, sans jamais
    // toucher aux lignes déjà enregistrées.
    star_add_column_if_missing($db, 'star_paiements', 'telecharge_compte',
        'INT UNSIGNED NOT NULL DEFAULT 0');
}

/** Ajoute une colonne à une table existante si elle n'existe pas déjà
 *  (portable, sans dépendre de "ADD COLUMN IF NOT EXISTS" selon la
 *  version MySQL de l'hébergeur). Ne fait jamais planter le site si
 *  la vérification échoue. */
function star_add_column_if_missing(mysqli $db, string $table, string $column, string $definition): void
{
    try {
        $stmt = $db->prepare(
            "SELECT COUNT(*) AS n FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?"
        );
        $stmt->bind_param('ss', $table, $column);
        $stmt->execute();
        $existe = (int)($stmt->get_result()->fetch_assoc()['n'] ?? 0) > 0;
        $stmt->close();
        if (!$existe) {
            $db->query("ALTER TABLE `$table` ADD COLUMN `$column` $definition");
        }
    } catch (Throwable $e) { /* jamais bloquant */ }
}

/** Réponse JSON d'erreur standardisée */
function star_json_error(string $code, string $message, int $http = 400): void
{
    http_response_code($http);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'error' => $code, 'message' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

/** Réponse JSON de succès standardisée */
function star_json_ok(array $extra = []): void
{
    http_response_code(200);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array_merge(['ok' => true], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}

/** Échappement HTML pour l'affichage */
function star_h($s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

/** Vérifie la session administrateur (pour les actions sensibles) */
function star_require_admin(): void
{
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (isset($_SESSION['staros_last_activity']) && (time() - $_SESSION['staros_last_activity'] > SESSION_DURATION)) {
        session_unset(); session_destroy();
        star_json_error('session_expiree', 'Session expirée, reconnectez-vous.', 401);
    }
    $_SESSION['staros_last_activity'] = time();
    if (empty($_SESSION['staros_logged_in'])) {
        star_json_error('non_autorise', 'Connexion administrateur requise.', 401);
    }
}

/** Vérifie la clé API (pour les appels entrants du site public) */
function star_require_api_key(): void
{
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $auth = '';
    foreach ($headers as $k => $v) {
        if (strcasecmp($k, 'Authorization') === 0) { $auth = $v; break; }
    }
    if ($auth === '' && isset($_SERVER['HTTP_AUTHORIZATION'])) $auth = $_SERVER['HTTP_AUTHORIZATION'];
    if ($auth === '' && isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) $auth = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];

    if (preg_match('/Bearer\s+(.+)$/i', $auth, $m)) {
        if (hash_equals(STAR_API_KEY, trim($m[1]))) return;
    }
    // Accepter aussi la clé dans le corps JSON (certains navigateurs suppriment l'en-tête)
    $in = star_read_json_body();
    if (!empty($in['api_key']) && hash_equals(STAR_API_KEY, (string)$in['api_key'])) return;

    star_json_error('cle_invalide', 'Clé API invalide ou absente.', 403);
}

/** Lit le corps JSON de la requête (mis en cache) */
function star_read_json_body(): array
{
    static $body = null;
    if ($body !== null) return $body;
    $raw = file_get_contents('php://input');
    $body = json_decode($raw, true);
    if (!is_array($body)) $body = [];
    return $body;
}

/** Gestion CORS — autorise uniquement vos domaines déclarés */
function star_cors(): void
{
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($origin !== '') {
        $autorise = false;
        foreach (STAR_ALLOWED_ORIGINS as $allowed) {
            if (strcasecmp($origin, $allowed) === 0 || strpos($origin, $allowed) === 0) {
                $autorise = true;
                break;
            }
        }
        // Même hôte que ce backend (domaine Hostinger, URL temporaire, www…)
        $originHost = parse_url($origin, PHP_URL_HOST);
        $selfHost   = preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? ''));
        if ($originHost && $selfHost && strcasecmp($originHost, $selfHost) === 0) {
            $autorise = true;
        }
        // Mode tolérant en développement : refléter localhost/127.0.0.1 quel que soit le port
        if (preg_match('#^https?://(localhost|127\.0\.0\.1)(:\d+)?$#i', $origin)) {
            $autorise = true;
        }
        if ($autorise) {
            header('Access-Control-Allow-Origin: ' . $origin);
            header('Vary: Origin');
        }
    }
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    header('Access-Control-Max-Age: 600');
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

// ============================================================
//  FONCTIONS PARTAGÉES (utilisées par api.php ET paiement.php)
// ============================================================

/** Coupe une chaîne proprement (tolérant si l'extension mbstring est absente) */
function star_cut($s, int $max): string
{
    $s = trim((string)$s);
    if (function_exists('mb_strlen')) {
        if (mb_strlen($s) <= $max) return $s;
        return mb_substr($s, 0, $max - 1) . '…';
    }
    if (strlen($s) <= $max) return $s;
    return substr($s, 0, $max - 3) . '...';
}

/** Crée / met à jour la fiche client (relation site → CRM) */
function star_upsert_client(mysqli $db, string $nom, string $email, string $tel, string $ville): void
{
    if ($nom === '' || $nom === 'Visiteur Site Web') return;
    if ($email === '' && $tel === '') return;

    $existing = null;
    if ($email !== '') {
        $s = $db->prepare("SELECT id FROM star_clients WHERE email = ? LIMIT 1");
        $s->bind_param('s', $email); $s->execute();
        $existing = $s->get_result()->fetch_assoc(); $s->close();
    }
    if (!$existing && $tel !== '') {
        $s = $db->prepare("SELECT id FROM star_clients WHERE telephone = ? LIMIT 1");
        $s->bind_param('s', $tel); $s->execute();
        $existing = $s->get_result()->fetch_assoc(); $s->close();
    }

    if ($existing) {
        $s = $db->prepare("UPDATE star_clients SET requests_count = requests_count + 1, last_seen = NOW(),
                           nom = IF(?<>'', ?, nom), ville = IF(?<>'', ?, ville) WHERE id = ?");
        $s->bind_param('ssssi', $nom, $nom, $ville, $ville, $existing['id']);
        $s->execute(); $s->close();
    } else {
        $s = $db->prepare("INSERT INTO star_clients (nom, email, telephone, ville) VALUES (?,?,?,?)");
        $s->bind_param('ssss', $nom, $email, $tel, $ville);
        $s->execute(); $s->close();
    }
}

/** Notification e-mail à l'administrateur — via BREVO (API REST gratuite), secours mail() */
function star_notify_email(string $title, string $msg, string $client, string $email, string $tel): void
{
    if (STAR_NOTIFY_EMAIL === '' || strpos(STAR_NOTIFY_EMAIL, 'votre-email') !== false) return;
    $subject = '🔔 STAR OS — ' . star_cut($title, 90);
    $body = "Nouvel événement sur votre site STAR ENTREPRISE\n" .
            "============================================\n\n" .
            "Titre : $title\n" .
            "Client : $client\nE-mail : $email\nTéléphone : $tel\n\n" .
            "Détails :\n$msg\n\n" .
            "============================================\n" .
            "Connectez-vous à votre tableau de bord : /admin/\n";

    // ---- Voie 1 (recommandée) : API Brevo — fiable, 300 e-mails/jour gratuits ----
    if (defined('BREVO_API_KEY') && BREVO_API_KEY !== '' && strpos(BREVO_API_KEY, 'METTEZ') === false && function_exists('curl_init')) {
        $payload = [
            'sender'      => ['name' => BREVO_SENDER_NAME, 'email' => BREVO_SENDER_EMAIL],
            'to'          => [['email' => STAR_NOTIFY_EMAIL]],
            'subject'     => $subject,
            'textContent' => $body,
            'tags'        => ['star-os', 'notification-site'],
        ];
        $ch = curl_init('https://api.brevo.com/v3/smtp/email');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE),
            CURLOPT_HTTPHEADER     => [
                'api-key: ' . BREVO_API_KEY,
                'Content-Type: application/json',
                'Accept: application/json',
            ],
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT        => 20,
        ]);
        $res = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($res !== false && $code >= 200 && $code < 300) return; // ✅ envoyé via Brevo
        // Sinon : on tente le secours ci-dessous (journalisé silencieusement)
    }

    // ---- Voie 2 (secours) : fonction mail() de l'hébergeur ----
    $headers = 'From: ' . STAR_FROM_EMAIL . "\r\n" . 'Content-Type: text/plain; charset=utf-8';
    try { @mail(STAR_NOTIFY_EMAIL, '=?UTF-8?B?' . base64_encode($subject) . '?=', $body, $headers); } catch (Throwable $e) {}
}

/** Notification e-mail à l'administrateur AVEC le CV du candidat en pièce
 *  jointe — via BREVO (gère les pièces jointes nativement). Si Brevo est
 *  indisponible, secours mail() SANS pièce jointe (le fichier reste malgré
 *  tout en sécurité dans backend/cv-recus/, pour récupération manuelle). */
function star_notify_email_cv(string $title, string $msg, string $client, string $email, string $tel,
    string $cheminFichier, string $nomFichierAffiche): void
{
    if (STAR_NOTIFY_EMAIL === '' || strpos(STAR_NOTIFY_EMAIL, 'votre-email') !== false) return;
    $subject = '📄 STAR OS — ' . star_cut($title, 90);
    $body = "Nouvelle candidature avec CV sur votre site STAR ENTREPRISE\n" .
            "============================================\n\n" .
            "Titre : $title\n" .
            "Candidat : $client\nE-mail : $email\nTéléphone : $tel\n\n" .
            "Détails :\n$msg\n\n" .
            "Le CV est joint à cet e-mail.\n\n" .
            "============================================\n" .
            "Connectez-vous à votre tableau de bord : /admin/\n";

    if (defined('BREVO_API_KEY') && BREVO_API_KEY !== '' && strpos(BREVO_API_KEY, 'METTEZ') === false
        && function_exists('curl_init') && is_file($cheminFichier)) {
        $payload = [
            'sender'      => ['name' => BREVO_SENDER_NAME, 'email' => BREVO_SENDER_EMAIL],
            'to'          => [['email' => STAR_NOTIFY_EMAIL]],
            'subject'     => $subject,
            'textContent' => $body,
            'tags'        => ['star-os', 'candidature-cv'],
            'attachment'  => [[
                'content' => base64_encode((string)file_get_contents($cheminFichier)),
                'name'    => $nomFichierAffiche,
            ]],
        ];
        $ch = curl_init('https://api.brevo.com/v3/smtp/email');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE),
            CURLOPT_HTTPHEADER     => [
                'api-key: ' . BREVO_API_KEY,
                'Content-Type: application/json',
                'Accept: application/json',
            ],
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT        => 30,
        ]);
        $res = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($res !== false && $code >= 200 && $code < 300) return; // ✅ envoyé via Brevo, CV joint
    }

    // ---- Secours : mail() SANS pièce jointe (le CV reste sur le serveur) ----
    $body .= "\n⚠️ Pièce jointe non envoyée (secours sans Brevo) — fichier conservé sur le serveur :\n" . $cheminFichier . "\n";
    $headers = 'From: ' . STAR_FROM_EMAIL . "\r\n" . 'Content-Type: text/plain; charset=utf-8';
    try { @mail(STAR_NOTIFY_EMAIL, '=?UTF-8?B?' . base64_encode($subject) . '?=', $body, $headers); } catch (Throwable $e) {}
}

/** Envoi d'un message WhatsApp via l'API Cloud officielle (Meta). Partagé
 *  entre whatsapp.php et les autres points d'entrée (ex. candidature-cv.php)
 *  qui doivent notifier un numéro sans charger tout le routeur webhook.
 *  Ne fait rien (retourne simplement false) tant que WHATSAPP_TOKEN /
 *  WHATSAPP_PHONE_NUMBER_ID ne sont pas renseignés dans config.php. */
function star_wa_send(string $to, string $body): bool
{
    if (!defined('WHATSAPP_TOKEN') || !defined('WHATSAPP_PHONE_NUMBER_ID')
        || WHATSAPP_TOKEN === '' || strpos(WHATSAPP_TOKEN, 'METTEZ') !== false) {
        return false; // pas encore configuré
    }
    if (!function_exists('curl_init')) return false;

    $url = 'https://graph.facebook.com/v20.0/' . WHATSAPP_PHONE_NUMBER_ID . '/messages';
    $payload = [
        'messaging_product' => 'whatsapp',
        'to' => $to,
        'type' => 'text',
        'text' => ['body' => $body],
    ];
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . WHATSAPP_TOKEN,
            'Content-Type: application/json',
        ],
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT => 20,
    ]);
    $res = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $res !== false && $code >= 200 && $code < 300;
}

/** Envoi d'un FICHIER (PDF…) en pièce jointe WhatsApp, via l'API Cloud
 *  officielle (Meta) — en 2 temps obligatoires côté Meta : 1) upload du
 *  fichier sur leurs serveurs (→ un media_id valable ~30 jours), puis
 *  2) envoi d'un message de type "document" référençant ce media_id.
 *  Utilisée pour livrer automatiquement le livre numérique sur WhatsApp
 *  après validation manuelle d'un paiement (admin/paiements.php).
 *  Retourne [bool succès, string message d'erreur éventuel]. */
function star_wa_send_document(string $to, string $cheminFichier, string $nomAffiche, string $legende = ''): array
{
    if (!defined('WHATSAPP_TOKEN') || !defined('WHATSAPP_PHONE_NUMBER_ID')
        || WHATSAPP_TOKEN === '' || strpos(WHATSAPP_TOKEN, 'METTEZ') !== false) {
        return [false, 'WhatsApp non configuré (WHATSAPP_TOKEN/WHATSAPP_PHONE_NUMBER_ID manquants dans config.php).'];
    }
    if (!function_exists('curl_init')) return [false, 'Extension cURL absente du serveur PHP.'];
    if (!is_file($cheminFichier)) return [false, 'Fichier introuvable sur le serveur : ' . $cheminFichier];

    // ---- Étape 1 : upload du fichier → media_id ----
    $uploadUrl = 'https://graph.facebook.com/v20.0/' . WHATSAPP_PHONE_NUMBER_ID . '/media';
    $cfile = new CURLFile($cheminFichier, 'application/pdf', $nomAffiche);
    $ch = curl_init($uploadUrl);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . WHATSAPP_TOKEN],
        CURLOPT_POSTFIELDS => [
            'messaging_product' => 'whatsapp',
            'type' => 'application/pdf',
            'file' => $cfile,
        ],
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 60,
    ]);
    $res = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($res === false || $code < 200 || $code >= 300) {
        return [false, 'Échec de l\'envoi du fichier à WhatsApp (HTTP ' . $code . ') : ' . star_cut((string)$res, 300)];
    }
    $data = json_decode((string)$res, true);
    $mediaId = (string)($data['id'] ?? '');
    if ($mediaId === '') return [false, 'WhatsApp n\'a pas renvoyé d\'identifiant de fichier (media_id).'];

    // ---- Étape 2 : envoi du message "document" référençant ce media_id ----
    $msgUrl = 'https://graph.facebook.com/v20.0/' . WHATSAPP_PHONE_NUMBER_ID . '/messages';
    $payload = [
        'messaging_product' => 'whatsapp',
        'to' => $to,
        'type' => 'document',
        'document' => array_filter([
            'id' => $mediaId,
            'filename' => $nomAffiche,
            'caption' => $legende,
        ]),
    ];
    $ch = curl_init($msgUrl);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . WHATSAPP_TOKEN,
            'Content-Type: application/json',
        ],
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 30,
    ]);
    $res2 = curl_exec($ch);
    $code2 = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($res2 === false || $code2 < 200 || $code2 >= 300) {
        return [false, 'Fichier envoyé à WhatsApp mais échec de l\'envoi du message (HTTP ' . $code2 . ') : ' . star_cut((string)$res2, 300)];
    }
    return [true, ''];
}

/** Applique le format Mobile Money du Congo-Brazzaville : renvoie « 242XXXXXXXXX » ou null.
 *  Partagée entre paiement.php (OpenPay) et cinetpay.php (CinetPay). */
function star_normaliser_tel(string $raw): ?string
{
    $n = preg_replace('/[^0-9]/', '', $raw);
    if ($n === '') return null;
    if (str_starts_with($n, '00')) $n = substr($n, 2);          // 00242…
    if (str_starts_with($n, '242')) {                             // déjà international
        return strlen($n) === 12 ? $n : null;
    }
    if (strlen($n) === 9 && $n[0] === '0') return '242' . $n;     // 06/05/04 xxx xx xx
    if (strlen($n) === 8 && in_array($n[0], ['4', '5', '6'], true)) return '2420' . $n;
    return null;
}

/**
 * Catalogue OFFICIEL des articles vendus en ligne (libellé normalisé → prix FCFA).
 * Source : la galerie de carryo-oeuvre-achat.html (15 œuvres + le livre numérique).
 * Tout article absent de ce catalogue est refusé : impossible d'inventer
 * un libellé pour contourner un prix. Partagé entre TOUS les moyens de
 * paiement (OpenPay/MTN et CinetPay/carte+Mobile Money) — un seul endroit
 * à mettre à jour si un prix change.
 */
function star_catalogue(): array
{
    return [
        'regards croises'         => 150000,
        'fragments de memoire'    => 180000,
        'eclats d ebene'          => 120000,
        'la porteuse'             => 140000,
        'racines'                 => 220000,
        'regard sauvage'          => 200000,
        'marche de couleurs'      => 250000,
        'portrait d un sage'      => 160000,
        'elegance'                => 230000,
        'scene de vie'            => 300000,
        'visages multiples'       => 190000,
        'kaleidoscope'            => 170000,
        'vibrations d afrique'    => 190000,
        'empreintes'              => 175000,
        'mosaique urbaine'        => 240000,
        'de l ombre a la lumiere 2 exemplaires' => 25100,  // 📖 livre numérique (PDF) — 2 exemplaires (2 téléchargements)
        'de l ombre a la lumiere' => 12550,   // 📖 livre numérique (PDF) — 1 exemplaire (1 téléchargement)
    ];
}

/** Normalise un libellé : insensible à la casse, aux accents et à la ponctuation. */
function star_normaliser_libelle(string $s): string
{
    $s = function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s);
    $s = strtr($s, [
        'à' => 'a', 'â' => 'a', 'ä' => 'a', 'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e',
        'î' => 'i', 'ï' => 'i', 'ô' => 'o', 'ö' => 'o', 'ù' => 'u', 'û' => 'u', 'ü' => 'u',
        'ç' => 'c', 'œ' => 'oe', 'æ' => 'ae',
    ]);
    $s = preg_replace('/[^a-z0-9]+/', ' ', $s);
    return trim((string)preg_replace('/\s+/', ' ', $s));
}

/** Prix officiel d'un article, ou null s'il est inconnu du catalogue.
 *  Quand plusieurs libellés du catalogue correspondent (ex. « de l ombre
 *  a la lumiere » est un sous-ensemble de « de l ombre a la lumiere 2
 *  exemplaires »), c'est le libellé le PLUS LONG — donc le plus précis —
 *  qui l'emporte, jamais un refus par ambiguïté : les variantes « N
 *  exemplaires » d'un même article sont volontairement imbriquées. */
function star_prix_catalogue(string $article): ?int
{
    $norm = star_normaliser_libelle($article);
    if ($norm === '') return null;
    $meilleurTitre = null;
    $trouve = null;
    foreach (star_catalogue() as $titre => $prix) {
        if ($titre === '' || strpos($norm, $titre) === false) continue;
        if ($meilleurTitre === null || strlen($titre) > strlen($meilleurTitre)) {
            $meilleurTitre = $titre;
            $trouve = $prix;
        }
    }
    return $trouve;
}

/** Anti-spam simple : max 30 événements par fenêtre de 60 s par IP.
 *  ⚠️ Fenêtre GLISSANTE réelle : le compteur repart à zéro dès que la
 *  dernière requête date de plus de 60 s — un visiteur bavard avec Sarah
 *  ne doit JAMAIS être bloqué définitivement (sinon : perte de messages !). */
function star_rate_limit(): void
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'x';
    $dir = sys_get_temp_dir() . '/staros_rl';
    if (!is_dir($dir)) @mkdir($dir, 0700, true);
    $f   = $dir . '/' . md5($ip);
    $now = time();
    $n   = 0;
    if (is_file($f) && ($now - (int)@filemtime($f)) < 60) {
        // Fenêtre de 60 s encore active → on lit le compteur
        $n = (int)@file_get_contents($f);
    }
    // sinon : fenêtre expirée → compteur remis à 0 automatiquement
    if ($n >= 30) star_json_error('trop_de_requetes', 'Trop de requêtes, réessayez dans une minute.', 429);
    @file_put_contents($f, $n + 1, LOCK_EX);
    @touch($f, $now); // la fenêtre redémarre à chaque requête acceptée
}
