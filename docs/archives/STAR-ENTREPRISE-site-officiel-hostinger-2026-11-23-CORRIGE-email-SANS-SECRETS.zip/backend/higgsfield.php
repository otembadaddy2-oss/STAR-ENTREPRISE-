<?php
/**
 * ============================================================
 *  STAR OS — PROXY SÉCURISÉ HIGGSFIELD
 * ============================================================
 *  Relaie les appels vers l'API Higgsfield en ajoutant la clé
 *  secrète côté serveur (HIGGSFIELD_API_KEY, dans config.php).
 *  La clé Higgsfield n'est JAMAIS envoyée au client ni visible
 *  dans aucune réponse.
 *
 *  Accès : réservé aux appels portant le bon jeton
 *  d'automatisation (en-tête X-Automation-Token), vérifié contre
 *  STAR_AUTOMATION_TOKEN dans config.php. Tout autre appel est
 *  refusé (403).
 *
 *  URL : https://votredomaine.com/backend/higgsfield.php
 *  Requête attendue (POST, JSON) :
 *    { "path": "/v1/...", "method": "POST", "body": { ... } }
 *  Réponse : le JSON renvoyé tel quel par Higgsfield.
 * ============================================================
 */

require_once __DIR__ . '/../config.php';

header('Content-Type: application/json; charset=utf-8');

function hf_error(string $code, string $message, int $http = 400): void
{
    http_response_code($http);
    echo json_encode(['ok' => false, 'error' => $code, 'message' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

function hf_header(string $name): string
{
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    foreach ($headers as $k => $v) {
        if (strcasecmp($k, $name) === 0) return (string)$v;
    }
    $serverKey = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
    return (string)($_SERVER[$serverKey] ?? '');
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    hf_error('methode_invalide', 'Seul POST est accepté sur ce proxy.', 405);
}

if (!defined('STAR_AUTOMATION_TOKEN') || STAR_AUTOMATION_TOKEN === '') {
    hf_error('non_configure', 'STAR_AUTOMATION_TOKEN absent de config.php.', 500);
}
$token = hf_header('X-Automation-Token');
if ($token === '' || !hash_equals(STAR_AUTOMATION_TOKEN, $token)) {
    hf_error('jeton_invalide', 'Jeton d\'automatisation invalide ou absent.', 403);
}

if (!defined('HIGGSFIELD_API_KEY') || HIGGSFIELD_API_KEY === '' || HIGGSFIELD_API_KEY === 'METTEZ_VOTRE_CLE_HIGGSFIELD_ICI') {
    hf_error('cle_absente', 'HIGGSFIELD_API_KEY non configurée dans config.php — collez votre clé Higgsfield.', 500);
}

$raw = file_get_contents('php://input');
$in = json_decode($raw, true);
if (!is_array($in)) $in = [];

$path = (string)($in['path'] ?? '');
$method = strtoupper((string)($in['method'] ?? 'POST'));
$payload = $in['body'] ?? null;

if ($path === '' || $path[0] !== '/') {
    hf_error('chemin_invalide', 'Le champ "path" doit commencer par /, ex: /v1/image/generate', 400);
}
if (!in_array($method, ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'], true)) {
    hf_error('methode_amont_invalide', 'Méthode amont non supportée.', 400);
}

$base = defined('HIGGSFIELD_API_BASE') ? HIGGSFIELD_API_BASE : 'https://platform.higgsfield.ai';
$url = rtrim($base, '/') . $path;

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CUSTOMREQUEST  => $method,
    CURLOPT_HTTPHEADER     => [
        'Authorization: Key ' . HIGGSFIELD_API_KEY,
        'Content-Type: application/json',
        'Accept: application/json',
    ],
    CURLOPT_TIMEOUT        => 120,
    CURLOPT_SSL_VERIFYPEER => true,
]);
if ($payload !== null && $method !== 'GET') {
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload, JSON_UNESCAPED_UNICODE));
}

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr  = curl_error($ch);
curl_close($ch);

if ($response === false) {
    hf_error('appel_echoue', 'Appel Higgsfield impossible : ' . $curlErr, 502);
}

http_response_code($httpCode > 0 ? $httpCode : 200);
echo $response;
