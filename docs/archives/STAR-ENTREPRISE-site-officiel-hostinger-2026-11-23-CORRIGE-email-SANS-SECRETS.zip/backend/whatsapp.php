<?php
/**
 * ============================================================
 *  STAR OS — SARAH SUR WHATSAPP BUSINESS (API Cloud officielle Meta)
 * ============================================================
 *  Ce fichier est volontairement ISOLÉ de api.php et db.php :
 *  il ne touche AUCUNE table existante et n'en crée que de
 *  nouvelles. Rien ici ne peut casser Demandes / Sarah web /
 *  Paiements, qui ont déjà été vérifiés de bout en bout.
 *
 *  URL du webhook à donner à Meta (WhatsApp Manager → Configuration) :
 *      https://votredomaine.com/backend/whatsapp.php
 *
 *  Avant de l'activer, remplissez dans config.php :
 *  WHATSAPP_TOKEN, WHATSAPP_PHONE_NUMBER_ID, WHATSAPP_VERIFY_TOKEN,
 *  WHATSAPP_APP_SECRET (recommandé), ANTHROPIC_API_KEY (optionnel).
 * ============================================================
 */

require_once __DIR__ . '/db.php';

star_cors();
star_wa_migrate(star_db());

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// -----------------------------------------------------------
//  1. VÉRIFICATION DU WEBHOOK (Meta appelle ceci une seule fois,
//     quand vous cliquez sur « Vérifier et enregistrer »)
// -----------------------------------------------------------
if ($method === 'GET' && isset($_GET['hub_mode'])) {
    $mode      = (string)($_GET['hub_mode'] ?? '');
    $token     = (string)($_GET['hub_verify_token'] ?? '');
    $challenge = (string)($_GET['hub_challenge'] ?? '');
    $expected  = defined('WHATSAPP_VERIFY_TOKEN') ? WHATSAPP_VERIFY_TOKEN : '';
    if ($mode === 'subscribe' && $expected !== '' && hash_equals($expected, $token)) {
        header('Content-Type: text/plain');
        echo $challenge;
        exit;
    }
    http_response_code(403);
    echo 'Jeton de vérification invalide.';
    exit;
}

// -----------------------------------------------------------
//  2. RÉCEPTION D'UN MESSAGE WHATSAPP ENTRANT (Meta → nous)
// -----------------------------------------------------------
if ($method === 'POST' && !isset($_GET['admin'])) {
    $raw = file_get_contents('php://input');
    star_wa_verify_signature($raw);
    $payload = json_decode($raw, true);
    if (is_array($payload)) star_wa_handle_incoming($payload);
    http_response_code(200);
    echo 'EVENT_RECEIVED';
    exit;
}

// -----------------------------------------------------------
//  3. ACTIONS ADMIN (consultées par admin/whatsapp.php)
// -----------------------------------------------------------
if (isset($_GET['admin']) || $method === 'POST') {
    star_require_admin();
    $in = star_read_json_body();
    $action = (string)($in['action'] ?? '');
    star_wa_handle_admin($action, $in);
    exit;
}

http_response_code(404);
exit;

// ===========================================================
//  TABLES DÉDIÉES — créées ici uniquement (jamais dans db.php)
// ===========================================================
function star_wa_migrate(mysqli $db): void
{
    static $done = false;
    if ($done) return;
    $done = true;

    $db->query("CREATE TABLE IF NOT EXISTS star_whatsapp (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        wa_id VARCHAR(30) NOT NULL DEFAULT '',
        contact_name VARCHAR(190) DEFAULT '',
        direction ENUM('in','out') NOT NULL,
        auteur VARCHAR(20) NOT NULL DEFAULT 'client',
        categorie VARCHAR(20) NOT NULL DEFAULT 'indetermine',
        confiance TINYINT UNSIGNED NOT NULL DEFAULT 0,
        body TEXT,
        wa_message_id VARCHAR(80) DEFAULT '',
        is_read TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_wa (wa_id),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->query("CREATE TABLE IF NOT EXISTS star_whatsapp_threads (
        wa_id VARCHAR(30) NOT NULL PRIMARY KEY,
        contact_name VARCHAR(190) DEFAULT '',
        sarah_actif TINYINT(1) NOT NULL DEFAULT 1,
        last_message_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

// ===========================================================
//  SÉCURITÉ — vérifie la signature Meta (X-Hub-Signature-256)
// ===========================================================
function star_wa_verify_signature(string $raw): void
{
    if (!defined('WHATSAPP_APP_SECRET') || WHATSAPP_APP_SECRET === '' || strpos(WHATSAPP_APP_SECRET, 'METTEZ') !== false) {
        return; // pas encore configuré — on accepte (à activer dès que possible)
    }
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $sig = '';
    foreach ($headers as $k => $v) {
        if (strcasecmp($k, 'X-Hub-Signature-256') === 0) { $sig = $v; break; }
    }
    $expected = 'sha256=' . hash_hmac('sha256', $raw, WHATSAPP_APP_SECRET);
    if (!hash_equals($expected, (string)$sig)) {
        http_response_code(403);
        echo 'Signature invalide.';
        exit;
    }
}

// ===========================================================
//  RÉCEPTION — cœur de la logique métier
// ===========================================================
function star_wa_handle_incoming(array $payload): void
{
    $entries = $payload['entry'] ?? [];
    foreach ($entries as $entry) {
        foreach (($entry['changes'] ?? []) as $change) {
            $value = $change['value'] ?? [];
            $messages = $value['messages'] ?? [];
            if (!$messages) continue; // accusés de lecture / statuts : ignorés ici

            $contacts = $value['contacts'] ?? [];
            $contactName = $contacts[0]['profile']['name'] ?? '';

            foreach ($messages as $m) {
                $waId = (string)($m['from'] ?? '');
                if ($waId === '') continue;
                $body = star_wa_extract_text($m);
                $msgId = (string)($m['id'] ?? '');

                star_wa_process_message($waId, $contactName, $body, $msgId);
            }
        }
    }
}

/** Extrait le texte d'un message WhatsApp quel que soit son type */
function star_wa_extract_text(array $m): string
{
    $type = $m['type'] ?? 'text';
    switch ($type) {
        case 'text':      return (string)($m['text']['body'] ?? '');
        case 'button':    return (string)($m['button']['text'] ?? '');
        case 'interactive':
            $i = $m['interactive'] ?? [];
            return (string)($i['button_reply']['title'] ?? $i['list_reply']['title'] ?? '');
        default:          return '[Message ' . $type . ' — non pris en charge par Sarah, à consulter dans WhatsApp]';
    }
}

/** Traite un message entrant : enregistre, classe, répond si pertinent */
function star_wa_process_message(string $waId, string $contactName, string $body, string $msgId): void
{
    $db = star_db();

    // Fil de discussion : crée/actualise la fiche contact
    $stmt = $db->prepare("INSERT INTO star_whatsapp_threads (wa_id, contact_name, last_message_at)
                          VALUES (?,?,NOW())
                          ON DUPLICATE KEY UPDATE contact_name = IF(VALUES(contact_name)<>'', VALUES(contact_name), contact_name),
                                                   last_message_at = NOW()");
    $stmt->bind_param('ss', $waId, $contactName); $stmt->execute(); $stmt->close();

    $th = $db->prepare("SELECT sarah_actif FROM star_whatsapp_threads WHERE wa_id=?");
    $th->bind_param('s', $waId); $th->execute();
    $sarahActif = (int)($th->get_result()->fetch_assoc()['sarah_actif'] ?? 1);
    $th->close();

    // Classification : « business » (Sarah peut répondre) / « personnel » (on laisse) / « indéterminé » (on escalade)
    [$categorie, $confiance] = star_wa_classify($waId, $body);

    $stmt = $db->prepare("INSERT INTO star_whatsapp (wa_id, contact_name, direction, auteur, categorie, confiance, body, wa_message_id)
                          VALUES (?,?,'in','client',?,?,?,?)");
    $stmt->bind_param('sssiss', $waId, $contactName, $categorie, $confiance, $body, $msgId);
    $stmt->execute(); $stmt->close();

    // Sarah ne répond QUE si : catégorie business + confiance suffisante + Carry n'a pas repris la main sur ce contact
    if ($categorie === 'business' && $confiance >= 60 && $sarahActif) {
        $reply = star_wa_build_reply($body);
        if ($reply !== null) {
            star_wa_send($waId, $reply);
            $stmt = $db->prepare("INSERT INTO star_whatsapp (wa_id, contact_name, direction, auteur, categorie, confiance, body)
                                  VALUES (?,?,'out','sarah','business',100,?)");
            $stmt->bind_param('sss', $waId, $contactName, $reply);
            $stmt->execute(); $stmt->close();
        }
        // Si aucune fiche de connaissance ne correspond avec assez de certitude,
        // Sarah NE DEVINE PAS : le message reste simplement non lu pour Carry
        // (visible dans admin/whatsapp.php, catégorie "à vérifier").
    }
}

/**
 * Classification heuristique. Volontairement prudente : en cas de doute,
 * on n'auto-répond jamais — on laisse toujours la main à Carry.
 */
function star_wa_classify(string $waId, string $body): array
{
    $personalContacts = defined('WHATSAPP_PERSONAL_CONTACTS') ? WHATSAPP_PERSONAL_CONTACTS : [];
    if (in_array($waId, $personalContacts, true)) {
        return ['personnel', 100]; // liste blanche explicite de Carry — jamais touchée par Sarah
    }

    $t = mb_strtolower($body);

    $personalMarkers = ['papa', 'maman', 'mon amour', 'chéri', 'cherie', 'mon frère', 'mon frere',
        'ma sœur', 'ma soeur', 'tonton', 'tantine', 'bro ', 'tu fais quoi', 'ça va toi', 'ca va toi',
        'comment tu vas', 'mon ami ', 'mon pote'];
    foreach ($personalMarkers as $marker) {
        if (mb_strpos($t, $marker) !== false) return ['personnel', 80];
    }

    $businessMarkers = ['prix', 'tarif', 'devis', 'rendez-vous', 'rdv', 'commande', 'service',
        'produit', 'livraison', 'paiement', 'payer', 'adresse', 'horaire', 'disponib', 'information',
        'renseign', 'contrat', 'facture', 'réservation', 'reservation', 'abonnement', 'star ',
        'pioupiou', 'komyo', 'bissa pop', 'clinique', 'jet', 'immo', 'marketplace', 'alerte',
        'kidimbou', 'liboke', 'énergie', 'energie', 'transport', 'événement', 'evenement'];
    foreach ($businessMarkers as $marker) {
        if (mb_strpos($t, $marker) !== false) return ['business', 75];
    }

    // Premier message d'un inconnu, sans marqueur clair : traité comme un prospect
    // potentiel mais SANS auto-réponse (confiance volontairement sous le seuil de 60).
    return ['indetermine', 40];
}

/** Construit une réponse à partir de la base de connaissances (sans jamais inventer) */
function star_wa_build_reply(string $body): ?string
{
    static $kb = null;
    if ($kb === null) {
        $json = @file_get_contents(__DIR__ . '/sarah-knowledge.json');
        $kb = $json ? (json_decode($json, true) ?: []) : [];
    }

    $t = mb_strtolower($body);
    $best = null; $bestScore = 0;
    foreach ($kb as $key => $fiche) {
        if ($key === '_note') continue;
        $hay = mb_strtolower(($fiche['name'] ?? '') . ' ' . ($fiche['summary'] ?? '') . ' ' . ($fiche['details'] ?? ''));
        $words = preg_split('/[^a-zà-ÿ0-9]+/u', mb_strtolower($fiche['name'] ?? ''));
        $score = 0;
        foreach ($words as $w) {
            if (mb_strlen($w) >= 3 && mb_strpos($t, $w) !== false) $score += 2;
        }
        if (mb_strpos($t, mb_strtolower($fiche['name'] ?? '__x__')) !== false) $score += 5;
        if ($score > $bestScore) { $bestScore = $score; $best = $fiche; }
    }

    if ($best && $bestScore >= 2) {
        $txt = "Bonjour, je suis Sarah, l'assistante de Carry OTEMBA, PDG de STAR ENTREPRISE. 🙏\n\n"
             . "*{$best['name']}*\n{$best['summary']}";
        if (!empty($best['details'])) $txt .= "\n\n{$best['details']}";
        $txt .= "\n\nSouhaitez-vous que je transmette votre demande directement à notre équipe ?";
        return $txt;
    }

    // Aucune fiche fiable trouvée → tentative optionnelle via Claude (Anthropic),
    // strictement cadrée par le système de prompt, sinon on n'invente rien.
    if (defined('ANTHROPIC_API_KEY') && ANTHROPIC_API_KEY !== '' && strpos(ANTHROPIC_API_KEY, 'METTEZ') === false) {
        return star_wa_ask_claude($body, $kb);
    }
    return null;
}

/** Appel serveur (jamais côté client) à l'API Anthropic, cadré par la base de connaissances */
function star_wa_ask_claude(string $body, array $kb): ?string
{
    if (!function_exists('curl_init')) return null;

    $facts = [];
    foreach ($kb as $key => $fiche) {
        if ($key === '_note') continue;
        $facts[] = "- {$fiche['name']} : {$fiche['summary']}";
    }
    $system = "Tu es Sarah, assistante virtuelle de STAR ENTREPRISE au Congo, au service de son PDG Carry OTEMBA. "
        . "Ton hyper professionnel, courtois, chaleureux. Tu réponds UNIQUEMENT à partir des faits ci-dessous. "
        . "Si la question sort de cette liste ou que tu n'es pas certaine, réponds EXACTEMENT : "
        . "\"ESCALADE\" (rien d'autre) — Carry OTEMBA la traitera personnellement. Ne devine jamais un prix, "
        . "une date ou une information absente de la liste.\n\nFAITS CONNUS :\n" . implode("\n", $facts);

    $ch = curl_init('https://api.anthropic.com/v1/messages');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'x-api-key: ' . ANTHROPIC_API_KEY,
            'anthropic-version: 2023-06-01',
        ],
        CURLOPT_POSTFIELDS => json_encode([
            'model' => 'claude-sonnet-5',
            'max_tokens' => 400,
            'system' => $system,
            'messages' => [['role' => 'user', 'content' => $body]],
        ], JSON_UNESCAPED_UNICODE),
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT => 20,
    ]);
    $res = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($res === false || $code < 200 || $code >= 300) return null;

    $data = json_decode($res, true);
    $text = $data['content'][0]['text'] ?? '';
    $text = trim($text);
    if ($text === '' || stripos($text, 'ESCALADE') !== false) return null;
    return $text;
}

/* star_wa_send() vit désormais dans db.php (partagée avec candidature-cv.php,
   qui doit notifier WhatsApp sans charger tout ce routeur webhook). */

// ===========================================================
//  ACTIONS ADMIN — consultées par admin/whatsapp.php
// ===========================================================
function star_wa_handle_admin(string $action, array $in): void
{
    $db = star_db();

    switch ($action) {

        case 'threads':
            $res = $db->query("SELECT t.wa_id, t.contact_name, t.sarah_actif, t.last_message_at,
                    (SELECT body FROM star_whatsapp w WHERE w.wa_id=t.wa_id ORDER BY w.id DESC LIMIT 1) AS last_body,
                    (SELECT COUNT(*) FROM star_whatsapp w WHERE w.wa_id=t.wa_id AND w.is_read=0 AND w.direction='in') AS non_lus
                FROM star_whatsapp_threads t ORDER BY t.last_message_at DESC LIMIT 200");
            $list = [];
            while ($row = $res->fetch_assoc()) $list[] = $row;
            star_json_ok(['threads' => $list]);
            break;

        case 'thread':
            $waId = (string)($in['wa_id'] ?? '');
            $stmt = $db->prepare("SELECT * FROM star_whatsapp WHERE wa_id=? ORDER BY id ASC LIMIT 500");
            $stmt->bind_param('s', $waId); $stmt->execute();
            $res = $stmt->get_result();
            $list = [];
            while ($row = $res->fetch_assoc()) $list[] = $row;
            $stmt->close();
            $u = $db->prepare("UPDATE star_whatsapp SET is_read=1 WHERE wa_id=?");
            $u->bind_param('s', $waId); $u->execute(); $u->close();
            star_json_ok(['messages' => $list]);
            break;

        // Carry répond lui-même depuis la console — visible et unifié, et met
        // Sarah en pause sur ce contact (il a repris la main personnellement).
        case 'send_as_carry':
            $waId = (string)($in['wa_id'] ?? '');
            $body = (string)($in['body'] ?? '');
            if ($waId === '' || trim($body) === '') star_json_error('champs_requis', 'Destinataire et message requis.');
            $ok = star_wa_send($waId, $body);
            if (!$ok) star_json_error('envoi_echoue', 'Envoi WhatsApp impossible — vérifiez WHATSAPP_TOKEN dans config.php.', 502);
            $stmt = $db->prepare("INSERT INTO star_whatsapp (wa_id, direction, auteur, categorie, confiance, body)
                                  VALUES (?, 'out', 'carry', 'personnel', 100, ?)");
            $stmt->bind_param('ss', $waId, $body); $stmt->execute(); $stmt->close();
            $up = $db->prepare("UPDATE star_whatsapp_threads SET sarah_actif=0, last_message_at=NOW() WHERE wa_id=?");
            $up->bind_param('s', $waId); $up->execute(); $up->close();
            star_json_ok();
            break;

        // Redonner la main à Sarah sur un contact (après que Carry a répondu lui-même)
        case 'toggle_sarah':
            $waId = (string)($in['wa_id'] ?? '');
            $actif = !empty($in['actif']) ? 1 : 0;
            $stmt = $db->prepare("UPDATE star_whatsapp_threads SET sarah_actif=? WHERE wa_id=?");
            $stmt->bind_param('is', $actif, $waId); $stmt->execute(); $stmt->close();
            star_json_ok();
            break;

        case 'mark_all_read':
            $db->query("UPDATE star_whatsapp SET is_read=1 WHERE is_read=0");
            star_json_ok();
            break;

        default:
            star_json_error('action_inconnue', "Action « $action » inconnue.", 404);
    }
}
