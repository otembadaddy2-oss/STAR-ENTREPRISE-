<?php
/**
 * ============================================================
 *  STAR OS — API CENTRALE  (point d'entrée unique)
 * ============================================================
 *  Le site public envoie ici : request / conversation / unresolved
 *  L'admin consulte ici      : stats / events / clients / actions
 *
 *  URL publique :  https://votredomaine.com/backend/api.php
 *  (ou la jolie URL /api/star-os via le .htaccess fourni)
 * ============================================================
 */

require_once __DIR__ . '/db.php';

star_cors();

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// -----------------------------------------------------------
//  PING PUBLIC (test de vie : le site vérifie que le backend tourne)
// -----------------------------------------------------------
if ($method === 'GET' && isset($_GET['ping'])) {
    star_json_ok(['service' => 'STAR OS', 'version' => STAR_BACKEND_VERSION, 'time' => date('c')]);
}

$in = ($method === 'POST') ? star_read_json_body() : $_GET;
$action = isset($in['action']) ? strtolower(trim((string)$in['action'])) : '';

// -----------------------------------------------------------
//  AIGUILLAGE
// -----------------------------------------------------------

// Actions PUBLIQUES (envoyées par le site via star-backend-bridge.js)
$publicActions  = ['request', 'conversation', 'unresolved', 'alert', 'event'];
// Actions ADMIN (protégées par la session de connexion)
$adminActions   = ['stats', 'events', 'clients', 'payments', 'mark_read', 'mark_all_read',
                   'mark_read_many', 'pay_recheck', 'livre_envoyer_whatsapp',
                   'update_status', 'delete', 'test_event', 'export_csv'];

if (in_array($action, $publicActions, true)) {
    star_require_api_key();
    star_rate_limit();
    star_handle_public($action, $in['data'] ?? []);
}

if (in_array($action, $adminActions, true)) {
    star_require_admin();
    star_handle_admin($action, $in);
}

star_json_error('action_inconnue', "Action « $action » inconnue.", 404);

// ===========================================================
//  TRAITEMENT DES ACTIONS PUBLIQUES (le site → le backend)
// ===========================================================
function star_handle_public(string $action, $data): void
{
    if (is_string($data)) { $decoded = json_decode($data, true); $data = is_array($decoded) ? $decoded : []; }
    if (!is_array($data)) $data = [];

    $db = star_db();
    $ip = substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 60);

    // Champs génériques, quel que soit le type d'événement
    $client    = star_cut($data['client'] ?? $data['nom'] ?? $data['name'] ?? 'Visiteur Site Web', 180);
    $email     = star_cut($data['email'] ?? '', 180);
    $telephone = star_cut($data['telephone'] ?? $data['phone'] ?? $data['tel'] ?? '', 55);
    $ville     = star_cut($data['ville'] ?? $data['city'] ?? $data['address'] ?? '', 110);
    $page      = star_cut($data['page'] ?? $data['source'] ?? '', 250);

    switch ($action) {
        case 'request':
            $type  = (string)($data['type'] ?? 'Contact / Message Client');
            $sujet = (string)($data['sujet'] ?? $data['subject'] ?? $type);
            $msg   = (string)($data['message'] ?? '');
            $isCand = (!empty($data['kind_hint']) && $data['kind_hint'] === 'candidature')
                || (bool)preg_match('/candidature/i', $type . ' ' . $sujet);
            $isCmd = !empty($data['is_command']) || star_is_command($type . ' ' . $sujet . ' ' . $msg);
            $isPay = !$isCand && star_is_paiement_signale($sujet . ' ' . $msg);
            // GARDE : une question captée par Sarah (pont non mis à jour / cache
            // navigateur) appartient au module IA, jamais aux demandes ni aux
            // paiements — même si le texte contient « prix » ou « payer ».
            $isSarahLog = (bool)preg_match('/Sarah AI/iu',
                (string)($data['source'] ?? '') . ' ' . $type);
            if ($isSarahLog) {
                $kind  = 'conversation';
                $title = '💬 Sarah — ' . star_cut($sujet, 120) . ' (question posée à l\'IA)';
            } elseif ($isCand) {
                $kind  = 'candidature';
                $title = '📋 CANDIDATURE — ' . $sujet;
            } elseif ($isPay) {
                // 💰 La preuve/annonce de paiement appartient au module PAIEMENTS
                //    (MTN Money ou Airtel), jamais au flux des demandes générales.
                $kind  = 'paiement';
                $title = '💰 PAIEMENT SIGNALÉ PAR LE CLIENT — ' . star_cut($sujet, 140);
            } elseif ($isCmd) {
                $kind  = 'commande';
                $title = '🛒 COMMANDE — ' . $sujet;
            } else {
                $kind  = 'request';
                $title = $sujet;
            }
            break;

        case 'conversation':
            $q    = (string)($data['question'] ?? '');
            $a    = (string)($data['answer'] ?? '');
            $kind = 'conversation';
            $title = '💬 Sarah — ' . star_cut($q, 90);
            $msg  = "QUESTION : $q\n\nRÉPONSE SARAH : $a";
            if (!empty($data['intent'])) $title .= '  [' . star_cut($data['intent'], 40) . ']';
            break;

        case 'unresolved':
            $kind = 'unresolved';
            $title = '⚠️ Sarah — question non résolue (à traiter)';
            $msg  = "Question : " . ($data['question'] ?? '') .
                    "\nRéponse partielle : " . ($data['partial_answer'] ?? '') .
                    "\nIntention détectée : " . ($data['intent'] ?? 'général');
            break;

        case 'alert':
        case 'event':
        default:
            $kind = 'alert';
            $title = star_cut($data['title'] ?? 'Notification du site', 200);
            $msg   = (string)($data['message'] ?? json_encode($data, JSON_UNESCAPED_UNICODE));
            break;
    }

    // Enregistrement de l'événement
    $stmt = $db->prepare("INSERT INTO star_events (kind, title, message, client, email, telephone, ville, page, ip)
                          VALUES (?,?,?,?,?,?,?,?,?)");
    $t = star_cut($title, 250);
    $stmt->bind_param('sssssssss', $kind, $t, $msg, $client, $email, $telephone, $ville, $page, $ip);
    $stmt->execute();
    $eventId = $db->insert_id;
    $stmt->close();

    // Fiche client : création ou mise à jour automatique — UNIQUEMENT pour les
    // vrais contacts du site. Une conversation avec l'IA (ou son escalade) ne
    // crée JAMAIS de fiche et n'allume jamais le badge Clients.
    if (!in_array($kind, ['conversation', 'unresolved'], true)) {
        star_upsert_client($db, $client, $email, $telephone, $ville);
    }

    // E-mail Gmail : candidatures, questions non résolues, et vrais formulaires du site.
    // JAMAIS un e-mail « PAIEMENT REÇU / CONFIRMÉ » depuis le navigateur (seul paiement.php
    // envoie ça, après encaissement OpenPay réel).
    $fromForm = !empty($data['notify']) || !empty($data['from_form']);
    $isFakePay = (bool)preg_match('/PAIEMENT\s*(REÇU|RECU|MTN|CONFIRM)/iu', $title . ' ' . $msg);
    $doEmail = false;
    if ($isFakePay && $kind !== 'paiement') {
        $doEmail = false;
    } elseif ($kind === 'candidature' || $kind === 'unresolved') {
        $doEmail = true;
    } elseif ($fromForm && in_array($kind, ['request', 'commande'], true)) {
        $doEmail = true;
    }
    if ($doEmail) {
        star_notify_email($title, $msg, $client, $email, $telephone);
    }

    star_json_ok(['id' => $eventId, 'kind' => $kind]);
}

/** Détecte si un texte ressemble à une commande/achat */
function star_is_command(string $text): bool
{
    return (bool)preg_match('/achat|commande|acquérir|réservation|réserver|acheter|purchase|buy|payer|order|acquisition/i', $text);
}

/** Module STAR OS d'appartenance d'un événement — UN type = UN module, zéro mélange. */
function star_event_group(string $kind): string
{
    if ($kind === 'paiement' || $kind === 'livre_telechargement') return 'paiements';
    if ($kind === 'conversation' || $kind === 'unresolved')        return 'sarah';
    return 'demandes';
}

/** Le message parle-t-il d'un paiement déjà effectué (MTN/Airtel/MoMo/virement) ? */
function star_is_paiement_signale(string $text): bool
{
    return (bool)preg_match("/paiement\s+(effectu[eé]|confirm[eé]|pass[eé]|reçu|recu)|j['’]\s*ai\s+(pay[eé]|effectu[eé]|envoy[eé])|preuve\s+de\s+paiement|capture\s+d.[’']?[ée]cran|airtel\s+money|mtn\s+money|mobile\s+money|virement|transaction\s+r[eé]gl[eé]e|STAR-\d{6}/i", $text);
}

// NOTE : star_cut, star_upsert_client, star_notify_email et star_rate_limit
// vivent désormais dans db.php (partagées avec paiement.php).

// ===========================================================
//  TRAITEMENT DES ACTIONS ADMIN (le backend → VOUS)
// ===========================================================
function star_handle_admin(string $action, array $in): void
{
    $db = star_db();

    switch ($action) {

        // ---- Compteurs du tableau de bord ----
        case 'stats':
            $out = ['total' => 0, 'non_lus' => 0, 'commandes' => 0, 'clients' => 0,
                    'conversations' => 0, 'unresolved' => 0, 'aujourdhui' => 0, 'par_jour' => []];
            $r = $db->query("SELECT COUNT(*) c FROM star_events");        $out['total'] = (int)$r->fetch_assoc()['c'];
            $r = $db->query("SELECT COUNT(*) c FROM star_events WHERE is_read=0"); $out['non_lus'] = (int)$r->fetch_assoc()['c'];
            // 🗂 Un badge par MODULE : chacun s'éteint quand CE module a été lu —
            //    plus jamais un compteur global qui fait clignoter toutes les cartes.
            $r = $db->query("SELECT COUNT(*) c FROM star_events WHERE is_read=0 AND kind IN ('paiement','livre_telechargement')");
            $out['non_lus_paiements'] = (int)$r->fetch_assoc()['c'];
            $r = $db->query("SELECT COUNT(*) c FROM star_events WHERE is_read=0 AND kind IN ('conversation','unresolved')");
            $out['non_lus_sarah'] = (int)$r->fetch_assoc()['c'];
            $r = $db->query("SELECT COUNT(*) c FROM star_events WHERE is_read=0 AND kind NOT IN ('paiement','livre_telechargement','conversation','unresolved')");
            $out['non_lus_demandes'] = (int)$r->fetch_assoc()['c'];
            $r = $db->query("SELECT COUNT(*) c FROM star_events WHERE kind='commande'"); $out['commandes'] = (int)$r->fetch_assoc()['c'];
            $r = $db->query("SELECT COUNT(*) c FROM star_events WHERE kind='conversation'"); $out['conversations'] = (int)$r->fetch_assoc()['c'];
            $r = $db->query("SELECT COUNT(*) c FROM star_events WHERE kind='unresolved'"); $out['unresolved'] = (int)$r->fetch_assoc()['c'];
            $r = $db->query("SELECT COUNT(*) c FROM star_events WHERE DATE(created_at)=CURDATE()"); $out['aujourdhui'] = (int)$r->fetch_assoc()['c'];
            $r = $db->query("SELECT COUNT(*) c FROM star_clients");       $out['clients'] = (int)$r->fetch_assoc()['c'];
            // Badge « Clients » : fiches nouvelles ou réactivées depuis la
            // dernière OUVERTURE de la page Clients — un module = un badge,
            // ouvert = lu = éteint, sans toucher aux autres compteurs.
            $out['non_lus_clients'] = 0;
            $rv = $db->query("SELECT COUNT(*) c FROM star_clients cl
                             WHERE cl.last_seen > COALESCE(
                                 (SELECT mv.viewed_at FROM star_module_views mv WHERE mv.module='clients'),
                                 '2000-01-01')");
            if ($rv) $out['non_lus_clients'] = (int)$rv->fetch_assoc()['c'];
            $r = $db->query("SELECT DATE(created_at) j, COUNT(*) c FROM star_events
                             WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
                             GROUP BY DATE(created_at) ORDER BY j");
            while ($row = $r->fetch_assoc()) $out['par_jour'][] = $row;
            // Pages du site les plus actives (d'où viennent les visiteurs)
            $out['par_page'] = [];
            $r = $db->query("SELECT page, COUNT(*) c FROM star_events WHERE page <> ''
                             GROUP BY page ORDER BY c DESC LIMIT 6");
            while ($row = $r->fetch_assoc()) $out['par_page'][] = $row;
            // Dernière activité (les 8 derniers événements)
            $out['derniers'] = [];
            $r = $db->query("SELECT id, kind, title, client, telephone, status, created_at
                             FROM star_events ORDER BY id DESC LIMIT 8");
            while ($row = $r->fetch_assoc()) $out['derniers'][] = $row;
            // Paiements Mobile Money (OpenPay)
            $r = $db->query("SELECT COUNT(*) c, COALESCE(SUM(montant),0) total FROM star_paiements WHERE statut='succes'");
            $p = $r->fetch_assoc(); $out['pay_recus'] = (int)$p['c']; $out['pay_fcfa'] = (int)$p['total'];
            $r = $db->query("SELECT COUNT(*) c, COALESCE(SUM(montant),0) total FROM star_paiements WHERE statut='succes' AND DATE(created_at)=CURDATE()");
            $p = $r->fetch_assoc(); $out['pay_aujourd'] = (int)$p['c']; $out['pay_fcfa_jour'] = (int)$p['total'];
            $r = $db->query("SELECT COUNT(*) c FROM star_paiements WHERE statut='attente' AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)");
            $out['pay_attente'] = (int)$r->fetch_assoc()['c'];
            star_json_ok(['stats' => $out]);
            break;

        // ---- Liste des paiements Mobile Money ----
        case 'payments':
            // 👁 Ouvrir le module Paiements = lire ses notifications : le badge
            //    « non lus » de la carte Paiements s'éteint (et pas les autres).
            $db->query("UPDATE star_events SET is_read=1 WHERE is_read=0
                        AND kind IN ('paiement','livre_telechargement')");
            // 🔍 Revérification honnête : toute transaction ⏳/✖ des 48 dernières heures
            //    est contrôlée chez MTN avant l'affichage (throttle interne : 12 s/réf).
            //    → Un faux « échoué » devient « ✔ REÇU » dès que l'opérateur confirme.
            $chk = $db->query("SELECT reference FROM star_paiements
                              WHERE statut <> 'succes' AND created_at >= DATE_SUB(NOW(), INTERVAL 48 HOUR)
                              ORDER BY id DESC LIMIT 12");
            while ($c = $chk->fetch_assoc()) { star_reconcilier($db, $c['reference']); }

            $res = $db->query("SELECT * FROM star_paiements ORDER BY id DESC LIMIT 300");
            $list = [];
            while ($row = $res->fetch_assoc()) $list[] = $row;
            $tot = $db->query("SELECT COUNT(*) c, COALESCE(SUM(montant),0) total FROM star_paiements WHERE statut='succes'")->fetch_assoc();
            star_json_ok(['payments' => $list, 'recus' => (int)$tot['c'], 'fcfa' => (int)$tot['total']]);
            break;

        // ---- Liste des événements (temps réel via ?since=timestamp) ----
        case 'events':
            $since = isset($in['since']) ? (int)$in['since'] : 0;
            $limit = min(200, max(1, (int)($in['limit'] ?? 100)));
            $filter = (string)($in['filter'] ?? 'all');

            $where = '1=1'; $types = ''; $params = [];
            if ($since > 0) { $where .= ' AND created_at > FROM_UNIXTIME(?)'; $types .= 'i'; $params[] = $since; }
            if ($filter === 'unread')    { $where .= ' AND is_read=0'; }
            if ($filter === 'commandes') { $where .= " AND kind='commande'"; }
            if ($filter === 'sarah')     { $where .= " AND kind IN ('conversation','unresolved')"; }
            if ($filter === 'paiements') { $where .= " AND kind IN ('paiement','livre_telechargement')"; }
            if ($filter === 'demandes')  { $where .= " AND kind NOT IN ('paiement','livre_telechargement','conversation','unresolved')"; }

            $sql = "SELECT * FROM star_events WHERE $where ORDER BY id DESC LIMIT $limit";
            $stmt = $db->prepare($sql);
            if ($params) $stmt->bind_param($types, ...$params);
            $stmt->execute();
            $res = $stmt->get_result();
            $events = [];
            while ($row = $res->fetch_assoc()) {
                $row['is_read'] = (int)$row['is_read'];
                $events[] = $row;
            }
            $stmt->close();

            // 👁 « Vu = lu » côté SERVEUR : tout événement affiché sur la page d'un
            //    module est marqué lu immédiatement (même au-delà des 100 premiers,
            //    même si le JavaScript du navigateur n'a pas pu le faire). L'état est
            //    en base : le badge du module s'éteint et NE REDÉMARRE JAMAIS.
            $markGroup = (string)($in['mark_group'] ?? '');
            if ($markGroup === 'demandes') {
                $db->query("UPDATE star_events SET is_read=1 WHERE is_read=0
                            AND kind NOT IN ('paiement','livre_telechargement','conversation','unresolved')");
            } elseif ($markGroup === 'sarah') {
                $db->query("UPDATE star_events SET is_read=1 WHERE is_read=0
                            AND kind IN ('conversation','unresolved')");
            } elseif ($markGroup === 'paiements') {
                $db->query("UPDATE star_events SET is_read=1 WHERE is_read=0
                            AND kind IN ('paiement','livre_telechargement')");
            }
            star_json_ok(['events' => $events, 'now' => time()]);
            break;

        // ---- Liste des clients ----
        case 'clients':
            // 👁 Ouvrir le module Clients = lire ses notifications : le badge
            //    « N clients » s'ÉTEINT (il ne restera plus figé à l'écran).
            $db->query("REPLACE INTO star_module_views (module, viewed_at) VALUES ('clients', NOW())");
            $res = $db->query("SELECT * FROM star_clients ORDER BY last_seen DESC LIMIT 300");
            $list = [];
            while ($row = $res->fetch_assoc()) $list[] = $row;
            star_json_ok(['clients' => $list]);
            break;

        // ---- Marquer lu / tout marquer lu ----
        case 'mark_read':
            $id = (int)($in['id'] ?? 0);
            $stmt = $db->prepare("UPDATE star_events SET is_read=1 WHERE id=?");
            $stmt->bind_param('i', $id); $stmt->execute(); $stmt->close();
            star_json_ok();
            break;

        case 'mark_all_read':
            $db->query("UPDATE star_events SET is_read=1 WHERE is_read=0");
            star_json_ok();
            break;

        // ---- Marquer lus EN MASSE (dès que l'admin a le message sous les yeux) ----
        //    Objectif : le badge « non lus » qui clignote s'ARRÊTE une fois lu,
        //    et ne repart plus jamais (l'état est en base, pas dans l'onglet).
        case 'mark_read_many':
            $ids = $in['ids'] ?? [];
            if (is_string($ids)) $ids = json_decode($ids, true);
            if (!is_array($ids)) $ids = [];
            $ids = array_values(array_unique(array_filter(array_map('intval', $ids), function ($v) { return $v > 0; })));
            if ($ids) {
                $ph = implode(',', array_fill(0, count($ids), '?'));
                $stmt = $db->prepare("UPDATE star_events SET is_read=1 WHERE id IN ($ph)");
                $stmt->bind_param(str_repeat('i', count($ids)), ...$ids);
                $stmt->execute(); $stmt->close();
            }
            star_json_ok(['marques' => count($ids)]);
            break;

        // ---- Bouton « 🔄 Vérifier chez MTN » d'une transaction ----
        case 'pay_recheck':
            $ref = star_cut((string)($in['reference'] ?? ''), 60);
            if ($ref === '') star_json_error('reference_requise', 'Référence du paiement requise.');
            $r = star_reconcilier($db, $ref);
            star_json_ok(['changed' => (bool)$r['changed'], 'statut' => $r['row']['statut'] ?? 'inconnu']);
            break;

        // ---- Bouton « 📖 Envoyer le livre sur WhatsApp » (validation manuelle
        //      de Carry après un paiement réussi du livre numérique) ----
        //      Réutilise EXACTEMENT le même verrou anti-fraude que le téléchargement
        //      web (backend/telecharger.php) : le nombre d'envois ne peut jamais
        //      dépasser le nombre d'exemplaires réellement payés (1 ou 2), et
        //      l'incrément est atomique pour bloquer toute tentative en double.
        case 'livre_envoyer_whatsapp':
            $ref = star_cut((string)($in['reference'] ?? ''), 60);
            if ($ref === '') star_json_error('reference_requise', 'Référence du paiement requise.');

            $stmt = $db->prepare("SELECT article, montant, statut, telephone, client, telecharge_compte
                                   FROM star_paiements WHERE reference = ? LIMIT 1");
            $stmt->bind_param('s', $ref); $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc(); $stmt->close();
            if (!$row) star_json_error('introuvable', 'Paiement inconnu.', 404);
            if ($row['statut'] !== 'succes') {
                star_json_error('pas_paye', 'Ce paiement n\'est pas confirmé (statut : « ' . $row['statut'] . ' »).', 409);
            }
            $art = function_exists('mb_strtolower') ? mb_strtolower((string)$row['article'], 'UTF-8') : strtolower((string)$row['article']);
            if (strpos($art, 'ombre') === false || strpos($art, 'lumi') === false) {
                star_json_error('article_incorrect', 'Ce paiement ne concerne pas le livre « De l\'Ombre à la Lumière ».', 409);
            }

            $montantPaye = (int)$row['montant'];
            if ($montantPaye === 12550) { $maxEnvois = 1; }
            elseif ($montantPaye === 25100) { $maxEnvois = 2; }
            else {
                star_json_error('montant_incorrect', 'Montant payé non conforme aux prix officiels du livre.', 409);
            }

            $telWa = star_normaliser_tel((string)$row['telephone']);
            if ($telWa === null) {
                star_json_error('telephone_invalide',
                    'Numéro de téléphone du client invalide ou absent (' . star_h((string)$row['telephone']) .
                    ') — envoi WhatsApp impossible. Contactez le client manuellement.', 422);
            }

            // 🔒 Verrou atomique : un envoi ne peut jamais dépasser le nombre d'exemplaires payés
            $stmt = $db->prepare("UPDATE star_paiements SET telecharge_compte = telecharge_compte + 1
                                   WHERE reference = ? AND telecharge_compte < ?");
            $stmt->bind_param('si', $ref, $maxEnvois);
            $stmt->execute();
            $affecte = $stmt->affected_rows;
            $stmt->close();
            if ($affecte < 1) {
                star_json_error('deja_envoye',
                    'Ce paiement a déjà servi à envoyer le nombre d\'exemplaires payés (' . $maxEnvois . '). Envoi refusé.', 409);
            }

            $cheminLivre = __DIR__ . '/../livres-prive/de-lombre-a-la-lumiere--K7x2P9sQ4mW8.pdf';
            $legende = "📖 Voici votre exemplaire de « De l'Ombre à la Lumière » — Carry OTEMBA.\nMerci pour votre achat ! 🙏";
            [$ok, $erreur] = star_wa_send_document($telWa, $cheminLivre, 'De-l-Ombre-a-la-Lumiere--Carry-OTEMBA.pdf', $legende);

            if (!$ok) {
                // Échec réel d'envoi : on restitue le crédit consommé (le client n'a RIEN reçu)
                $stmt = $db->prepare("UPDATE star_paiements SET telecharge_compte = telecharge_compte - 1 WHERE reference = ?");
                $stmt->bind_param('s', $ref); $stmt->execute(); $stmt->close();
                star_json_error('envoi_echoue', $erreur, 502);
            }

            $msg = "Livre numérique « De l'Ombre à la Lumière » envoyé sur WhatsApp ($telWa) après validation manuelle.\nRéférence : $ref";
            $stmt = $db->prepare("INSERT INTO star_events (kind, title, message, client, telephone, page, ip)
                                   VALUES ('livre_telechargement', '📲 Livre envoyé sur WhatsApp', ?, ?, ?, 'admin/paiements.php', '')");
            $client = (string)$row['client'];
            $stmt->bind_param('sss', $msg, $client, $telWa);
            $stmt->execute(); $stmt->close();

            star_json_ok(['envoye' => true, 'telephone' => $telWa]);
            break;

        // ---- Changer le statut (nouveau → en cours → traité) ----
        case 'update_status':
            $id = (int)($in['id'] ?? 0);
            $status = (string)($in['status'] ?? '');
            if (!in_array($status, ['nouveau', 'en_cours', 'traite'], true)) {
                star_json_error('statut_invalide', 'Statut non reconnu.');
            }
            $stmt = $db->prepare("UPDATE star_events SET status=? WHERE id=?");
            $stmt->bind_param('si', $status, $id); $stmt->execute(); $stmt->close();
            star_json_ok();
            break;

        // ---- Supprimer un événement ----
        case 'delete':
            $id = (int)($in['id'] ?? 0);
            $stmt = $db->prepare("DELETE FROM star_events WHERE id=?");
            $stmt->bind_param('i', $id); $stmt->execute(); $stmt->close();
            star_json_ok();
            break;

        // ---- Export CSV (demandes) ----
        case 'export_csv':
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="staros-demandes-' . date('Y-m-d') . '.csv"');
            echo "\xEF\xBB\xBF"; // BOM pour Excel
            $out = fopen('php://output', 'w');
            fputcsv($out, ['ID', 'Type', 'Titre', 'Client', 'E-mail', 'Téléphone', 'Ville', 'Statut', 'Page', 'Date'], ';');
            $res = $db->query("SELECT * FROM star_events ORDER BY id DESC LIMIT 2000");
            while ($row = $res->fetch_assoc()) {
                fputcsv($out, [$row['id'], $row['kind'], $row['title'], $row['client'], $row['email'],
                               $row['telephone'], $row['ville'], $row['status'], $row['page'], $row['created_at']], ';');
            }
            fclose($out);
            exit;

        // ---- Événement de test (vérifier que toute la chaîne marche) ----
        case 'test_event':
            star_handle_public('request', [
                'type'    => 'Test système',
                'client'  => 'Test Admin',
                'email'   => 'test@star.local',
                'sujet'   => 'Vérification de la chaîne de données',
                'message' => 'Si vous voyez cet événement, la relation site ↔ backend fonctionne parfaitement. 🎉',
                'page'    => '/admin (test)',
            ]);
            break;
    }
}
