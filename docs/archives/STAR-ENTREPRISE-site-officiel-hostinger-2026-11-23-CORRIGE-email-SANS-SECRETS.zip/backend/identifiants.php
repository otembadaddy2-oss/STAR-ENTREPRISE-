<?php
/**
 * ============================================================
 *  STAR OS — IDENTIFIANTS ADMINISTRATEUR + RÉINITIALISATION
 * ============================================================
 *  Rôle :
 *   • vérifier les identifiants de connexion (base MySQL d'abord,
 *     puis repli automatique sur config.php)
 *   • compter les échecs de connexion
 *   • envoyer un code de vérification par e-mail (Brevo, secours mail())
 *   • enregistrer de nouveaux identifiants de façon fiable
 *
 *  GARANTIES DE SÉCURITÉ :
 *   • si la base MySQL est injoignable, la connexion continue de
 *     fonctionner avec config.php — jamais d'interruption de service
 *   • le code n'est JAMAIS stocké en clair (empreinte SHA-256 salée)
 *   • code valable 15 minutes, 3 essais maximum, puis détruit
 *   • envois limités : 1 toutes les 60 s, 5 par heure
 *   • après une réinitialisation, les anciens identifiants de
 *     config.php ne fonctionnent plus (la base fait foi)
 *
 *  Ce fichier ne modifie AUCUN autre fichier du site.
 * ============================================================
 */

require_once __DIR__ . '/db.php';

// Ce fichier ne doit jamais être ouvert directement par le navigateur.
if (isset($_SERVER['SCRIPT_FILENAME']) && realpath($_SERVER['SCRIPT_FILENAME']) === realpath(__FILE__)) {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'error' => 'acces_direct_interdit']);
    exit;
}

// Ce fichier ne peut être chargé qu'une fois (login.php et mot-de-passe.php
// peuvent l'inclure tous les deux au cours d'une même requête).
if (defined('STAR_IDENTIFIANTS_CHARGE')) return;
define('STAR_IDENTIFIANTS_CHARGE', true);

/* Portabilité : si l'extension mbstring venait à manquer sur le serveur, on
   retombe sur les équivalents standards. Sans cela, la page « Mot de passe »
   du tableau de bord (qui utilise mb_strlen) afficherait une page blanche.
   Les garde-fous function_exists évitent tout conflit si mbstring est présent. */
if (!function_exists('mb_strlen'))     { function mb_strlen($s, $e = null)     { return strlen((string)$s); } }
if (!function_exists('mb_strtolower')) { function mb_strtolower($s, $e = null) { return strtolower((string)$s); } }

// ---------------------------------------------------------------------------
//  Réglages
// ---------------------------------------------------------------------------
define('STAR_ID_MAX_TENTATIVES', 5);        // échecs avant de proposer la réinitialisation
define('STAR_ID_CODE_DUREE', 15 * 60);      // validité du code : 15 minutes
define('STAR_ID_CODE_ESSAIS', 3);           // essais de saisie du code
define('STAR_ID_ENVOI_INTERVALLE', 60);     // 1 envoi toutes les 60 secondes
define('STAR_ID_ENVOI_MAX_HEURE', 5);       // 5 envois par heure
define('STAR_ID_MDP_MIN', 8);               // longueur minimale du nouveau mot de passe

/** Adresse qui reçoit le code (celle de votre entreprise, déjà dans config.php). */
function star_id_email(): string
{
    return defined('STAR_NOTIFY_EMAIL') ? (string)STAR_NOTIFY_EMAIL : '';
}

/** Adresse affichée à l'écran, masquée (c****t.starentreprise@gmail.com). */
function star_id_email_masque(): string
{
    $e = star_id_email();
    if ($e === '' || strpos($e, '@') === false) return 'votre adresse e-mail';
    list($local, $dom) = explode('@', $e, 2);
    $n = strlen($local);
    $vis = $n <= 2 ? $local : substr($local, 0, 1) . str_repeat('*', max(3, $n - 2)) . substr($local, -1);
    return $vis . '@' . $dom;
}

// ---------------------------------------------------------------------------
//  ACCÈS BASE — toujours tolérant : ne plante JAMAIS la page
// ---------------------------------------------------------------------------
/**
 * Connexion MySQL dédiée, indépendante de star_db().
 * Retourne null si la base est injoignable : tout le reste du fichier
 * bascule alors automatiquement sur config.php.
 */
function star_id_db()
{
    static $db = false;
    if ($db !== false) return $db;

    $db = null;
    try {
        if (!defined('DB_HOST') || !defined('DB_NAME')) return null;
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        $c = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        $c->set_charset(defined('DB_CHARSET') ? DB_CHARSET : 'utf8mb4');
        star_id_tables($c);
        $db = $c;
    } catch (Throwable $e) {
        $db = null;   // base injoignable -> repli sur config.php
    }
    return $db;
}

/** Création des 3 tables nécessaires (uniquement si elles n'existent pas). */
function star_id_tables(mysqli $db): void
{
    static $fait = false;
    if ($fait) return;
    $fait = true;

    // Identifiants administrateur définis par une réinitialisation
    $db->query("CREATE TABLE IF NOT EXISTS star_admin (
        id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
        username VARCHAR(60) NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        origine VARCHAR(20) NOT NULL DEFAULT 'reinitialisation',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Codes de vérification envoyés par e-mail
    $db->query("CREATE TABLE IF NOT EXISTS star_reset (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        jeton CHAR(32) NOT NULL,
        code_hash CHAR(64) NOT NULL,
        email VARCHAR(190) NOT NULL DEFAULT '',
        ip VARCHAR(60) DEFAULT '',
        sent_via VARCHAR(12) DEFAULT '',
        attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
        used TINYINT(1) NOT NULL DEFAULT 0,
        expires_at DATETIME NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_jeton (jeton),
        INDEX idx_valides (used, expires_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Échecs de connexion, par adresse IP (durcissement anti force-brute)
    $db->query("CREATE TABLE IF NOT EXISTS star_login_fail (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        ip VARCHAR(60) NOT NULL DEFAULT '',
        username VARCHAR(60) DEFAULT '',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_ip_date (ip, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

// ---------------------------------------------------------------------------
//  IDENTIFIANTS EN VIGUEUR
// ---------------------------------------------------------------------------
/** Vrai si des identifiants ont déjà été enregistrés en base. */
function star_id_base_active(): bool
{
    $db = star_id_db();
    if (!$db) return false;
    $r = $db->query("SELECT password_hash FROM star_admin WHERE id = 1 LIMIT 1");
    if (!$r) return false;
    $row = $r->fetch_assoc();
    return !empty($row['password_hash']);
}

/** Identifiant actuellement valable (base si définie, sinon config.php). */
function star_id_utilisateur(): string
{
    $db = star_id_db();
    if ($db) {
        $r = $db->query("SELECT username FROM star_admin WHERE id = 1 LIMIT 1");
        if ($r && ($row = $r->fetch_assoc()) && !empty($row['username'])) {
            return (string)$row['username'];
        }
    }
    return defined('ADMIN_USERNAME') ? (string)ADMIN_USERNAME : '';
}

/**
 * Vérifie un couple identifiant / mot de passe.
 *  • si la base contient des identifiants -> eux seuls font foi
 *  • sinon -> constantes de config.php (comportement d'origine intact)
 */
function star_id_verifier(string $utilisateur, string $motdepasse): bool
{
    $utilisateur = trim($utilisateur);
    if ($utilisateur === '' || $motdepasse === '') return false;

    $db = star_id_db();
    if ($db) {
        $s = $db->prepare("SELECT username, password_hash FROM star_admin WHERE id = 1 LIMIT 1");
        if ($s && $s->execute()) {
            $res = $s->get_result();
            if ($row = $res->fetch_assoc()) {
                $s->close();
                return hash_equals((string)$row['username'], $utilisateur)
                    && password_verify($motdepasse, (string)$row['password_hash']);
            }
            if ($s) $s->close();
        }
    }

    // Repli : identifiants d'origine définis dans config.php
    if (!defined('ADMIN_USERNAME') || !defined('ADMIN_PASSWORD_HASH')) return false;
    return $utilisateur === (string)ADMIN_USERNAME
        && password_verify($motdepasse, (string)ADMIN_PASSWORD_HASH);
}

/**
 * Enregistre de nouveaux identifiants en base (après code validé).
 * Retourne true en cas de succès, sinon un message d'erreur.
 */
function star_id_enregistrer(string $utilisateur, string $motdepasse)
{
    $utilisateur = trim($utilisateur);

    if (!preg_match('/^[A-Za-z0-9._ -]{3,60}$/u', $utilisateur)) {
        return "Identifiant invalide : 3 à 60 caractères, lettres, chiffres, point, tiret, espace.";
    }
    if (strlen($motdepasse) < STAR_ID_MDP_MIN) {
        return "Le mot de passe doit contenir au moins " . STAR_ID_MDP_MIN . " caractères.";
    }
    if (strlen($motdepasse) > 200) {
        return "Le mot de passe est trop long (200 caractères maximum).";
    }
    if (strtolower($motdepasse) === strtolower($utilisateur)) {
        return "Le mot de passe ne peut pas être identique à l'identifiant.";
    }
    if (password_verify($motdepasse, defined('ADMIN_PASSWORD_HASH') ? (string)ADMIN_PASSWORD_HASH : '')) {
        return "Choisissez un mot de passe différent de l'ancien.";
    }

    $db = star_id_db();
    if (!$db) {
        return "Base de données injoignable : réessayez dans quelques minutes.";
    }

    $hash = password_hash($motdepasse, PASSWORD_DEFAULT);
    $s = $db->prepare("INSERT INTO star_admin (id, username, password_hash, origine)
                       VALUES (1, ?, ?, 'reinitialisation')
                       ON DUPLICATE KEY UPDATE username = VALUES(username),
                                               password_hash = VALUES(password_hash),
                                               origine = 'reinitialisation',
                                               updated_at = CURRENT_TIMESTAMP");
    if (!$s) return "Enregistrement impossible (préparation de la requête).";
    $s->bind_param('ss', $utilisateur, $hash);
    $ok = $s->execute();
    $s->close();
    if (!$ok) return "Enregistrement impossible (écriture en base).";

    // Trace d'audit dans votre table d'événements existante
    star_id_journal($db, "🔑 Identifiants administrateur réinitialisés", "Nouveaux identifiants créés via la procédure de récupération par e-mail.");
    return true;
}

/** Ajoute une ligne dans star_events (table déjà créée par db.php). */
function star_id_journal(mysqli $db, string $titre, string $message): void
{
    try {
        $s = $db->prepare("INSERT INTO star_events (kind, title, message, client, page, status, ip)
                           VALUES ('alert', ?, ?, 'Administrateur', 'admin/reinitialiser.php', 'nouveau', ?)");
        if ($s) {
            $ip = star_id_ip();
            $s->bind_param('sss', $titre, $message, $ip);
            $s->execute();
            $s->close();
        }
    } catch (Throwable $e) {
        // la journalisation ne doit jamais faire échouer la procédure
    }
}

// ---------------------------------------------------------------------------
//  COMPTEUR D'ÉCHECS DE CONNEXION
// ---------------------------------------------------------------------------
function star_id_ip(): string
{
    return substr((string)($_SERVER['REMOTE_ADDR'] ?? 'inconnue'), 0, 60);
}

/** Nombre d'échecs de connexion en cours (session + adresse IP). */
function star_id_tentatives(): int
{
    if (session_status() === PHP_SESSION_NONE) @session_start();
    $s = isset($_SESSION['staros_echecs']) ? (int)$_SESSION['staros_echecs'] : 0;

    // On retient le plus élevé des deux compteurs (session et IP)
    $db = star_id_db();
    if ($db) {
        $ip = star_id_ip();
        $stmt = $db->prepare("SELECT COUNT(*) AS n FROM star_login_fail
                              WHERE ip = ? AND created_at > (NOW() - INTERVAL 30 MINUTE)");
        if ($stmt) {
            $stmt->bind_param('s', $ip);
            if ($stmt->execute()) {
                $r = $stmt->get_result()->fetch_assoc();
                $s = max($s, (int)($r['n'] ?? 0));
            }
            $stmt->close();
        }
    }
    return $s;
}

/** Enregistre un échec de connexion. */
function star_id_echec(string $utilisateur = ''): void
{
    if (session_status() === PHP_SESSION_NONE) @session_start();
    $_SESSION['staros_echecs'] = (int)($_SESSION['staros_echecs'] ?? 0) + 1;

    $db = star_id_db();
    if ($db) {
        $ip = star_id_ip();
        $u = substr($utilisateur, 0, 60);
        $stmt = $db->prepare("INSERT INTO star_login_fail (ip, username) VALUES (?, ?)");
        if ($stmt) { $stmt->bind_param('ss', $ip, $u); $stmt->execute(); $stmt->close(); }
        // purge des lignes anciennes
        @$db->query("DELETE FROM star_login_fail WHERE created_at < (NOW() - INTERVAL 1 DAY)");
    }
}

/** Remet le compteur à zéro (après une connexion réussie). */
function star_id_raz(): void
{
    if (session_status() === PHP_SESSION_NONE) @session_start();
    unset($_SESSION['staros_echecs']);

    $db = star_id_db();
    if ($db) {
        $ip = star_id_ip();
        $stmt = $db->prepare("DELETE FROM star_login_fail WHERE ip = ?");
        if ($stmt) { $stmt->bind_param('s', $ip); $stmt->execute(); $stmt->close(); }
    }
}

/** La réinitialisation est-elle proposée ? (après 5 échecs) */
function star_id_reset_propose(): bool
{
    return star_id_tentatives() >= STAR_ID_MAX_TENTATIVES;
}

/** Combien d'essais restent avant de proposer la réinitialisation. */
function star_id_tentatives_restantes(): int
{
    return max(0, STAR_ID_MAX_TENTATIVES - star_id_tentatives());
}

// ---------------------------------------------------------------------------
//  CODE DE VÉRIFICATION PAR E-MAIL
// ---------------------------------------------------------------------------
/** Peut-on envoyer un code maintenant ? Retourne true ou un message d'attente. */
function star_id_envoi_autorise()
{
    if (session_status() === PHP_SESSION_NONE) @session_start();
    $maintenant = time();

    $dernier = (int)($_SESSION['star_reset_dernier_envoi'] ?? 0);
    if ($dernier && ($maintenant - $dernier) < STAR_ID_ENVOI_INTERVALLE) {
        return "Patientez " . (STAR_ID_ENVOI_INTERVALLE - ($maintenant - $dernier)) . " s avant un nouvel envoi.";
    }
    $historique = isset($_SESSION['star_reset_historique']) && is_array($_SESSION['star_reset_historique'])
        ? $_SESSION['star_reset_historique'] : [];
    $historique = array_values(array_filter($historique, function ($t) use ($maintenant) {
        return ($maintenant - (int)$t) < 3600;
    }));
    $_SESSION['star_reset_historique'] = $historique;
    if (count($historique) >= STAR_ID_ENVOI_MAX_HEURE) {
        return "Trop de codes demandés. Réessayez dans une heure.";
    }
    return true;
}

/**
 * Génère un code à 6 chiffres, le stocke haché et l'envoie par e-mail.
 * Retourne ['ok'=>bool, 'jeton'=>string, 'voie'=>string, 'message'=>string]
 */
function star_id_envoyer_code(): array
{
    $email = star_id_email();
    if ($email === '' || strpos($email, '@') === false) {
        return ['ok' => false, 'jeton' => '', 'voie' => '', 'message' => "Aucune adresse de récupération n'est configurée."];
    }
    $autorise = star_id_envoi_autorise();
    if ($autorise !== true) {
        return ['ok' => false, 'jeton' => '', 'voie' => '', 'message' => $autorise];
    }

    $db = star_id_db();
    if (!$db) {
        return ['ok' => false, 'jeton' => '', 'voie' => '',
                'message' => "Base de données injoignable : la réinitialisation par e-mail est momentanément indisponible. Connectez-vous avec vos identifiants habituels."];
    }

    // Invalide les codes précédents encore ouverts
    @$db->query("UPDATE star_reset SET used = 1 WHERE used = 0");

    $code  = (string)random_int(100000, 999999);
    $jeton = bin2hex(random_bytes(16));
    $hash  = hash('sha256', $code . '|' . $jeton . '|' . $email);   // jamais stocké en clair
    $ip    = star_id_ip();
    $expire = date('Y-m-d H:i:s', time() + STAR_ID_CODE_DUREE);

    $envoi = star_id_mail($email, $code, $jeton);
    if (!$envoi['ok']) {
        return ['ok' => false, 'jeton' => '', 'voie' => $envoi['voie'],
                'message' => "L'e-mail n'a pas pu partir (" . $envoi['voie'] . "). Réessayez dans une minute."];
    }

    $s = $db->prepare("INSERT INTO star_reset (jeton, code_hash, email, ip, sent_via, expires_at)
                       VALUES (?, ?, ?, ?, ?, ?)");
    if (!$s) return ['ok' => false, 'jeton' => '', 'voie' => $envoi['voie'], 'message' => "Enregistrement du code impossible."];
    $s->bind_param('ssssss', $jeton, $hash, $email, $ip, $envoi['voie'], $expire);
    $ok = $s->execute();
    $s->close();
    if (!$ok) return ['ok' => false, 'jeton' => '', 'voie' => $envoi['voie'], 'message' => "Enregistrement du code impossible."];

    if (session_status() === PHP_SESSION_NONE) @session_start();
    $_SESSION['star_reset_dernier_envoi'] = time();
    $h = isset($_SESSION['star_reset_historique']) && is_array($_SESSION['star_reset_historique'])
        ? $_SESSION['star_reset_historique'] : [];
    $h[] = time();
    $_SESSION['star_reset_historique'] = $h;
    $_SESSION['star_reset_jeton'] = $jeton;

    star_id_journal($db, "🔑 Code de réinitialisation envoyé", "Un code de vérification a été envoyé à " . star_id_email_masque() . " (voie : " . $envoi['voie'] . ").");

    return ['ok' => true, 'jeton' => $jeton, 'voie' => $envoi['voie'], 'message' => ''];
}

/**
 * Envoi du code par Brevo (voie principale), secours : fonction mail().
 * L'URL Brevo peut être redéfinie par la constante STAR_BREVO_URL (tests).
 */
function star_id_mail(string $destinataire, string $code, string $jeton): array
{
    $sujet  = "🔑 STAR OS — Votre code de réinitialisation : " . $code;
    $url    = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https://' : 'http://')
            . ($_SERVER['HTTP_HOST'] ?? 'starentreprise.com')
            . rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/admin/'), '/') . '/reinitialiser.php';

    $corps  = "STAR OS — Réinitialisation de vos identifiants\n";
    $corps .= "================================================\n\n";
    $corps .= "Votre code de vérification :\n\n";
    $corps .= "        " . $code . "\n\n";
    $corps .= "Valable " . (STAR_ID_CODE_DUREE / 60) . " minutes, " . STAR_ID_CODE_ESSAIS . " essais de saisie.\n\n";
    $corps .= "Page à ouvrir :\n" . $url . "\n\n";
    $corps .= "------------------------------------------------\n";
    $corps .= "Si vous n'êtes pas à l'origine de cette demande, ignorez ce\n";
    $corps .= "message : rien ne sera modifié sans le code ci-dessus.\n";
    $corps .= "================================================\n";

    // ---- Voie 1 : API Brevo (déjà configurée et testée sur votre compte) ----
    if (defined('BREVO_API_KEY') && BREVO_API_KEY !== '' && strpos(BREVO_API_KEY, 'METTEZ') === false
        && function_exists('curl_init')) {

        $apiUrl = defined('STAR_BREVO_URL') ? STAR_BREVO_URL : 'https://api.brevo.com/v3/smtp/email';
        $payload = [
            'sender'      => [
                'name'  => defined('BREVO_SENDER_NAME') ? BREVO_SENDER_NAME : 'STAR ENTREPRISE',
                'email' => defined('BREVO_SENDER_EMAIL') ? BREVO_SENDER_EMAIL : $destinataire,
            ],
            'to'          => [['email' => $destinataire]],
            'subject'     => $sujet,
            'textContent' => $corps,
            'tags'        => ['star-os', 'reinitialisation-identifiants'],
        ];
        $ch = curl_init($apiUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE),
            CURLOPT_HTTPHEADER     => [
                'api-key: ' . BREVO_API_KEY,
                'Content-Type: application/json',
                'Accept: application/json',
            ],
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT        => 20,
        ]);
        $res  = curl_exec($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($res !== false && $http >= 200 && $http < 300) {
            return ['ok' => true, 'voie' => 'brevo'];
        }
    }

    // ---- Voie 2 : fonction mail() de l'hébergeur ----
    $from    = defined('STAR_FROM_EMAIL') ? STAR_FROM_EMAIL : ('noreply@' . ($_SERVER['HTTP_HOST'] ?? 'localhost'));
    $headers = 'From: ' . $from . "\r\n" . 'Content-Type: text/plain; charset=utf-8';
    $sujetM  = '=?UTF-8?B?' . base64_encode($sujet) . '?=';
    $ok = false;
    try { $ok = (bool)@mail($destinataire, $sujetM, $corps, $headers); } catch (Throwable $e) { $ok = false; }
    if ($ok) return ['ok' => true, 'voie' => 'mail'];

    return ['ok' => false, 'voie' => 'echec'];
}

/**
 * Vérifie le code saisi. Retourne true si le code est bon.
 * Incrémente le compteur d'essais ; au-delà de 3, le code est détruit.
 */
function star_id_verifier_code(string $code, string $jeton): bool
{
    $code = trim($code);
    if (!preg_match('/^\d{6}$/', $code) || $jeton === '') return false;

    $db = star_id_db();
    if (!$db) return false;

    $s = $db->prepare("SELECT id, code_hash, email, attempts FROM star_reset
                       WHERE jeton = ? AND used = 0 AND expires_at > NOW() LIMIT 1");
    if (!$s) return false;
    $s->bind_param('s', $jeton);
    if (!$s->execute()) { $s->close(); return false; }
    $row = $s->get_result()->fetch_assoc();
    $s->close();
    if (!$row) return false;

    if ((int)$row['attempts'] >= STAR_ID_CODE_ESSAIS) {
        star_id_detruire_code((int)$row['id']);
        return false;
    }

    $attendu = hash('sha256', $code . '|' . $jeton . '|' . $row['email']);
    if (hash_equals((string)$row['code_hash'], $attendu)) {
        return true;
    }

    // Mauvais code : on incrémente, on invalide au-delà du quota
    $u = $db->prepare("UPDATE star_reset SET attempts = attempts + 1 WHERE id = ?");
    if ($u) { $id = (int)$row['id']; $u->bind_param('i', $id); $u->execute(); $u->close(); }
    if ((int)$row['attempts'] + 1 >= STAR_ID_CODE_ESSAIS) star_id_detruire_code((int)$row['id']);
    return false;
}

/** Marque un code comme consommé. */
function star_id_consommer_code(string $jeton): void
{
    $db = star_id_db();
    if (!$db) return;
    $s = $db->prepare("UPDATE star_reset SET used = 1 WHERE jeton = ?");
    if ($s) { $s->bind_param('s', $jeton); $s->execute(); $s->close(); }
}

function star_id_detruire_code(int $id): void
{
    $db = star_id_db();
    if (!$db) return;
    $s = $db->prepare("UPDATE star_reset SET used = 1 WHERE id = ?");
    if ($s) { $s->bind_param('i', $id); $s->execute(); $s->close(); }
}

/** Nombre d'essais restants pour le code en cours. */
function star_id_code_essais_restants(string $jeton): int
{
    $db = star_id_db();
    if (!$db) return 0;
    $s = $db->prepare("SELECT attempts FROM star_reset WHERE jeton = ? AND used = 0 AND expires_at > NOW() LIMIT 1");
    if (!$s) return 0;
    $s->bind_param('s', $jeton);
    if (!$s->execute()) { $s->close(); return 0; }
    $row = $s->get_result()->fetch_assoc();
    $s->close();
    if (!$row) return 0;
    return max(0, STAR_ID_CODE_ESSAIS - (int)$row['attempts']);
}
