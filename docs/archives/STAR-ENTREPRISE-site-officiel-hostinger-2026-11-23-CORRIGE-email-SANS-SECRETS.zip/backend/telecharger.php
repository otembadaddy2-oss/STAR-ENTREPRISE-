<?php
/**
 * ============================================================
 *  STAR OS — TÉLÉCHARGEMENT VERROUILLÉ DU LIVRE
 *  « De l'Ombre à la Lumière » — Carry OTEMBA
 * ------------------------------------------------------------
 *  LE LIVRE NE SERT JAMAIS SANS PAIEMENT CONFIRMÉ. Point final.
 *
 *  Deux preuves de paiement acceptées (au moins UNE exigée) :
 *   a) La RÉFÉRENCE existe dans la BDD (table star_paiements)
 *      avec statut = 'succes' ET l'article du livre.
 *      → voie normale sur l'hébergement Hostinger.
 *   b) Un JETON signé (HMAC-SHA256 à partir de la clé secrète
 *      OpenPay) : fourni par le serveur au moment du succès.
 *      → voie de secours (site déployé sur Vercel sans base).
 *
 *  Sans preuve : HTTP 403 + page 🔒 aimable qui renvoie vers
 *  la page d'achat. Le fichier PDF vit dans /livres-prive/,
 *  dossier INTERDIT d'accès direct par .htaccess.
 * ============================================================
 */

require_once __DIR__ . '/db.php';

// ------------------------------------------------------------
//  RÉGLAGES (ne pas toucher)
// ------------------------------------------------------------
define('LIVRE_FICHIER', __DIR__ . '/../livres-prive/de-lombre-a-la-lumiere--K7x2P9sQ4mW8.pdf');
define('LIVRE_NOM_TELECHARGEMENT', 'De-l-Ombre-a-la-Lumiere--Carry-OTEMBA.pdf');
define('LIVRE_SECRET_SEL', '|livre-carryo-otemba');
define('LIVRE_PAGE_ACHAT', '/carryo-oeuvre-achat.html?id=15');
define('LIVRE_PRIX_1_EXEMPLAIRE', 12550);   // 🔒 prix officiel — 1 exemplaire = 1 téléchargement autorisé
define('LIVRE_PRIX_2_EXEMPLAIRES', 25100);  // 🔒 prix officiel — 2 exemplaires = 2 téléchargements autorisés

// ------------------------------------------------------------
//  PING — simple test de vie (utilisé par le site pour savoir
//  si la porte serveur existe : ?ping=1 → {"ok":true,...})
// ------------------------------------------------------------
if (isset($_GET['ping'])) {
    star_json_ok([
        'service' => 'telechargement-livre',
        'version' => '1.0',
        'livre'   => 'De l\'Ombre à la Lumière — Carry OTEMBA',
        'fichier_present' => is_file(LIVRE_FICHIER),
    ]);
}

// ------------------------------------------------------------
//  1) Récupérer la référence + le jeton éventuel
// ------------------------------------------------------------
$ref = star_cut((string)($_GET['ref'] ?? $_POST['ref'] ?? ''), 60);
$tok = trim((string)($_GET['tok'] ?? $_POST['tok'] ?? ''));

if ($ref === '' || !preg_match('/^[A-Za-z0-9\-\_]{4,60}$/', $ref)) {
    livre_refuse('reference', 'Référence de paiement absente ou invalide.');
}

// ------------------------------------------------------------
//  2) PREUVE A — la référence est un paiement réussi du livre (BDD)
// ------------------------------------------------------------
$autorise = false;
$motif = '';
$maxTelechargements = 0;   // nombre d'exemplaires payés = nombre de téléchargements autorisés pour cette référence
try {
    $db = star_db();
    $stmt = $db->prepare("SELECT article, montant, statut, telecharge_compte FROM star_paiements WHERE reference = ? LIMIT 1");
    $stmt->bind_param('s', $ref);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($row) {
        if ($row['statut'] !== 'succes') {
            livre_refuse('pas_paye', 'Ce paiement n\'est pas confirmé (statut : « ' . $row['statut'] . ' »). Payez d\'abord le livre puis revenez avec votre référence.');
        }
        // 🔒 Le montant DOIT être l'un des deux prix officiels du livre (double verrou, en plus du catalogue serveur)
        $montantPaye = (int)$row['montant'];
        if ($montantPaye === LIVRE_PRIX_1_EXEMPLAIRE) {
            $maxTelechargements = 1;
        } elseif ($montantPaye === LIVRE_PRIX_2_EXEMPLAIRES) {
            $maxTelechargements = 2;
        } else {
            livre_refuse('montant_incorrect',
                'Le paiement référencé ne correspond à aucun prix officiel du livre (' .
                number_format(LIVRE_PRIX_1_EXEMPLAIRE, 0, ',', ' ') . ' FCFA pour 1 exemplaire, ou ' .
                number_format(LIVRE_PRIX_2_EXEMPLAIRES, 0, ',', ' ') . ' FCFA pour 2 exemplaires). Téléchargement refusé.');
        }
        $art = function_exists('mb_strtolower') ? mb_strtolower((string)$row['article'], 'UTF-8') : strtolower((string)$row['article']);
        if (strpos($art, 'ombre') !== false && strpos($art, 'lumi') !== false) {
            $autorise = true;
            $motif = 'bdd';
        }
    }
} catch (Throwable $e) {
    // Base injoignable : on continue avec la preuve B (jeton) si fournie
}

// ------------------------------------------------------------
//  3) PREUVE B — jeton signé HMAC (secours Vercel / preuve serveur)
// ------------------------------------------------------------
if (!$autorise && $tok !== '' && preg_match('/^[a-f0-9]{64}$/', $tok)) {
    $cle = defined('OPENPAY_API_KEY') ? OPENPAY_API_KEY : '';
    if ($cle !== '' && strpos($cle, 'METTEZ') === false) {
        $attendu = hash_hmac('sha256', $ref . LIVRE_SECRET_SEL, $cle);
        if (hash_equals($attendu, $tok)) {
            $autorise = true;
            $motif = 'jeton';
        }
    }
}

if (!$autorise) {
    livre_refuse('aucune_preuve', 'Aucun paiement confirmé ne correspond à cette référence.');
}

// ------------------------------------------------------------
//  3bis) 🔒 VERROU ANTI-FRAUDE — un paiement ne débloque QUE le nombre
//  d'exemplaires réellement payés (1 ou 2). Chaque téléchargement
//  consomme un exemplaire ; une fois le quota atteint, la référence
//  se bloque automatiquement — même avec le même lien, la même minute.
//  Incrément ATOMIQUE (une seule requête SQL) pour qu'aucune double
//  tentative simultanée ne puisse voler un exemplaire supplémentaire.
//  N'existe que pour la preuve A (base de données) : la preuve B
//  (jeton, utilisée seulement si la base est injoignable) n'a par
//  nature aucun compteur à consulter — c'est le compromis déjà choisi
//  par le mécanisme de secours existant.
// ------------------------------------------------------------
if ($motif === 'bdd') {
    $stmt = $db->prepare("UPDATE star_paiements SET telecharge_compte = telecharge_compte + 1 WHERE reference = ? AND telecharge_compte < ?");
    $stmt->bind_param('si', $ref, $maxTelechargements);
    $stmt->execute();
    $affecte = $stmt->affected_rows;
    $stmt->close();
    if ($affecte < 1) {
        livre_refuse('deja_telecharge',
            'Ce paiement a déjà servi pour télécharger le nombre d\'exemplaires payés (' . $maxTelechargements .
            ($maxTelechargements > 1 ? ' exemplaires' : ' exemplaire') . '). Pour la sécurité de votre achat, chaque ' .
            'paiement n\'ouvre droit qu\'à ce nombre de téléchargements. Besoin d\'un exemplaire de plus ? Contactez le ' .
            '+242 06 656 50 50.');
    }
}

// ------------------------------------------------------------
//  4) Paiement PROUVÉ → journaliser + servir le livre
// ------------------------------------------------------------
try {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $msg = "Livre numérique « De l'Ombre à la Lumière » (Carry OTEMBA) téléchargé.\nRéférence de paiement : $ref\nPreuve : $motif";
    $stmt = $db->prepare("INSERT INTO star_events (kind, title, message, client, telephone, page, ip) VALUES ('livre_telechargement', '⬇️ Téléchargement du livre numérique', ?, 'Acheteur livre', '', 'carryo-oeuvre-achat.html', ?)");
    $stmt->bind_param('ss', $msg, $ip);
    $stmt->execute();
    $stmt->close();
} catch (Throwable $e) { /* le journal ne doit jamais bloquer le téléchargement */ }

$taille = filesize(LIVRE_FICHIER);
http_response_code(200);
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . LIVRE_NOM_TELECHARGEMENT . '"');
header('Content-Length: ' . $taille);
header('Cache-Control: no-store, no-cache, must-revalidate');
header('X-Content-Type-Options: nosniff');
$flux = fopen(LIVRE_FICHIER, 'rb');
fpassthru($flux);
fclose($flux);
exit;

// ------------------------------------------------------------
//  PAGE DE REFUS — aimable, claire, renvoie vers l'achat
// ------------------------------------------------------------
function livre_refuse(string $code, string $message): void
{
    http_response_code(403);
    header('Content-Type: text/html; charset=utf-8');
    $msg = star_h($message);
    $url = LIVRE_PAGE_ACHAT;
    echo '<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8">'
       . '<meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<title>🔒 Téléchargement verrouillé — CARRY.O AFRIQUE</title>'
       . '<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0B1F3A;font-family:system-ui,Segoe UI,Arial,sans-serif;padding:20px;box-sizing:border-box}'
       . '.card{background:#fff;border-radius:22px;max-width:520px;width:100%;padding:38px 34px;text-align:center;box-shadow:0 30px 80px rgba(0,0,0,.45)}'
       . '.ico{font-size:56px}.t{color:#0B1F3A;font-size:21px;font-weight:800;margin:14px 0 8px}'
       . '.m{color:#64748B;font-size:14.5px;line-height:1.6;margin:0 0 22px}'
       . '.btn{display:inline-block;background:linear-gradient(135deg,#D4AF37,#C59B27);color:#0B1F3A;font-weight:800;text-decoration:none;padding:13px 26px;border-radius:26px;font-size:15px}'
       . '.note{margin-top:16px;font-size:12px;color:#94A3B8}</style></head><body><div class="card">'
       . '<div class="ico">🔒</div>'
       . '<div class="t">Téléchargement verrouillé</div>'
       . '<p class="m">Le livre numérique <b>« De l\'Ombre à la Lumière »</b> de <b>Carry OTEMBA</b> ne peut être téléchargé qu\'après un paiement confirmé.<br><br>' . $msg . '<br><br>Payez <b>12 550 FCFA</b> par MTN Money : le bouton de téléchargement se débloque <b>immédiatement</b> après validation.</p>'
       . '<a class="btn" href="' . $url . '">← Aller à la page d\'achat du livre</a>'
       . '<div class="note">Déjà payé ? Reprenez exactement votre référence de paiement. Besoin d\'aide : +242 06 656 50 50</div>'
       . '</div></body></html>';
    exit;
}
