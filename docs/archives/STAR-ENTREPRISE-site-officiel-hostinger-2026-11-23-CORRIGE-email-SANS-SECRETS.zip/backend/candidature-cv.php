<?php
/**
 * ============================================================
 *  STAR OS — CANDIDATURE SPONTANÉE AVEC CV (page Carrières)
 * ------------------------------------------------------------
 *  Point d'entrée dédié (distinct de api.php) car il reçoit un
 *  fichier : multipart/form-data, pas du JSON.
 *
 *  À réception :
 *   1. Le CV est vérifié (format, taille, contenu réel) puis
 *      enregistré dans backend/cv-recus/ (dossier protégé par
 *      .htaccess — jamais accessible publiquement).
 *   2. Un e-mail part vers STAR_NOTIFY_EMAIL (contact.starentreprise@
 *      gmail.com) avec le CV en pièce jointe — via Brevo, déjà
 *      configuré et testé.
 *   3. Une alerte WhatsApp part vers le numéro indiqué ci-dessous —
 *      inactive tant que WHATSAPP_TOKEN / WHATSAPP_PHONE_NUMBER_ID
 *      ne sont pas renseignés dans config.php (star_wa_send() ne
 *      fait alors rien, sans erreur).
 *   4. La candidature apparaît dans /admin/ (onglet Demandes),
 *      exactement comme les candidatures sans CV.
 * ============================================================
 */

require_once __DIR__ . '/db.php';

star_cors();

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    star_json_error('methode_invalide', 'Méthode non autorisée.', 405);
}

star_require_api_key();
star_rate_limit();

// ------------------------------------------------------------
//  Numéro WhatsApp qui reçoit l'alerte temps réel des candidatures.
//  ⚠️ C'est le numéro business (+242 06 656 50 50) : sur l'API Cloud
//  Meta, ce numéro ne peut pas recevoir de notification « app »
//  classique sur un téléphone (il est consommé par l'API). Le
//  message part bel et bien, mais consultez-le via /admin/whatsapp.php
//  plutôt que d'attendre une alerte sur votre téléphone.
// ------------------------------------------------------------
define('CANDIDATURE_WA_DESTINATAIRE', '242066565050');

// ------------------------------------------------------------
//  1) Champs texte du formulaire
// ------------------------------------------------------------
$nom        = star_cut($_POST['nom'] ?? '', 180);
$telephone  = star_cut($_POST['telephone'] ?? '', 55);
$email      = star_cut($_POST['email'] ?? '', 180);
$domaine    = star_cut($_POST['domaine'] ?? '', 120);
$poste      = star_cut($_POST['poste'] ?? '', 180);
$messageTxt = star_cut($_POST['message'] ?? '', 2000);
$page       = star_cut($_POST['page'] ?? 'carrieres.html', 250);

if ($nom === '' || $telephone === '') {
    star_json_error('champs_requis', 'Le nom et le téléphone sont obligatoires.', 400);
}

// ------------------------------------------------------------
//  2) Le fichier CV — obligatoire, PDF/DOC/DOCX, 5 Mo max
// ------------------------------------------------------------
if (empty($_FILES['cv']) || !isset($_FILES['cv']['error']) || $_FILES['cv']['error'] !== UPLOAD_ERR_OK) {
    star_json_error('cv_requis', 'Le CV (PDF ou Word) est obligatoire et n\'a pas pu être reçu. Réessayez ou vérifiez sa taille.', 400);
}
$fichier = $_FILES['cv'];

$tailleMaxOctets = 5 * 1024 * 1024; // 5 Mo
if ((int)$fichier['size'] > $tailleMaxOctets) {
    star_json_error('cv_trop_lourd', 'Le CV dépasse la taille maximale autorisée (5 Mo).', 400);
}

$extension = strtolower((string)pathinfo((string)$fichier['name'], PATHINFO_EXTENSION));
$extensionsAutorisees = ['pdf', 'doc', 'docx'];
if (!in_array($extension, $extensionsAutorisees, true)) {
    star_json_error('cv_format_invalide', 'Format de CV non accepté. Formats autorisés : PDF, DOC ou DOCX.', 400);
}

// Vérification du contenu RÉEL du fichier (empêche un exécutable renommé « .pdf »)
$typesAutorisesParExtension = [
    'pdf'  => ['application/pdf'],
    'doc'  => ['application/msword', 'application/x-ole-storage'],
    'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip'],
];
if (function_exists('finfo_open')) {
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeReel = (string)finfo_file($finfo, $fichier['tmp_name']);
    finfo_close($finfo);
    if (!in_array($mimeReel, $typesAutorisesParExtension[$extension] ?? [], true)) {
        star_json_error('cv_type_suspect', 'Le contenu du fichier ne correspond pas à son extension. Envoyez un vrai PDF ou document Word.', 400);
    }
}

// ------------------------------------------------------------
//  3) Enregistrement dans le dossier protégé backend/cv-recus/
// ------------------------------------------------------------
$dossier = __DIR__ . '/cv-recus';
if (!is_dir($dossier)) @mkdir($dossier, 0750, true);
$nomStocke = date('Ymd-His') . '-' . bin2hex(random_bytes(6)) . '.' . $extension;
$cheminComplet = $dossier . '/' . $nomStocke;
if (!move_uploaded_file($fichier['tmp_name'], $cheminComplet)) {
    star_json_error('cv_echec_stockage', 'Impossible d\'enregistrer le CV sur le serveur. Réessayez.', 500);
}
$nomAffiche = 'CV - ' . preg_replace('/[^A-Za-z0-9 \-]/u', '', $nom) . '.' . $extension;

// ------------------------------------------------------------
//  4) Journalisation (apparaît dans /admin/ → Demandes, comme les
//     candidatures sans CV) + fiche client
// ------------------------------------------------------------
$ip = substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 60);
$lignes = [
    'Candidature spontanée avec CV — STAR ENTREPRISE',
    'Nom : ' . $nom,
    'Téléphone : ' . $telephone,
    'E-mail : ' . ($email !== '' ? $email : 'non précisé'),
    'Domaine visé : ' . ($domaine !== '' ? $domaine : 'non précisé'),
];
if ($poste !== '') $lignes[] = 'Poste souhaité : ' . $poste;
if ($messageTxt !== '') $lignes[] = 'Message : ' . $messageTxt;
$lignes[] = 'Fichier CV : ' . $nomStocke . ' (' . round(((int)$fichier['size']) / 1024) . ' Ko)';
$msgComplet = implode("\n", $lignes);
$sujet = 'Candidature avec CV — ' . ($domaine !== '' ? $domaine : 'domaine non précisé') . ($poste !== '' ? ' / ' . $poste : '');

$db = star_db();
$stmt = $db->prepare("INSERT INTO star_events (kind, title, message, client, email, telephone, page, ip)
                      VALUES ('candidature', ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param('sssssss', $sujet, $msgComplet, $nom, $email, $telephone, $page, $ip);
$stmt->execute();
$stmt->close();

star_upsert_client($db, $nom, $email, $telephone, '');

// ------------------------------------------------------------
//  5) Notifications — e-mail (CV joint) + WhatsApp (alerte texte)
// ------------------------------------------------------------
star_notify_email_cv($sujet, $msgComplet, $nom, $email, $telephone, $cheminComplet, $nomAffiche);

$texteWa = "📄 Nouvelle candidature — STAR ENTREPRISE\n" .
    "Nom : $nom\nTéléphone : $telephone\n" .
    ($domaine !== '' ? "Domaine : $domaine\n" : '') .
    ($poste !== '' ? "Poste : $poste\n" : '') .
    "CV reçu — pièce jointe par e-mail, détail complet dans /admin/.";
star_wa_send(CANDIDATURE_WA_DESTINATAIRE, $texteWa);

star_json_ok(['message' => 'Candidature et CV bien reçus. Merci !']);
