/* ============================================================
 *  STAR PAIEMENT — Mode SIMPLE (sans backend PHP)
 *  ------------------------------------------------------------
 *  Cette fonction Vercel appelle directement OpenPay (MTN Money).
 *  La clé OpenPay vit dans les VARIABLES D'ENVIRONNEMENT Vercel
 *  (Settings → Environment Variables → OPENPAY_API_KEY) :
 *  elle n'est JAMAIS envoyée au navigateur.
 *
 *  Pour réactiver le mode « relais vers backend PHP » plus tard,
 *  il suffira de remplacer ce fichier par la version relais.
 * ============================================================ */
const URL_OPENPAY = 'https://api.openpay-cg.com/v1/transaction/payment';
const CLE_SITE    = 'star-os-live-2026-secret-key'; // comme star-paiement.js
const crypto      = require('crypto');               // sert à signer les jetons de téléchargement (livre)

module.exports = async function handler(req, res) {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');

    // -------- GET = test de vie (ping) --------
    if (req.method !== 'POST') {
        res.status(200).send(JSON.stringify({
            ok: true, service: 'STAR PAIEMENT', version: '1.0-simple',
            provider: 'MTN Money', mode: 'live (OpenPay direct)',
            cle_openpay: process.env.OPENPAY_API_KEY ? 'configurée ✔' : 'MANQUANTE ⚠️ (ajoutez OPENPAY_API_KEY dans Vercel → Settings → Environment Variables)'
        }));
        return;
    }

    let corps = req.body || {};
    if (typeof corps === 'string') { try { corps = JSON.parse(corps); } catch (e) { corps = {}; } }
    const action = String(corps.action || '').toLowerCase();

    if (corps.api_key !== CLE_SITE) {
        res.status(403).send(JSON.stringify({ ok: false, error: 'cle_invalide', message: 'Clé site invalide ou absente.' }));
        return;
    }

    // -------- pay_status : informatif (OpenPay répond en direct, en une fois) --------
    if (action === 'pay_status') {
        res.status(200).send(JSON.stringify({ ok: true, payment: { reference: String(corps.reference || ''), statut: 'attente' } }));
        return;
    }

    if (action !== 'pay_start') {
        res.status(404).send(JSON.stringify({ ok: false, error: 'action_inconnue', message: 'Action inconnue.' }));
        return;
    }

    // -------- pay_start : créer le paiement MTN Money --------
    const cle = process.env.OPENPAY_API_KEY;
    if (!cle) {
        res.status(503).send(JSON.stringify({
            ok: false, error: 'cle_manquante',
            message: 'Clé OpenPay non configurée : Vercel → Settings → Environment Variables → OPENPAY_API_KEY, puis Redeploy.'
        }));
        return;
    }

    const d = corps.data || corps;
    const montant = parseInt(String(d.montant ?? d.amount ?? '0').replace(/[^0-9]/g, ''), 10) || 0;
    const tel = normaliserTel(String(d.telephone || d.phone || d.payment_phone_number || ''));
    const article = couper(String(d.article || d.title || 'Test paiement'), 180);
    const client = couper(String(d.client || d.nom || 'Client Test'), 180);

    if (montant < 100 || montant > 99999999) {
        res.status(400).send(JSON.stringify({ ok: false, error: 'montant_invalide', message: 'Le montant doit être entre 100 et 99 999 999 FCFA.' }));
        return;
    }
    if (!tel) {
        res.status(400).send(JSON.stringify({ ok: false, error: 'telephone_invalide', message: 'Numéro MTN invalide (ex. 06 555 12 34).' }));
        return;
    }

    // 🔒 CATALOGUE SERVEUR — le montant DOIT correspondre au prix officiel.
    // C'est le serveur qui fait foi : une requête falsifiée est refusée (403),
    // aucun paiement n'est lancé.
    const prix = prixCatalogue(article);
    if (prix === null) {
        res.status(403).send(JSON.stringify({ ok: false, error: 'article_inconnu', message: 'Article non reconnu par le catalogue officiel du site. Achat refusé.' }));
        return;
    }
    if (montant !== prix) {
        res.status(403).send(JSON.stringify({
            ok: false, error: 'montant_non_conforme',
            message: 'Montant refusé : le prix officiel de cet article est de ' + prix + ' FCFA, pas ' + montant + ' FCFA. Achat bloqué.'
        }));
        return;
    }

    const reference = 'STARV-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).slice(2, 7).toUpperCase();

    try {
        const r = await fetch(URL_OPENPAY, {
            method: 'POST',
            headers: {
                'XO-API-KEY': cle,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                amount: montant,
                payment_phone_number: tel,
                provider: 'MTN',
                customer_external_id: reference,
                customer: { name: client, phone: tel },
                metadata: { article: article, source: 'starentreprise-vercel', reference: reference }
            })
        });
        const j = await r.json().catch(() => ({}));
        const status = String(j.status || '').toLowerCase();
        const msgOp = String(j.message || j.detail || j.error || '');
        let statut = 'echec';
        if (estEncaisse(status, msgOp)) statut = 'succes';
        else if (['pending', 'processing', 'initiated', 'waiting', 'attente', 'queued', 'success'].indexOf(status) >= 0
            || (status === '' && (j.reference || reference))) statut = 'attente';

        // 📖 Livre : après SUCCÈS confirmé par OpenPay, on émet un jeton signé
        //    qui déverrouille le téléchargement via /api/telecharger-livre.
        //    Le jeton n'existe JAMAIS sans succès → impossible à falsifier côté client.
        const refFinale = j.reference || reference;
        const dlToken = (statut === 'succes')
            ? crypto.createHmac('sha256', cle).update(String(refFinale) + '|livre-carryo-otemba').digest('hex')
            : undefined;

        res.status(200).send(JSON.stringify({
            ok: true,
            reference: refFinale,
            statut: statut,
            montant: montant,
            devise: 'XAF',
            mode: 'live',
            event_enregistre: true,
            dl_token: dlToken,
            message: msgOp || (statut === 'succes' ? 'Paiement confirmé. Merci !' : (statut === 'attente' ? 'Validez sur votre téléphone…' : 'Le paiement a échoué.'))
        }));
    } catch (e) {
        res.status(200).send(JSON.stringify({ ok: false, error: 'reseau', message: 'OpenPay injoignable : ' + e.message }));
    }
};

function normaliserTel(raw) {
    let n = String(raw || '').replace(/[^0-9]/g, '');
    if (!n) return null;
    if (n.startsWith('00')) n = n.slice(2);
    if (n.startsWith('242')) return n.length === 12 ? n : null;
    if (n.length === 9 && n[0] === '0') return '242' + n;
    if (n.length === 8 && ['4', '5', '6'].indexOf(n[0]) >= 0) return '2420' + n;
    return null;
}
function couper(s, max) { return s.length > max ? s.slice(0, max - 1) + '…' : s; }
/** Catalogue OFFICIEL des articles vendus (libellé normalisé → prix FCFA).
 *  Identique à celui de backend/paiement.php — source : galerie carryo-oeuvre-achat.html. */
const CATALOGUE = {
    'regards croises': 150000,
    'fragments de memoire': 180000,
    'eclats d ebene': 120000,
    'la porteuse': 140000,
    'racines': 220000,
    'regard sauvage': 200000,
    'marche de couleurs': 250000,
    'portrait d un sage': 160000,
    'elegance': 230000,
    'scene de vie': 300000,
    'visages multiples': 190000,
    'kaleidoscope': 170000,
    'vibrations d afrique': 190000,
    'empreintes': 175000,
    'mosaique urbaine': 240000,
    'de l ombre a la lumiere 2 exemplaires': 25100,
    'de l ombre a la lumiere': 12550
};
/** Insensible à la casse, aux accents et à la ponctuation. */
function normaliserLibelle(s) {
    return String(s || '')
        .toLowerCase()
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .replace(/œ/g, 'oe').replace(/æ/g, 'ae')
        .replace(/[^a-z0-9]+/g, ' ')
        .trim();
}
/** Prix officiel d'un article, ou null s'il est inconnu du catalogue.
 *  Le libellé du catalogue le plus LONG qui correspond l'emporte (les
 *  variantes « N exemplaires » d'un même article sont volontairement
 *  imbriquées) — identique à backend/paiement.php. */
function prixCatalogue(article) {
    const norm = normaliserLibelle(article);
    if (!norm) return null;
    let meilleurTitre = null, trouve = null;
    for (const titre of Object.keys(CATALOGUE)) {
        if (!titre || norm.indexOf(titre) === -1) continue;
        if (meilleurTitre === null || titre.length > meilleurTitre.length) {
            meilleurTitre = titre;
            trouve = CATALOGUE[titre];
        }
    }
    return trouve;
}
/** Argent réellement encaissé — pas un simple accusé de réception de la requête. */
function estEncaisse(status, msg) {
    status = String(status || '').toLowerCase();
    msg = String(msg || '');
    if (['paid', 'completed', 'complete', 'successful', 'succes'].indexOf(status) >= 0) return true;
    if (status !== 'success') return false;
    if (!msg) return false;
    if (/initi[eé]|en attente|pending|processing|envoy[eé]|validez|ussd|push/i.test(msg)) return false;
    return /effectu[ée].*succ[eè]s|paiement\s+(réussi|reussi|confirm[eé])|successfully\s+(paid|completed)|paid\s+successfully/i.test(msg);
}
