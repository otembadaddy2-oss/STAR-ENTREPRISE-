/* ============================================================
 *  Relais Vercel — /api/star-os → (backend PHP)/backend/api.php
 *  ------------------------------------------------------------
 *  Le site appelle /api/star-os (même domaine Vercel → aucun
 *  blocage navigateur), et cette petite fonction relaie la
 *  demande vers votre backend PHP gratuit côté serveur.
 * ============================================================ */
const { BACKEND_URL: URL_FICHIER } = require('./_config');

// Priorité à la variable d'environnement Vercel, sinon le fichier _config.js
const BACKEND_URL = (process.env.BACKEND_URL || URL_FICHIER || 'https://A-CONFIGURER').replace(/\/+$/, '');

module.exports = async function handler(req, res) {
    const cible = BACKEND_URL + '/backend/api.php' + suffixeQuery(req);

    try {
        const init = { method: req.method || 'GET', headers: { 'Content-Type': 'application/json' } };
        if (req.method === 'POST') {
            init.body = typeof req.body === 'string' ? req.body : JSON.stringify(req.body || {});
        }
        const timeout = new AbortController();
        const timer = setTimeout(() => timeout.abort(), 25000);
        init.signal = timeout.signal;

        const reponse = await fetch(cible, init);
        clearTimeout(timer);

        const texte = await reponse.text();
        res.status(reponse.status).setHeader('Content-Type', 'application/json; charset=utf-8').send(texte);
    } catch (e) {
        res.status(200).setHeader('Content-Type', 'application/json; charset=utf-8');
        res.send(JSON.stringify({ ok: false, error: 'relais_backend', message: 'Le backend ne répond pas : ' + e.message }));
    }
};

function suffixeQuery(req) {
    const i = (req.url || '').indexOf('?');
    return i >= 0 ? req.url.slice(i) : '';
}
