/* ============================================================
 *  ⭐ OÙ EST MON BACKEND ? (2 façons — UNE SEULE suffit)
 *  ------------------------------------------------------------
 *  FAÇON 1 (recommandée, rien à renvoyer sur Vercel) :
 *    Vercel → votre projet → Settings → Environment Variables
 *    → Name: BACKEND_URL  ·  Value: https://votre-backend.atwebpages.com
 *    → Save, puis Deployments → Redeploy.
 *
 *  FAÇON 2 (ou pour un test local) : collez l'adresse ici.
 *
 *  Dans les 2 cas : l'adresse SANS slash « / » à la fin.
 * ============================================================ */
module.exports = {
    BACKEND_URL: ''
};
