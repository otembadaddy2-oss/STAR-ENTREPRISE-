/* ============================================================
 *  STAR — TÉLÉCHARGEMENT VERROUILLÉ DU LIVRE (version Vercel)
 *  « De l'Ombre à la Lumière » — Carry OTEMBA
 * ------------------------------------------------------------
 *  Le fichier PDF vit ICI, DANS la fonction serveur : il n'est
 *  JAMAIS exposé comme fichier statique public.
 *
 *  Condition UNIQUE de déblocage : un jeton signé HMAC-SHA256
 *  calculé avec la clé secrète OpenPay (variable d'environnement,
 *  jamais visible côté navigateur). Ce jeton est émis UNIQUEMENT
 *  par api/star-pay.js quand OpenPay confirme « paiement réussi ».
 *
 *  Sans jeton valide → HTTP 403 + page 🔒 qui renvoie à l'achat.
 * ============================================================ */
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const FICHIER_LIVRE = path.join(__dirname, '_livre-de-lombre-a-la-lumiere.pdf');
const NOM_TELECHARGEMENT = 'De-l-Ombre-a-la-Lumiere--Carry-OTEMBA.pdf';
const SEL = '|livre-carryo-otemba';
const PAGE_ACHAT = '/carryo-oeuvre-achat.html?id=15';

module.exports = async function handler(req, res) {
    const q = req.query || {};

    // -------- ping : test de vie --------
    if (q.ping) {
        res.setHeader('Content-Type', 'application/json; charset=utf-8');
        res.status(200).send(JSON.stringify({
            ok: true, service: 'telechargement-livre',
            livre: 'De l\'Ombre à la Lumière — Carry OTEMBA',
            fichier_present: fs.existsSync(FICHIER_LIVRE),
            cle_serveur: process.env.OPENPAY_API_KEY ? 'configurée ✔' : 'MANQUANTE ⚠️'
        }));
        return;
    }

    const ref = String(q.ref || '').trim();
    const tok = String(q.tok || '').trim();
    const cle = process.env.OPENPAY_API_KEY || '';

    if (!/^[A-Za-z0-9\-_]{4,60}$/.test(ref)) return refus(res, 'Référence de paiement absente ou invalide.');
    if (!cle) return refus(res, 'Configuration serveur incomplète (clé OpenPay absente).');

    // -------- VÉRIFICATION DU JETON SIGNÉ (la SEULE clé du verrou) --------
    let prouve = false;
    if (/^[a-f0-9]{64}$/.test(tok)) {
        const attendu = crypto.createHmac('sha256', cle).update(ref + SEL).digest('hex');
        try { prouve = crypto.timingSafeEqual(Buffer.from(attendu), Buffer.from(tok)); } catch (e) { prouve = false; }
    }
    if (!prouve) {
        return refus(res, 'Aucun paiement confirmé ne correspond à ce lien. Payez d\'abord le livre (12 550 FCFA par MTN Money), le bouton se débloque immédiatement après validation.');
    }

    // -------- Paiement PROUVÉ → on sert le livre --------
    if (!fs.existsSync(FICHIER_LIVRE)) return refus(res, 'Fichier momentanément indisponible — contactez le +242 06 656 50 50.');

    const taille = fs.statSync(FICHIER_LIVRE).size;
    res.status(200);
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="' + NOM_TELECHARGEMENT + '"');
    res.setHeader('Content-Length', String(taille));
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    fs.createReadStream(FICHIER_LIVRE).pipe(res);
};

/* -------- page de refus aimable -------- */
function refus(res, message) {
    const m = String(message).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    res.status(403);
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send('<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8">'
        + '<meta name="viewport" content="width=device-width,initial-scale=1">'
        + '<title>🔒 Téléchargement verrouillé — CARRY.O AFRIQUE</title>'
        + '<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0B1F3A;font-family:system-ui,Segoe UI,Arial,sans-serif;padding:20px;box-sizing:border-box}'
        + '.card{background:#fff;border-radius:22px;max-width:520px;width:100%;padding:38px 34px;text-align:center;box-shadow:0 30px 80px rgba(0,0,0,.45)}'
        + '.ico{font-size:56px}.t{color:#0B1F3A;font-size:21px;font-weight:800;margin:14px 0 8px}'
        + '.m{color:#64748B;font-size:14.5px;line-height:1.6;margin:0 0 22px}'
        + '.btn{display:inline-block;background:linear-gradient(135deg,#D4AF37,#C59B27);color:#0B1F3A;font-weight:800;text-decoration:none;padding:13px 26px;border-radius:26px;font-size:15px}'
        + '.note{margin-top:16px;font-size:12px;color:#94A3B8}</style></head><body><div class="card">'
        + '<div class="ico">🔒</div><div class="t">Téléchargement verrouillé</div>'
        + '<p class="m">Le livre numérique <b>« De l\'Ombre à la Lumière »</b> de <b>Carry OTEMBA</b> ne peut être téléchargé qu\'après un paiement confirmé.<br><br>' + m + '</p>'
        + '<a class="btn" href="' + PAGE_ACHAT + '">← Aller à la page d\'achat du livre</a>'
        + '<div class="note">Déjà payé ? Reprenez exactement votre référence de paiement. Besoin d\'aide : +242 06 656 50 50</div>'
        + '</div></body></html>');
}
