<?php
/**
 * STAR OS — Tableau de bord PDG : vue d'ensemble du groupe en temps réel.
 * Alimenté automatiquement par le site web (formulaires, achats, Sarah).
 */
require __DIR__ . '/auth.php';
require __DIR__ . '/ui.php';

staros_head('Tableau de bord PDG');
staros_topbar();
?>
<div class="wrap">
    <div class="pagehead">
        <h1>Tableau de bord PDG</h1>
        <p class="mono" style="font-size:10.5px;color:var(--gold-soft);letter-spacing:.1em;text-transform:uppercase">Vue d'ensemble du groupe — actualisé toutes les 3 secondes</p>
    </div>

    <div class="stats">
        <div class="stat" style="--c:var(--gold)"><div class="n" id="sTotal">–</div><div class="l">Événements</div></div>
        <div class="stat" style="--c:var(--orange)"><div class="n" id="sUnread">–</div><div class="l">Non lus</div></div>
        <div class="stat" style="--c:var(--red)"><div class="n" id="sCmd">–</div><div class="l">🛒 Commandes</div></div>
        <div class="stat" style="--c:var(--blue)"><div class="n" id="sSarah">–</div><div class="l">💬 Conversations</div></div>
        <div class="stat" style="--c:var(--purple)"><div class="n" id="sUnres">–</div><div class="l">⚠️ À traiter</div></div>
        <div class="stat" style="--c:var(--green)"><div class="n" id="sClients">–</div><div class="l">Clients</div></div>
        <div class="stat" style="--c:var(--green)"><div class="n" id="sToday">–</div><div class="l">Aujourd'hui</div></div>
    </div>

    <div class="panel">
        <h3>📈 Activité des 7 derniers jours <span class="tag">direct</span></h3>
        <div class="bars" id="bars"></div>
    </div>

    <div class="panel">
        <h3>🌐 Pages du site les plus actives <span class="tag">où les visiteurs agissent</span></h3>
        <div id="topPages"><div class="empty" style="padding:20px">Chargement…</div></div>
    </div>

    <div class="panel">
        <h3>🕐 Dernière activité sur le site <span class="tag">en direct</span></h3>
        <div id="derniers"></div>
    </div>
</div>

<script src="staros.js"></script>
<script>
async function maj() {
    const d = await starApi({ action: 'stats' });
    if (!d.ok) return;
    const s = d.stats;
    const map = { sTotal: s.total, sUnread: s.non_lus, sCmd: s.commandes, sSarah: s.conversations,
                  sUnres: s.unresolved, sClients: s.clients, sToday: s.aujourdhui };
    for (const [id, v] of Object.entries(map)) {
        const el = document.getElementById(id);
        if (el.textContent !== String(v)) el.textContent = v;
    }
    renderBars('bars', s.par_jour || []);
    renderTopPages(s.par_page || []);
    renderDerniers(s.derniers || []);
}

function renderTopPages(list) {
    const cont = document.getElementById('topPages');
    if (!list.length) { cont.innerHTML = '<div class="empty" style="padding:20px">Les pages actives apparaîtront ici dès les premières actions des visiteurs.</div>'; return; }
    const max = Math.max(...list.map(p => parseInt(p.c, 10)), 1);
    cont.innerHTML = list.map(p => {
        const nom = String(p.page || 'Page inconnue').replace('/', '') || 'Accueil';
        const pct = Math.round(parseInt(p.c, 10) / max * 100);
        return `<div style="margin-bottom:12px">
            <div style="display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:5px">
                <span>🔗 ${esc(nom)}</span>
                <span class="mono" style="color:var(--gold-soft);font-size:11px">${p.c} action(s)</span>
            </div>
            <div style="height:7px;background:rgba(255,255,255,.06);border-radius:4px">
                <div style="height:100%;width:${pct}%;background:linear-gradient(90deg,var(--gold),var(--gold-soft));border-radius:4px;transition:width .5s"></div>
            </div>
        </div>`;
    }).join('');
}

function renderDerniers(list) {
    const cont = document.getElementById('derniers');
    if (!list.length) { cont.innerHTML = '<div class="empty" style="padding:20px">Aucune activité pour le moment.</div>'; return; }
    cont.innerHTML = list.map(ev => `
        <div style="display:flex;gap:12px;padding:11px 4px;border-bottom:1px solid rgba(255,255,255,.05);align-items:flex-start">
            <span style="font-size:17px">${icon(ev.kind)}</span>
            <div style="flex:1;min-width:0">
                <div style="font-size:13px;font-weight:600">${esc(ev.title)}</div>
                <div style="font-size:11.5px;color:var(--ink-muted);margin-top:2px">
                    ${esc(ev.client || 'Visiteur')}${ev.telephone ? ' · 📞 ' + esc(ev.telephone) : ''} · 🕐 ${fmtDate(ev.created_at)}
                </div>
            </div>
            <span class="st ${ev.status}">${labelStatus(ev.status)}</span>
        </div>`).join('');
}

maj();
setInterval(maj, 3000);
</script>
<?php staros_foot(); ?>
