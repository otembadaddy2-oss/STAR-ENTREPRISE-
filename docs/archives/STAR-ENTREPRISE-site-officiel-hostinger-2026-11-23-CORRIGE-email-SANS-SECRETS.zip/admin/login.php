<?php
/**
 * STAR OS — Connexion (style identique à la référence)
 * Inclus par index.php — jamais appelé directement.
 */
require_once __DIR__ . '/../backend/identifiants.php';

if (session_status() === PHP_SESSION_NONE) session_start();

if (!empty($_SESSION['staros_logged_in'])) {
    header('Location: index.php');
    exit;
}

if (empty($_SESSION['csrf_login'])) $_SESSION['csrf_login'] = bin2hex(random_bytes(32));

$error = '';
$resetOk = !empty($_SESSION['star_reset_reussite']);
if ($resetOk) unset($_SESSION['star_reset_reussite']);

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    if (!hash_equals($_SESSION['csrf_login'], $_POST['csrf'] ?? '')) {
        $error = 'Session expirée, veuillez réessayer.';
    } else {
        $u = trim($_POST['username'] ?? '');
        $p = $_POST['password'] ?? '';
        sleep(1); // anti force-brute
        if (star_id_verifier($u, $p)) {
            star_id_raz();               // le compteur d'échecs repart à zéro
            session_regenerate_id(true);
            $_SESSION['staros_logged_in'] = true;
            $_SESSION['staros_user'] = $u;
            $_SESSION['staros_last_activity'] = time();
            header('Location: index.php');
            exit;
        }
        star_id_echec($u);               // échec enregistré (session + adresse IP)
        $error = star_id_reset_propose()
            ? 'Identifiant ou mot de passe incorrect. Vous pouvez réinitialiser vos identifiants ci-dessous.'
            : 'Identifiant ou mot de passe incorrect.';
    }
    $_SESSION['csrf_login'] = bin2hex(random_bytes(32));
}

$proposeReset = star_id_reset_propose();
$restants     = star_id_tentatives_restantes();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>STAR OS — Connexion</title>
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%230B1F3A'/%3E%3Ctext x='32' y='44' font-size='34' text-anchor='middle' fill='%23D4AF37'%3E★%3C/text%3E%3C/svg%3E">
<style>
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600&display=swap');
:root{--navy:#0B1F3A;--navy-deep:#071224;--gold:#D4AF37;--gold-soft:#F3DFA0;--gold-mid:#C59B27;
      --ink:#F3F6FC;--ink-muted:rgba(243,246,252,.62);--border:rgba(212,175,55,0.18);--red:#ff6b6b}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Inter',sans-serif;min-height:100vh;color:var(--ink);display:flex;align-items:center;justify-content:center;padding:24px;
     background:linear-gradient(160deg,var(--navy),var(--navy-deep))}
.card{background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:18px;
      padding:42px 38px;width:100%;max-width:420px;backdrop-filter:blur(6px)}
.logo{display:flex;flex-direction:column;align-items:center;gap:14px;margin-bottom:30px;text-align:center}
.logo .l{width:64px;height:64px;border-radius:16px;border:1px solid rgba(212,175,55,.4);display:flex;align-items:center;justify-content:center;
         font-size:34px;color:var(--gold);background:linear-gradient(135deg,rgba(212,175,55,.15),transparent)}
.logo h1{font-family:'Fraunces',serif;font-size:27px;font-weight:700}
.logo p{font-family:'JetBrains Mono',monospace;font-size:10.5px;color:var(--gold-soft);letter-spacing:.14em;text-transform:uppercase}
.field{margin-bottom:17px}
label{display:block;font-family:'JetBrains Mono',monospace;font-size:10px;color:var(--ink-muted);margin-bottom:7px;letter-spacing:.1em;text-transform:uppercase}
input{width:100%;padding:13px 15px;border-radius:10px;font-size:15px;border:1px solid var(--border);
      background:rgba(7,18,36,.6);color:var(--ink);outline:none;transition:.2s;font-family:'Inter',sans-serif}
input:focus{border-color:var(--gold);box-shadow:0 0 0 3px rgba(212,175,55,.15)}
.btn{width:100%;padding:14px;border:none;border-radius:10px;cursor:pointer;font-size:14px;font-weight:700;letter-spacing:.05em;
     color:#0B1F3A;background:linear-gradient(135deg,var(--gold),var(--gold-mid));transition:.15s;font-family:'Inter',sans-serif}
.btn:hover{transform:translateY(-1px);box-shadow:0 10px 26px rgba(212,175,55,.25)}
.alert{background:rgba(255,107,107,.09);border:1px solid rgba(255,107,107,.4);color:var(--red);
       border-radius:10px;padding:12px 14px;font-size:13.5px;margin-bottom:18px;text-align:center}
.alert.ok{background:rgba(61,220,151,.08);border-color:rgba(61,220,151,.4);color:#3ddc97}
.reset{margin-top:20px;padding:16px 15px;border-radius:11px;text-align:center;
       background:rgba(212,175,55,.07);border:1px solid rgba(212,175,55,.28)}
.reset p{font-size:12.5px;color:var(--ink-muted);line-height:1.65;margin-bottom:11px}
.reset a{display:inline-block;padding:11px 20px;border-radius:9px;font-size:13px;font-weight:600;
         color:var(--gold-soft);border:1px solid rgba(212,175,55,.45);text-decoration:none;transition:.15s}
.reset a:hover{background:rgba(212,175,55,.14);color:var(--gold);transform:translateY(-1px)}
/* Petit œil : afficher / masquer le mot de passe pendant la saisie */
.stareye{position:relative}
.stareye>input{padding-right:48px}
.stareye-btn{position:absolute;top:50%;right:8px;transform:translateY(-50%);width:34px;height:34px;
             display:flex;align-items:center;justify-content:center;padding:0;line-height:0;cursor:pointer;
             background:transparent;border:1px solid transparent;border-radius:9px;
             color:rgba(243,246,252,.45);transition:.15s}
.stareye-btn:hover{color:var(--gold);border-color:rgba(212,175,55,.3);background:rgba(212,175,55,.08)}
.stareye-btn:focus-visible{outline:2px solid var(--gold);outline-offset:2px}
.stareye-btn[aria-pressed="true"]{color:var(--gold)}
.stareye-off{display:none}
.stareye-btn[aria-pressed="true"] .stareye-open{display:none}
.stareye-btn[aria-pressed="true"] .stareye-off{display:block}
.foot{text-align:center;color:rgba(243,246,252,.35);font-size:11px;margin-top:26px}
</style>
</head>
<body>
<div class="card">
    <div class="logo">
        <div class="l">★</div>
        <h1>STAR OS</h1>
        <p>Outils internes · Connexion</p>
    </div>
    <?php if ($resetOk): ?><div class="alert ok">✅ Vos nouveaux identifiants sont créés. Connectez-vous.</div><?php endif; ?>
    <?php if ($error): ?><div class="alert">⚠️ <?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="post" autocomplete="off">
        <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_login']) ?>">
        <div class="field">
            <label for="username">Identifiant</label>
            <input type="text" id="username" name="username" required autofocus placeholder="Votre identifiant">
        </div>
        <div class="field">
            <label for="password">Mot de passe</label>
            <div class="stareye">
                <input type="password" id="password" name="password" required placeholder="Votre mot de passe">
                <button type="button" class="stareye-btn" data-for="password" aria-pressed="false"
                        aria-label="Afficher le mot de passe" title="Afficher le mot de passe">
                    <svg class="stareye-open" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1.8 12S5.6 5.6 12 5.6 22.2 12 22.2 12 18.4 18.4 12 18.4 1.8 12 1.8 12Z"/><circle cx="12" cy="12" r="3.1"/></svg>
                    <svg class="stareye-off" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9.9 5.9A10.6 10.6 0 0 1 12 5.6c6.4 0 10.2 6.4 10.2 6.4a18 18 0 0 1-3.4 4.2M6.3 7.9A18 18 0 0 0 1.8 12S5.6 18.4 12 18.4a10.4 10.4 0 0 0 3.7-.7"/><path d="M9.9 9.9a3.1 3.1 0 0 0 4.3 4.3"/><path d="M3.2 3.2l17.6 17.6"/></svg>
                </button>
            </div>
        </div>
        <button class="btn" type="submit">Se connecter</button>
    </form>

    <?php if ($proposeReset): ?>
    <div class="reset">
        <p>Plusieurs tentatives sans succès ?<br>
           Réinitialisez vos identifiants grâce à un code envoyé à<br>
           <strong style="color:var(--gold-soft)"><?= star_h(star_id_email_masque()) ?></strong></p>
        <a href="reinitialiser.php">🔑 Réinitialiser mes identifiants</a>
    </div>
    <?php endif; ?>

    <div class="foot">© <?= date('Y') ?> STAR ENTREPRISE · Accès réservé</div>
</div>
<script>
/* Œil afficher/masquer — script volontairement autonome (aucun fichier externe) */
(function () {
    function bascule(bouton) {
        var champ = document.getElementById(bouton.getAttribute('data-for'));
        if (!champ) return;
        var afficher = (champ.type === 'password');
        champ.type = afficher ? 'text' : 'password';
        bouton.setAttribute('aria-pressed', afficher ? 'true' : 'false');
        var texte = afficher ? 'Masquer le mot de passe' : 'Afficher le mot de passe';
        bouton.setAttribute('aria-label', texte);
        bouton.setAttribute('title', texte);
        champ.focus();
        var valeur = champ.value; champ.value = ''; champ.value = valeur; /* curseur remis en fin */
    }
    function init() {
        var boutons = document.querySelectorAll('.stareye-btn');
        for (var i = 0; i < boutons.length; i++) {
            boutons[i].addEventListener('click', function (e) { e.preventDefault(); bascule(this); });
        }
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
</script>
</body>
</html>
