<?php
/**
 * STAR OS — Design system partagé (style identique à la référence STAR OS)
 * Marine profond + or, titres Fraunces, texte Inter, étiquettes JetBrains Mono.
 */

function staros_head(string $title, bool $refresh = false): void
{
    ?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($title) ?> — STAR OS</title>
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%230B1F3A'/%3E%3Ctext x='32' y='44' font-size='34' text-anchor='middle' fill='%23D4AF37'%3E★%3C/text%3E%3C/svg%3E">
<style>
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600&display=swap');
:root{
  --navy:#0B1F3A; --navy-deep:#071224; --gold:#D4AF37; --gold-soft:#F3DFA0; --gold-mid:#C59B27;
  --ink:#F3F6FC; --ink-muted:rgba(243,246,252,.62); --border:rgba(212,175,55,0.18);
  --card:rgba(255,255,255,0.04); --card-hov:rgba(255,255,255,0.08);
  --green:#3ddc97; --red:#ff6b6b; --blue:#5ea3ff; --orange:#ff9f43; --purple:#b388ff;
}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Inter',sans-serif;min-height:100vh;color:var(--ink);
     background:linear-gradient(160deg,var(--navy),var(--navy-deep))}
h1,h2,h3,.serif{font-family:'Fraunces',serif}
.mono{font-family:'JetBrains Mono',monospace}
a{color:var(--gold-soft)}

/* ---------- Barre supérieure ---------- */
.topbar{position:sticky;top:0;z-index:50;display:flex;align-items:center;gap:14px;padding:16px 22px;
        background:rgba(7,18,36,.92);border-bottom:1px solid var(--border);backdrop-filter:blur(10px);flex-wrap:wrap}
.topbar .logo{width:38px;height:38px;border-radius:10px;border:1px solid rgba(212,175,55,.4);display:flex;
              align-items:center;justify-content:center;font-size:20px;color:var(--gold);
              background:linear-gradient(135deg,rgba(212,175,55,.15),transparent)}
.topbar .names b{font-family:'Fraunces',serif;font-size:17px;letter-spacing:.5px}
.topbar .names small{display:block;font-family:'JetBrains Mono',monospace;font-size:9.5px;color:var(--gold-soft);
                     letter-spacing:.14em;text-transform:uppercase;opacity:.85}
.topbar .spacer{flex:1}
.livechip{display:flex;align-items:center;gap:7px;font-family:'JetBrains Mono',monospace;font-size:10.5px;
          color:var(--green);background:rgba(61,220,151,.08);border:1px solid rgba(61,220,151,.3);
          padding:6px 12px;border-radius:20px;letter-spacing:.1em}
.livechip i{width:7px;height:7px;border-radius:50%;background:var(--green);animation:pulse 1.6s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.25}}
.userchip{font-size:13px;color:var(--ink-muted)}
.userchip strong{color:var(--gold-soft)}
.tbtn{padding:8px 15px;border-radius:9px;border:1px solid var(--border);background:var(--card);color:var(--ink);
      font-size:12.5px;cursor:pointer;text-decoration:none;transition:.15s;font-family:'Inter',sans-serif}
.tbtn:hover{background:var(--card-hov);border-color:var(--gold)}
.tbtn.gold{background:linear-gradient(135deg,var(--gold),var(--gold-mid));color:#0B1F3A;font-weight:700;border:none}

/* ---------- Contenu ---------- */
.wrap{max-width:1060px;margin:0 auto;padding:28px 20px 70px}
.pagehead{margin-bottom:24px}
.pagehead h1{font-size:24px;margin-bottom:6px}
.pagehead p{color:var(--ink-muted);font-size:13.5px}

/* ---------- Cartes du hub (identique référence) ---------- */
.hub{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:14px}
a.module{display:block;text-decoration:none;color:var(--ink);background:var(--card);
         border:1px solid var(--border);border-radius:16px;padding:22px;transition:background .15s,transform .15s;position:relative}
a.module:hover{background:var(--card-hov);transform:translateY(-2px)}
a.module .ic{font-size:26px;margin-bottom:12px}
a.module b{font-family:'Fraunces',serif;font-size:16.5px;display:block;margin-bottom:5px}
a.module span{font-size:12.5px;color:var(--ink-muted);line-height:1.5;display:block}
a.module .badge{position:absolute;top:14px;right:14px;background:var(--gold);color:#0B1F3A;font-family:'JetBrains Mono',monospace;
                font-size:10px;font-weight:600;padding:4px 9px;border-radius:12px;animation:pulse 2s infinite}

/* ---------- Statistiques ---------- */
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:22px}
.stat{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:16px;position:relative;overflow:hidden}
.stat::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:var(--c,var(--gold))}
.stat .n{font-family:'Fraunces',serif;font-size:28px;font-weight:700;font-variant-numeric:tabular-nums}
.stat .l{font-family:'JetBrains Mono',monospace;font-size:9.5px;color:var(--ink-muted);letter-spacing:.1em;text-transform:uppercase;margin-top:4px}

/* ---------- Panneaux ---------- */
.panel{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:20px;margin-bottom:18px}
.panel h3{font-size:15px;margin-bottom:14px;display:flex;align-items:center;gap:8px}
.panel h3 .tag{font-family:'JetBrains Mono',monospace;font-size:9px;color:var(--gold-soft);letter-spacing:.12em;
               text-transform:uppercase;background:rgba(212,175,55,.1);padding:3px 9px;border-radius:10px;border:1px solid var(--border)}

/* ---------- Graphique bâtons ---------- */
.bars{display:flex;align-items:flex-end;gap:10px;height:100px}
.bar{flex:1;display:flex;flex-direction:column;align-items:center;gap:5px;height:100%;justify-content:flex-end}
.bar .fill{width:100%;max-width:42px;background:linear-gradient(180deg,var(--gold-soft),var(--gold));border-radius:6px 6px 2px 2px;min-height:3px;transition:height .5s}
.bar .d{font-size:10px;color:var(--ink-muted)}
.bar .v{font-family:'JetBrains Mono',monospace;font-size:10px;color:var(--gold-soft)}

/* ---------- Tableaux ---------- */
table.data{width:100%;border-collapse:collapse;font-size:13px}
table.data th{text-align:left;padding:10px 12px;font-family:'JetBrains Mono',monospace;font-size:9.5px;letter-spacing:.1em;
              text-transform:uppercase;color:var(--ink-muted);border-bottom:1px solid var(--border)}
table.data td{padding:12px;border-bottom:1px solid rgba(255,255,255,.06)}
table.data tr:hover td{background:rgba(255,255,255,.03)}

/* ---------- Événements (flux) ---------- */
.ev{background:var(--card);border:1px solid var(--border);border-radius:13px;padding:15px 17px;margin-bottom:11px;
    display:grid;grid-template-columns:auto 1fr auto;gap:13px;align-items:start;animation:slideIn .3s}
@keyframes slideIn{from{opacity:0;transform:translateY(-8px)}to{opacity:1}}
.ev.unread{border-left:3px solid var(--gold);background:linear-gradient(90deg,rgba(212,175,55,.07),var(--card) 30%)}
.ev .icon{font-size:20px;width:42px;height:42px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.06);border-radius:10px;border:1px solid var(--border)}
.ev .title{font-weight:600;font-size:14px;margin-bottom:4px;word-wrap:break-word}
.ev .meta{font-size:11.5px;color:var(--ink-muted);margin-bottom:6px;display:flex;gap:11px;flex-wrap:wrap}
.ev .msg{font-size:12.5px;color:rgba(243,246,252,.82);white-space:pre-wrap;word-wrap:break-word;max-height:85px;overflow:hidden;position:relative;line-height:1.55}
.ev .msg.open{max-height:none}
.ev .msg:not(.open)::after{content:'';position:absolute;bottom:0;left:0;right:0;height:30px;background:linear-gradient(transparent,#0d1a30)}
.ev .actions{display:flex;flex-direction:column;gap:7px;align-items:flex-end}
.ev .row{display:flex;gap:7px}
.st{font-family:'JetBrains Mono',monospace;font-size:10px;font-weight:600;padding:5px 11px;border-radius:13px;letter-spacing:.06em;white-space:nowrap}
.st.nouveau{background:rgba(255,159,67,.13);color:var(--orange);border:1px solid rgba(255,159,67,.4)}
.st.en_cours{background:rgba(94,163,255,.13);color:var(--blue);border:1px solid rgba(94,163,255,.4)}
.st.traite{background:rgba(61,220,151,.13);color:var(--green);border:1px solid rgba(61,220,151,.4)}
.abtn{padding:6px 11px;font-size:11.5px;border-radius:8px;border:1px solid var(--border);background:rgba(255,255,255,.05);color:var(--ink);cursor:pointer;transition:.15s;white-space:nowrap}
.abtn:hover{border-color:var(--gold);color:var(--gold-soft)}
.abtn.red:hover{border-color:var(--red);color:var(--red)}

/* ---------- Filtres / outils ---------- */
.toolbar{display:flex;gap:9px;align-items:center;flex-wrap:wrap;margin-bottom:16px}
.chip{padding:8px 16px;border-radius:20px;border:1px solid var(--border);background:var(--card);color:var(--ink-muted);
      font-size:12.5px;cursor:pointer;transition:.15s;user-select:none;font-family:'Inter',sans-serif}
.chip:hover{border-color:var(--gold)}
.chip.active{background:linear-gradient(135deg,var(--gold),var(--gold-mid));color:#0B1F3A;border-color:transparent;font-weight:700}
.btn{padding:9px 16px;border-radius:10px;border:1px solid var(--border);background:var(--card);color:var(--ink);
     font-size:12.5px;cursor:pointer;transition:.15s;display:inline-flex;align-items:center;gap:7px;font-family:'Inter',sans-serif}
.btn:hover{border-color:var(--gold);color:var(--gold-soft)}
.btn.gold{background:linear-gradient(135deg,var(--gold),var(--gold-mid));color:#0B1F3A;border:none;font-weight:700}

.empty{text-align:center;padding:52px 20px;color:var(--ink-muted);font-size:13.5px}
.empty .big{font-size:40px;margin-bottom:12px}

/* ---------- Toast ---------- */
#toast{position:fixed;bottom:22px;right:22px;z-index:999;display:none;align-items:center;gap:12px;
       background:linear-gradient(135deg,#122a4f,#0B1F3A);border:1px solid var(--gold);border-radius:13px;
       padding:14px 17px;box-shadow:0 16px 44px rgba(0,0,0,.55);max-width:350px;color:var(--ink);animation:slideIn .25s}
#toast .ti{font-size:20px}
#toast .tt{font-weight:700;color:var(--gold-soft);font-size:11px;text-transform:uppercase;letter-spacing:.08em;font-family:'JetBrains Mono',monospace}
#toast .tm{font-size:13px;line-height:1.45;margin-top:2px}

.hidden{display:none!important}
@media(max-width:640px){
  .ev{grid-template-columns:1fr}
  .ev .actions{flex-direction:row;flex-wrap:wrap;align-items:center}
  .stats{grid-template-columns:repeat(2,1fr)}
}
</style>
</head>
<body>
    <?php
}

/** Barre supérieure commune */
function staros_topbar(string $pageCourante = ''): void
{
    $user = htmlspecialchars($_SESSION['staros_user'] ?? 'admin', ENT_QUOTES, 'UTF-8');
    ?>
<div class="topbar">
    <div class="logo">★</div>
    <div class="names"><b>STAR OS</b><small>Outils internes · STAR ENTREPRISE</small></div>
    <div class="spacer"></div>
    <span class="livechip"><i></i> TEMPS RÉEL</span>
    <?php if ($pageCourante !== 'hub'): ?><a class="tbtn" href="index.php">⌂ Accueil</a><?php endif; ?>
    <span class="userchip">👤 <strong><?= $user ?></strong></span>
    <a class="tbtn" href="logout.php">Déconnexion</a>
</div>
    <?php
}

/** Pied de page */
function staros_foot(): void
{
    echo '<div style="text-align:center;padding:26px;font-size:11px;color:rgba(243,246,252,.35)">© ' . date('Y') . ' STAR ENTREPRISE — STAR OS · Accès réservé</div>';
    echo '</body></html>';
}
