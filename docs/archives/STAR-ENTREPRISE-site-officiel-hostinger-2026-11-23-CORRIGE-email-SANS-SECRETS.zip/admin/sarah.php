<?php
/**
 * STAR OS — SARAH AI CORE
 * Toutes les conversations de l'assistante + les questions non résolues
 * à traiter en priorité. En direct depuis le site.
 */
require __DIR__ . '/auth.php';
require __DIR__ . '/ui.php';

staros_head('SARAH AI CORE');
staros_topbar();
?>
<div class="wrap">
    <div class="pagehead">
        <h1>SARAH AI CORE</h1>
        <p class="mono" style="font-size:10.5px;color:var(--gold-soft);letter-spacing:.1em;text-transform:uppercase">Conversations de l'assistante — en direct</p>
    </div>

    <div class="stats">
        <div class="stat" style="--c:var(--blue)"><div class="n" id="cConv">–</div><div class="l">💬 Conversations</div></div>
        <div class="stat" style="--c:var(--purple)"><div class="n" id="cUnres">–</div><div class="l">⚠️ Non résolues</div></div>
    </div>

    <div class="toolbar">
        <button class="chip active" data-view="unresolved">⚠️ À traiter en priorité</button>
        <button class="chip" data-view="conversation">💬 Toutes les conversations</button>
        <div style="flex:1"></div>
        <button class="btn" id="btnReadAll">✔ Tout marquer lu</button>
        <button class="btn" id="btnSound">🔔 Son : ON</button>
    </div>

    <div id="events"><div class="empty">Chargement…</div></div>
</div>

<script src="staros.js"></script>
<script>
const REFRESH = 3000;
let lastTs = 0, view = 'unresolved';
let allEvents = []; let knownIds = new Set();

function matches(ev) {
    return view === 'unresolved' ? ev.kind === 'unresolved' : ev.kind === 'conversation';
}

function eventHTML(ev) {
    return `
    <div class="ev ${ev.is_read === 0 ? 'unread' : ''}" data-id="${ev.id}">
        <div class="icon">${icon(ev.kind)}</div>
        <div class="body">
            <div class="title">${esc(ev.title)}</div>
            <div class="meta">
                <span>👤 ${esc(ev.client || 'Visiteur')}</span>
                <span>🕐 ${fmtDate(ev.created_at)}</span>
                ${ev.page ? `<span>🔗 ${esc(ev.page)}</span>` : ''}
            </div>
            ${ev.message ? `<div class="msg">${esc(ev.message)}</div>
            <button class="abtn" data-act="expand">Afficher tout ▾</button>` : ''}
        </div>
        <div class="actions">
            <span class="st ${ev.status}">${labelStatus(ev.status)}</span>
            <div class="row">
                ${ev.status === 'nouveau' ? `<button class="abtn" data-act="encours">→ En cours</button>` : ''}
                ${ev.status !== 'traite' ? `<button class="abtn" data-act="traite">→ Traité</button>` : ''}
                ${ev.is_read === 0 ? `<button class="abtn" data-act="lu">Marquer lu</button>` : ''}
            </div>
            <div class="row"><button class="abtn red" data-act="suppr">🗑 Supprimer</button></div>
        </div>
    </div>`;
}

function render() {
    const cont = document.getElementById('events');
    const list = allEvents.filter(matches);
    cont.innerHTML = list.length ? list.map(eventHTML).join('')
        : `<div class="empty"><div class="big">${view === 'unresolved' ? '🎉' : '💬'}</div>${view === 'unresolved' ? 'Aucune question en attente — Sarah gère tout parfaitement !' : 'Les conversations des visiteurs avec Sarah apparaîtront ici en direct.'}</div>`;
}

async function refresh(notify = true) {
    const d = await starApi({ action: 'events', since: lastTs, filter: 'sarah', limit: 100 });
    if (!d.ok) return;
    const fresh = (d.events || []).filter(e => !knownIds.has(e.id));
    if (fresh.length) {
        fresh.forEach(e => { knownIds.add(e.id); allEvents.unshift(e); });
        allEvents.sort((a, b) => b.id - a.id);
        allEvents = allEvents.slice(0, 300);
        render();
        const u = fresh.filter(e => e.kind === 'unresolved').length;
        const c = fresh.filter(e => e.kind === 'conversation').length;
        const elC = document.getElementById('cConv'), elU = document.getElementById('cUnres');
        elC.textContent = parseInt(elC.textContent || 0, 10) + c || c;
        elU.textContent = parseInt(elU.textContent || 0, 10) + u || u;
        if (notify && fresh.length) {
            starBeep();
            const imp = fresh.find(e => e.kind === 'unresolved') || fresh[0];
            starToast(imp.kind === 'unresolved' ? '⚠️ Question à traiter' : '💬 Nouvelle conversation', (imp.title || '').slice(0, 90), icon(imp.kind));
        }
    }
    if (d.now) lastTs = d.now - 1;
}

async function initial() {
    const d = await starApi({ action: 'events', filter: 'sarah', limit: 150 });
    if (d.ok) {
        allEvents = d.events || [];
        allEvents.forEach(e => knownIds.add(e.id));
        if (d.now) lastTs = d.now - 1;
        document.getElementById('cConv').textContent = allEvents.filter(e => e.kind === 'conversation').length;
        document.getElementById('cUnres').textContent = allEvents.filter(e => e.kind === 'unresolved').length;
        render();
    }
}

/* Actions identiques à la page Demandes : chaque bouton agit sur la base */
document.getElementById('events').addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-act]');
    if (!btn) return;
    const card = btn.closest('.ev');
    const id = parseInt(card.dataset.id, 10);
    const act = btn.dataset.act;
    if (act === 'expand') {
        const msg = card.querySelector('.msg');
        msg.classList.toggle('open');
        btn.textContent = msg.classList.contains('open') ? 'Réduire ▴' : 'Afficher tout ▾';
        return;
    }
    if (act === 'suppr') {
        if (!confirm('Supprimer définitivement ?')) return;
        await starApi({ action: 'delete', id });
        allEvents = allEvents.filter(x => x.id !== id); knownIds.delete(id);
        render(); return;
    }
    if (act === 'lu') {
        await starApi({ action: 'mark_read', id });
        const ev = allEvents.find(x => x.id === id); if (ev) ev.is_read = 1;
        render(); return;
    }
    if (act === 'encours' || act === 'traite') {
        const st = act === 'encours' ? 'en_cours' : 'traite';
        await starApi({ action: 'update_status', id, status: st });
        const ev = allEvents.find(x => x.id === id); if (ev) ev.status = st;
        render();
        starToast(st === 'traite' ? 'Traitée ✔' : 'En cours', 'Statut mis à jour.', '✅');
    }
});

document.getElementById('btnReadAll').onclick = async () => {
    await starApi({ action: 'mark_all_read' });
    allEvents.forEach(e => e.is_read = 1); render();
    starToast('Fait', 'Tout est marqué comme lu.', '✅');
};
document.getElementById('btnSound').onclick = (e) => {
    starSoundOn = !starSoundOn;
    e.target.textContent = starSoundOn ? '🔔 Son : ON' : '🔕 Son : OFF';
};

document.querySelectorAll('.chip[data-view]').forEach(chip => {
    chip.onclick = () => {
        document.querySelectorAll('.chip[data-view]').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        view = chip.dataset.view;
        render();
    };
});

setInterval(refresh, REFRESH);
initial();
</script>
<?php staros_foot(); ?>
