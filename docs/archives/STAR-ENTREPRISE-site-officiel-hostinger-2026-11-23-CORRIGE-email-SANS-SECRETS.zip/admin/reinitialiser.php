<?php
/**
 * STAR OS — Réinitialisation des identifiants administrateur
 * ---------------------------------------------------------
 * Accessible sans être connecté (c'est son rôle).
 * Déroulé : demande du code -> code reçu par e-mail -> nouveaux identifiants.
 *
 * La sécurité repose sur la possession de l'adresse e-mail de l'entreprise :
 * aucun identifiant ne peut être modifié sans le code envoyé à cette adresse.
 */
require_once __DIR__ . '/../backend/identifiants.php';

if (session_status() === PHP_SESSION_NONE) session_start();

// Déjà connecté ? Cette page ne sert à rien.
if (!empty($_SESSION['staros_logged_in'])) {
    header('Location: index.php');
    exit;
}

if (empty($_SESSION['csrf_reset'])) $_SESSION['csrf_reset'] = bin2hex(random_bytes(32));

// « Renvoyer un code » : on revient à l'étape 1 (le moteur gère les limites d'envoi)
if (isset($_GET['renvoyer'])) {
    unset($_SESSION['star_reset_jeton']);
    $_SESSION['star_reset_etape'] = 'demande';
    header('Location: reinitialiser.php');
    exit;
}

$etape   = isset($_SESSION['star_reset_etape']) ? $_SESSION['star_reset_etape'] : 'demande';
$jeton   = (string)($_SESSION['star_reset_jeton'] ?? '');
$info    = '';   // message d'erreur
$succes  = '';   // message de confirmation
$emailM  = star_id_email_masque();

// Jeton présent mais étape non initialisée (retour direct sur la page)
if ($jeton !== '' && $etape === 'demande') $etape = 'code';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {

    if (!hash_equals($_SESSION['csrf_reset'], (string)($_POST['csrf'] ?? ''))) {
        $info = 'Session expirée, veuillez réessayer.';
        $_SESSION['csrf_reset'] = bin2hex(random_bytes(32));
    } else {
        $action = (string)($_POST['action'] ?? '');

        // ---------- ÉTAPE 1 : envoi du code ----------
        if ($action === 'envoyer_code') {
            $res = star_id_envoyer_code();
            if ($res['ok']) {
                $_SESSION['star_reset_etape'] = 'code';
                $etape = 'code';
                $jeton = $res['jeton'];
                $succes = 'Code envoyé à ' . $emailM . ' (via ' . $res['voie'] . '). Vérifiez votre boîte de réception, pensez à regarder les indésirables.';
            } else {
                $info = $res['message'];
            }
        }

        // ---------- ÉTAPE 2 : création des nouveaux identifiants ----------
        elseif ($action === 'creer_identifiants') {
            if ($etape !== 'code' || $jeton === '') {
                $info = 'Aucun code en cours. Demandez d\'abord un code de vérification.';
                $etape = 'demande';
                $_SESSION['star_reset_etape'] = 'demande';
            } else {
                $code   = trim((string)($_POST['code'] ?? ''));
                $user   = trim((string)($_POST['username'] ?? ''));
                $pass   = (string)($_POST['password'] ?? '');
                $pass2  = (string)($_POST['password_confirm'] ?? '');

                $restant = star_id_code_essais_restants($jeton);
                if ($restant <= 0) {
                    $info = 'Code expiré ou trop d\'essais. Demandez un nouveau code.';
                    $etape = 'demande';
                    $_SESSION['star_reset_etape'] = 'demande';
                    unset($_SESSION['star_reset_jeton']);
                } elseif (!star_id_verifier_code($code, $jeton)) {
                    $encore = star_id_code_essais_restants($jeton);
                    $info = $encore > 0
                        ? 'Code incorrect. Il vous reste ' . $encore . ' essai' . ($encore > 1 ? 's' : '') . '.'
                        : 'Code incorrect et épuisé. Demandez un nouveau code.';
                    if ($encore <= 0) {
                        $etape = 'demande';
                        $_SESSION['star_reset_etape'] = 'demande';
                        unset($_SESSION['star_reset_jeton']);
                    }
                } elseif ($pass !== $pass2) {
                    $info = 'Les deux mots de passe ne sont pas identiques.';
                } else {
                    $r = star_id_enregistrer($user, $pass);
                    if ($r === true) {
                        star_id_consommer_code($jeton);
                        star_id_raz();
                        unset($_SESSION['star_reset_jeton'], $_SESSION['star_reset_etape'],
                              $_SESSION['star_reset_dernier_envoi'], $_SESSION['star_reset_historique'],
                              $_SESSION['staros_logged_in'], $_SESSION['staros_user']);
                        $_SESSION['star_reset_reussite'] = true;
                        session_regenerate_id(true);
                        header('Location: index.php');
                        exit;
                    }
                    $info = $r;   // message d'erreur de validation
                }
            }
        }
    }
    $_SESSION['csrf_reset'] = bin2hex(random_bytes(32));
}

$essaisRestants = $etape === 'code' ? star_id_code_essais_restants($jeton) : 0;
$baseActive     = star_id_base_active();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow">
<title>STAR OS — Réinitialiser mes identifiants</title>
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%230B1F3A'/%3E%3Ctext x='32' y='44' font-size='34' text-anchor='middle' fill='%23D4AF37'%3E★%3C/text%3E%3C/svg%3E">
<style>
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600&display=swap');
:root{--navy:#0B1F3A;--navy-deep:#071224;--gold:#D4AF37;--gold-soft:#F3DFA0;--gold-mid:#C59B27;
      --ink:#F3F6FC;--ink-muted:rgba(243,246,252,.62);--border:rgba(212,175,55,0.18);--red:#ff6b6b;
      --green:#3ddc97}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Inter',sans-serif;min-height:100vh;color:var(--ink);display:flex;align-items:center;justify-content:center;padding:24px;
     background:linear-gradient(160deg,var(--navy),var(--navy-deep))}
.card{background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:18px;
      padding:42px 38px;width:100%;max-width:460px;backdrop-filter:blur(6px)}
.logo{display:flex;flex-direction:column;align-items:center;gap:14px;margin-bottom:28px;text-align:center}
.logo .l{width:64px;height:64px;border-radius:16px;border:1px solid rgba(212,175,55,.4);display:flex;align-items:center;justify-content:center;
         font-size:34px;color:var(--gold);background:linear-gradient(135deg,rgba(212,175,55,.15),transparent)}
.logo h1{font-family:'Fraunces',serif;font-size:25px;font-weight:700}
.logo p{font-family:'JetBrains Mono',monospace;font-size:10.5px;color:var(--gold-soft);letter-spacing:.14em;text-transform:uppercase}
.field{margin-bottom:17px}
label{display:block;font-family:'JetBrains Mono',monospace;font-size:10px;color:var(--ink-muted);margin-bottom:7px;letter-spacing:.1em;text-transform:uppercase}
input{width:100%;padding:13px 15px;border-radius:10px;font-size:15px;border:1px solid var(--border);
      background:rgba(7,18,36,.6);color:var(--ink);outline:none;transition:.2s;font-family:'Inter',sans-serif}
input:focus{border-color:var(--gold);box-shadow:0 0 0 3px rgba(212,175,55,.15)}
input.code{font-family:'JetBrains Mono',monospace;font-size:26px;letter-spacing:.5em;text-align:center;font-weight:600}
.btn{width:100%;padding:14px;border:none;border-radius:10px;cursor:pointer;font-size:14px;font-weight:700;letter-spacing:.05em;
     color:#0B1F3A;background:linear-gradient(135deg,var(--gold),var(--gold-mid));transition:.15s;font-family:'Inter',sans-serif}
.btn:hover{transform:translateY(-1px);box-shadow:0 10px 26px rgba(212,175,55,.25)}
.btn.ghost{background:transparent;color:var(--ink-muted);border:1px solid var(--border);font-weight:600;margin-top:10px}
.btn.ghost:hover{color:var(--ink);border-color:var(--gold)}
.alert{background:rgba(255,107,107,.09);border:1px solid rgba(255,107,107,.4);color:var(--red);
       border-radius:10px;padding:12px 14px;font-size:13.5px;margin-bottom:18px;text-align:center;line-height:1.6}
.alert.ok{background:rgba(61,220,151,.08);border-color:rgba(61,220,151,.4);color:var(--green)}
.notice{background:rgba(7,18,36,.5);border:1px solid var(--border);border-radius:10px;padding:13px 15px;
        font-size:12.8px;line-height:1.75;color:var(--ink-muted);margin-bottom:20px}
.notice b{color:var(--gold-soft);font-weight:600}
.mail{font-family:'JetBrains Mono',monospace;color:var(--gold-soft);font-size:12.5px;word-break:break-all}
.foot{text-align:center;color:rgba(243,246,252,.35);font-size:11px;margin-top:26px}
.foot a{color:var(--ink-muted);text-decoration:none;border-bottom:1px solid rgba(212,175,55,.3)}
.foot a:hover{color:var(--gold)}
.steps{display:flex;gap:8px;justify-content:center;margin-bottom:24px}
.steps span{font-family:'JetBrains Mono',monospace;font-size:9.5px;letter-spacing:.08em;padding:5px 10px;border-radius:20px;
            border:1px solid var(--border);color:rgba(243,246,252,.3);text-transform:uppercase}
.steps span.on{color:#0B1F3A;background:linear-gradient(135deg,var(--gold),var(--gold-mid));border-color:transparent;font-weight:600}
.rule{font-size:11.5px;color:rgba(243,246,252,.4);margin-top:6px;line-height:1.6}
/* Petit œil : afficher / masquer le mot de passe pendant la saisie */
.stareye{position:relative}
.stareye>input{padding-right:48px}
.stareye-btn{position:absolute;top:50%;right:8px;transform:translateY(-50%);width:34px;height:34px;
             display:flex;align-items:center;justify-content:center;padding:0;line-height:0;cursor:pointer;
             background:transparent;border:1px solid transparent;border-radius:9px;
             color:rgba(243,246,252,.45);transition:.15s}
.stareye-btn:hover{color:var(--gold);border-color:rgba(212,175,55,.3);background:rgba(212,175,55,.08)}
.stareye-btn:focus-visible{outline:2px solid var(--gold);outline-offset:2px}
.stareye-btn[aria-pressed="true"]{color:var(--gold)}
.stareye-off{display:none}
.stareye-btn[aria-pressed="true"] .stareye-open{display:none}
.stareye-btn[aria-pressed="true"] .stareye-off{display:block}
</style>
</head>
<body>
<div class="card">
    <div class="logo">
        <div class="l">★</div>
        <h1>Réinitialisation</h1>
        <p>STAR OS · Identifiants administrateur</p>
    </div>

    <div class="steps">
        <span class="<?= $etape === 'demande' ? 'on' : '' ?>">1 · Code</span>
        <span class="<?= $etape === 'code' ? 'on' : '' ?>">2 · Nouveaux identifiants</span>
    </div>

    <?php if ($info): ?><div class="alert">⚠️ <?= star_h($info) ?></div><?php endif; ?>
    <?php if ($succes): ?><div class="alert ok">✅ <?= star_h($succes) ?></div><?php endif; ?>

    <?php if ($etape === 'demande'): ?>

        <div class="notice">
            Un code de vérification à 6 chiffres sera envoyé à l'adresse de l'entreprise :<br>
            <span class="mail"><?= star_h($emailM) ?></span><br><br>
            Ce code est valable <b>15 minutes</b> et permet <b>3 essais</b> de saisie.
            Sans accès à cette boîte e-mail, aucune modification n'est possible.
        </div>

        <form method="post" autocomplete="off">
            <input type="hidden" name="csrf" value="<?= star_h($_SESSION['csrf_reset']) ?>">
            <input type="hidden" name="action" value="envoyer_code">
            <button class="btn" type="submit">📨 Recevoir le code par e-mail</button>
        </form>

        <?php if (!$baseActive): ?>
        <p class="rule" style="text-align:center;margin-top:18px">
            Vos identifiants actuels sont ceux définis dans <code style="color:var(--gold-soft)">config.php</code>.<br>
            Après cette réinitialisation, ils seront remplacés et enregistrés dans votre base de données.
        </p>
        <?php else: ?>
        <p class="rule" style="text-align:center;margin-top:18px">
            Vos identifiants sont déjà enregistrés dans votre base de données.<br>
            Cette procédure les remplacera définitivement.
        </p>
        <?php endif; ?>

    <?php else: ?>

        <form method="post" autocomplete="off">
            <input type="hidden" name="csrf" value="<?= star_h($_SESSION['csrf_reset']) ?>">
            <input type="hidden" name="action" value="creer_identifiants">

            <div class="field">
                <label for="code">Code reçu par e-mail</label>
                <input class="code" type="text" id="code" name="code" required inputmode="numeric"
                       pattern="\d{6}" maxlength="6" autocomplete="one-time-code"
                       placeholder="000000" autofocus>
                <p class="rule"><?= $essaisRestants > 0
                        ? star_h($essaisRestants) . ' essai' . ($essaisRestants > 1 ? 's' : '') . ' restant' . ($essaisRestants > 1 ? 's' : '') . ' pour ce code.'
                        : 'Ce code n\'est plus valable — demandez-en un nouveau.' ?></p>
            </div>

            <div class="field">
                <label for="username">Nouvel identifiant</label>
                <input type="text" id="username" name="username" required minlength="3" maxlength="60"
                       value="<?= star_h(star_id_utilisateur()) ?>" placeholder="ex. direction">
                <p class="rule">3 à 60 caractères : lettres, chiffres, point, tiret, espace.</p>
            </div>

            <div class="field">
                <label for="password">Nouveau mot de passe</label>
                <div class="stareye">
                    <input type="password" id="password" name="password" required minlength="<?= STAR_ID_MDP_MIN ?>" maxlength="200"
                           placeholder="Au moins <?= STAR_ID_MDP_MIN ?> caractères">
                    <button type="button" class="stareye-btn" data-for="password" aria-pressed="false"
                            aria-label="Afficher le mot de passe" title="Afficher le mot de passe">
                        <svg class="stareye-open" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1.8 12S5.6 5.6 12 5.6 22.2 12 22.2 12 18.4 18.4 12 18.4 1.8 12 1.8 12Z"/><circle cx="12" cy="12" r="3.1"/></svg>
                        <svg class="stareye-off" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9.9 5.9A10.6 10.6 0 0 1 12 5.6c6.4 0 10.2 6.4 10.2 6.4a18 18 0 0 1-3.4 4.2M6.3 7.9A18 18 0 0 0 1.8 12S5.6 18.4 12 18.4a10.4 10.4 0 0 0 3.7-.7"/><path d="M9.9 9.9a3.1 3.1 0 0 0 4.3 4.3"/><path d="M3.2 3.2l17.6 17.6"/></svg>
                    </button>
                </div>
                <p class="rule">Minimum <?= STAR_ID_MDP_MIN ?> caractères. Évitez un mot de passe déjà utilisé.</p>
            </div>

            <div class="field">
                <label for="password_confirm">Confirmer le mot de passe</label>
                <div class="stareye">
                    <input type="password" id="password_confirm" name="password_confirm" required minlength="<?= STAR_ID_MDP_MIN ?>" maxlength="200"
                           placeholder="Retapez le mot de passe">
                    <button type="button" class="stareye-btn" data-for="password_confirm" aria-pressed="false"
                            aria-label="Afficher la confirmation" title="Afficher la confirmation">
                        <svg class="stareye-open" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1.8 12S5.6 5.6 12 5.6 22.2 12 22.2 12 18.4 18.4 12 18.4 1.8 12 1.8 12Z"/><circle cx="12" cy="12" r="3.1"/></svg>
                        <svg class="stareye-off" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9.9 5.9A10.6 10.6 0 0 1 12 5.6c6.4 0 10.2 6.4 10.2 6.4a18 18 0 0 1-3.4 4.2M6.3 7.9A18 18 0 0 0 1.8 12S5.6 18.4 12 18.4a10.4 10.4 0 0 0 3.7-.7"/><path d="M9.9 9.9a3.1 3.1 0 0 0 4.3 4.3"/><path d="M3.2 3.2l17.6 17.6"/></svg>
                    </button>
                </div>
            </div>

            <button class="btn" type="submit">🔐 Créer mes nouveaux identifiants</button>
        </form>

        <form method="get" style="margin-top:10px">
            <input type="hidden" name="renvoyer" value="1">
            <button class="btn ghost" type="submit">📨 Renvoyer un code</button>
        </form>

    <?php endif; ?>

    <div class="foot">
        <a href="index.php">← Retour à la connexion</a><br><br>
        © <?= date('Y') ?> STAR ENTREPRISE · Accès réservé
    </div>
</div>
<script>
/* Œil afficher/masquer — script volontairement autonome (aucun fichier externe) */
(function () {
    function bascule(bouton) {
        var champ = document.getElementById(bouton.getAttribute('data-for'));
        if (!champ) return;
        var afficher = (champ.type === 'password');
        champ.type = afficher ? 'text' : 'password';
        bouton.setAttribute('aria-pressed', afficher ? 'true' : 'false');
        var texte = afficher ? 'Masquer le mot de passe' : 'Afficher le mot de passe';
        bouton.setAttribute('aria-label', texte);
        bouton.setAttribute('title', texte);
        champ.focus();
        var valeur = champ.value; champ.value = ''; champ.value = valeur; /* curseur remis en fin */
    }
    function init() {
        var boutons = document.querySelectorAll('.stareye-btn');
        for (var i = 0; i < boutons.length; i++) {
            boutons[i].addEventListener('click', function (e) { e.preventDefault(); bascule(this); });
        }
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
</script>
</body>
</html>
