<?php
/**
 * STAR OS — Changer le mot de passe administrateur
 */
require __DIR__ . '/auth.php';
require __DIR__ . '/ui.php';
require_once __DIR__ . '/../backend/identifiants.php';

$hash = ''; $info = ''; $directOk = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new = (string)($_POST['new_password'] ?? '');
    if (mb_strlen($new) < 6) {
        $info = 'Le mot de passe doit contenir au moins 6 caractères.';
    } elseif (star_id_base_active()) {
        // Vos identifiants sont gérés par la base de données : mise à jour directe,
        // sans avoir à recoller un hachage dans config.php.
        $r = star_id_enregistrer(star_id_utilisateur(), $new);
        if ($r === true) { $directOk = true; } else { $info = $r; }
    } else {
        $hash = password_hash($new, PASSWORD_DEFAULT);
    }
}

staros_head('Mot de passe');
staros_topbar();
?>
<style>
/* Petit œil : afficher / masquer le mot de passe pendant la saisie.
   Règles volontairement préfixées .stareye — elles ne peuvent pas entrer en
   conflit avec le style commun du back-office (admin/ui.php), non modifié. */
.stareye{position:relative}
.stareye-btn{position:absolute;top:50%;right:8px;transform:translateY(-50%);width:34px;height:34px;
             display:flex;align-items:center;justify-content:center;padding:0;line-height:0;cursor:pointer;
             background:transparent;border:1px solid transparent;border-radius:9px;
             color:rgba(243,246,252,.45);transition:.15s}
.stareye-btn:hover{color:var(--gold);border-color:rgba(212,175,55,.3);background:rgba(212,175,55,.08)}
.stareye-btn:focus-visible{outline:2px solid var(--gold);outline-offset:2px}
.stareye-btn[aria-pressed="true"]{color:var(--gold)}
.stareye-off{display:none}
.stareye-btn[aria-pressed="true"] .stareye-open{display:none}
.stareye-btn[aria-pressed="true"] .stareye-off{display:block}
</style>
<div class="wrap" style="max-width:640px">
    <div class="pagehead" style="text-align:center">
        <h1>🔑 Mot de passe</h1>
        <p>Sécurité du compte administrateur</p>
    </div>

    <div class="panel">
        <?php if ($info): ?>
            <div style="background:rgba(255,107,107,.09);border:1px solid rgba(255,107,107,.4);color:var(--red);border-radius:10px;padding:12px 14px;font-size:13.5px;margin-bottom:18px;text-align:center">⚠️ <?= star_h($info) ?></div>
        <?php endif; ?>

        <?php if ($directOk): ?>
            <div style="background:rgba(61,220,151,.08);border:1px solid rgba(61,220,151,.4);color:var(--green);border-radius:10px;padding:12px 14px;font-size:13.5px;margin-bottom:18px">✅ Mot de passe mis à jour dans votre base de données — actif immédiatement.</div>
            <p style="font-size:13.5px;line-height:2;color:var(--ink-muted)">
                Aucune manipulation dans <code>config.php</code> n'est nécessaire.<br>
                Votre identifiant reste : <code style="color:var(--gold-soft)"><?= star_h(star_id_utilisateur()) ?></code><br>
                Votre session en cours reste ouverte.
            </p>
            <p style="margin-top:16px;text-align:center"><a href="mot-de-passe.php">← Changer à nouveau</a></p>
        <?php elseif ($hash === ''): ?>
        <form method="post">
            <label class="mono" for="new_password" style="display:block;font-size:10px;color:var(--ink-muted);letter-spacing:.1em;text-transform:uppercase;margin-bottom:8px">Nouveau mot de passe (6 caractères minimum)</label>
            <div class="stareye" style="margin-bottom:16px">
                <input type="password" id="new_password" name="new_password" required placeholder="Nouveau mot de passe" autocomplete="new-password"
                       style="width:100%;padding:13px 48px 13px 15px;border-radius:10px;font-size:15px;border:1px solid var(--border);background:rgba(7,18,36,.6);color:var(--ink);outline:none">
                <button type="button" class="stareye-btn" data-for="new_password" aria-pressed="false"
                        aria-label="Afficher le mot de passe" title="Afficher le mot de passe">
                    <svg class="stareye-open" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1.8 12S5.6 5.6 12 5.6 22.2 12 22.2 12 18.4 18.4 12 18.4 1.8 12 1.8 12Z"/><circle cx="12" cy="12" r="3.1"/></svg>
                    <svg class="stareye-off" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9.9 5.9A10.6 10.6 0 0 1 12 5.6c6.4 0 10.2 6.4 10.2 6.4a18 18 0 0 1-3.4 4.2M6.3 7.9A18 18 0 0 0 1.8 12S5.6 18.4 12 18.4a10.4 10.4 0 0 0 3.7-.7"/><path d="M9.9 9.9a3.1 3.1 0 0 0 4.3 4.3"/><path d="M3.2 3.2l17.6 17.6"/></svg>
                </button>
            </div>
            <button type="submit" class="btn gold" style="width:100%">Générer</button>
        </form>
        <?php else: ?>
            <div style="background:rgba(61,220,151,.08);border:1px solid rgba(61,220,151,.4);color:var(--green);border-radius:10px;padding:12px 14px;font-size:13.5px;margin-bottom:18px">✅ Hachage généré ! Suivez les 3 étapes :</div>
            <p style="font-size:13.5px;line-height:2;color:var(--ink-muted)">
                1️⃣ Copiez ce code :<br>
                <code style="display:block;background:rgba(7,18,36,.7);border:1px solid var(--border);padding:12px;border-radius:9px;font-size:12px;word-break:break-all;margin:10px 0;color:var(--gold-soft)"><?= star_h($hash) ?></code>
                2️⃣ Ouvrez <code>config.php</code> (Gestionnaire de fichiers Hostinger)<br>
                3️⃣ Remplacez l'ancien hachage (ligne <code>ADMIN_PASSWORD_HASH</code>) par celui-ci, puis enregistrez.
            </p>
            <p style="margin-top:16px;text-align:center"><a href="mot-de-passe.php">← Recommencer</a></p>
        <?php endif; ?>
    </div>
</div>
<script>
/* Œil afficher/masquer — script volontairement autonome (aucun fichier externe) */
(function () {
    function bascule(bouton) {
        var champ = document.getElementById(bouton.getAttribute('data-for'));
        if (!champ) return;
        var afficher = (champ.type === 'password');
        champ.type = afficher ? 'text' : 'password';
        bouton.setAttribute('aria-pressed', afficher ? 'true' : 'false');
        var texte = afficher ? 'Masquer le mot de passe' : 'Afficher le mot de passe';
        bouton.setAttribute('aria-label', texte);
        bouton.setAttribute('title', texte);
        champ.focus();
        var valeur = champ.value; champ.value = ''; champ.value = valeur; /* curseur remis en fin */
    }
    function init() {
        var boutons = document.querySelectorAll('.stareye-btn');
        for (var i = 0; i < boutons.length; i++) {
            boutons[i].addEventListener('click', function (e) { e.preventDefault(); bascule(this); });
        }
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
</script>
<?php staros_foot(); ?>
