<?php
/**
 * STAR OS — Garde d'accès (à inclure en haut de chaque page d'administration)
 * Exigence : connexion obligatoire.
 */
require_once __DIR__ . '/../backend/db.php';

if (session_status() === PHP_SESSION_NONE) session_start();

if (isset($_SESSION['staros_last_activity']) && (time() - $_SESSION['staros_last_activity'] > SESSION_DURATION)) {
    session_unset(); session_destroy(); session_start();
}
$_SESSION['staros_last_activity'] = time();

if (empty($_SESSION['staros_logged_in'])) {
    header('Location: index.php');
    exit;
}

/** Chemin relatif vers l'API du backend */
define('STAR_API', '../backend/api.php');
