/* ============================================================
 * STAR OS — Utilitaires partagés du tableau de bord
 * (API, toast, son, rendus — utilisés par toutes les pages admin)
 * ============================================================ */

/** Appel API backend (retourne du JSON, redirige si session expirée) */
async function starApi(payload) {
    const r = await fetch('../backend/api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify(payload)
    });
    if (r.status === 401) { location.href = 'index.php'; return { ok: false }; }
    return r.json();
}

/** Échappement HTML (anti-XSS) */
function esc(s) {
    return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/** Date lisible */
function fmtDate(d) {
    const dt = new Date(String(d).replace(' ', 'T'));
    return dt.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' }) + ' ' +
           dt.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
}

/** Icône selon le type d'événement */
function icon(kind) {
    return { commande: '🛒', conversation: '💬', unresolved: '⚠️', request: '📩', alert: '🔔' }[kind] || '📌';
}

/** Libellé de statut */
function labelStatus(s) {
    return { nouveau: 'NOUVEAU', en_cours: 'EN COURS', traite: 'TRAITÉ ✔' }[s] || s;
}

/** Son de notification (2 notes douces) */
let starSoundOn = true;
function starBeep() {
    if (!starSoundOn) return;
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        [880, 1174.66].forEach((f, i) => {
            const o = ctx.createOscillator(), g = ctx.createGain();
            o.connect(g); g.connect(ctx.destination);
            o.type = 'sine'; o.frequency.value = f;
            g.gain.setValueAtTime(0.0001, ctx.currentTime + i * 0.15);
            g.gain.exponentialRampToValueAtTime(0.22, ctx.currentTime + i * 0.15 + 0.02);
            g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + i * 0.15 + 0.32);
            o.start(ctx.currentTime + i * 0.15); o.stop(ctx.currentTime + i * 0.15 + 0.4);
        });
    } catch (e) {}
}

/** Toast de notification */
let _toastTimer = null;
function starToast(title, msg, iconStr = '🔔') {
    let t = document.getElementById('toast');
    if (!t) {
        t = document.createElement('div');
        t.id = 'toast';
        t.innerHTML = '<span class="ti"></span><div><div class="tt"></div><div class="tm"></div></div>';
        document.body.appendChild(t);
    }
    t.querySelector('.ti').textContent = iconStr;
    t.querySelector('.tt').textContent = title;
    t.querySelector('.tm').textContent = msg;
    t.style.display = 'flex';
    clearTimeout(_toastTimer);
    _toastTimer = setTimeout(() => { t.style.display = 'none'; }, 6000);
}

/** Graphique en bâtons des 7 derniers jours */
function renderBars(contId, days) {
    const cont = document.getElementById(contId);
    if (!cont) return;
    const byDate = {};
    days.forEach(d => { byDate[d.j] = parseInt(d.c, 10); });
    const out = [];
    for (let i = 6; i >= 0; i--) {
        const d = new Date(); d.setDate(d.getDate() - i);
        const key = d.toISOString().slice(0, 10);
        const label = d.toLocaleDateString('fr-FR', { weekday: 'short' }).replace('.', '');
        out.push({ label, v: byDate[key] || 0 });
    }
    const max = Math.max(1, ...out.map(o => o.v));
    cont.innerHTML = out.map(o =>
        `<div class="bar" title="${o.v} événement(s)">
            <span class="v">${o.v || ''}</span>
            <div class="fill" style="height:${Math.round(o.v / max * 78) + 3}px"></div>
            <span class="d">${o.label}</span>
         </div>`).join('');
}
