<?php
/**
 * STAR OS — SARAH SUR WHATSAPP
 * Console unifiée : les échanges business de Sarah avec les clients,
 * ET les messages personnels de Carry, dans une seule interface.
 * Carry voit tout ; il peut répondre lui-même à tout moment (Sarah
 * se met alors en pause sur ce contact).
 */
require __DIR__ . '/auth.php';
require __DIR__ . '/ui.php';

staros_head('SARAH — WHATSAPP');
staros_topbar();
define('STAR_WA_API', '../backend/whatsapp.php?admin=1');
?>
<div class="wrap">
    <div class="pagehead">
        <h1>Sarah sur WhatsApp</h1>
        <p class="mono" style="font-size:10.5px;color:var(--gold-soft);letter-spacing:.1em;text-transform:uppercase">+242 06 656 50 50 — messages business (Sarah) et personnels (vous), au même endroit</p>
    </div>

    <div style="display:grid;grid-template-columns:300px 1fr;gap:16px;align-items:start">
        <div class="panel" style="padding:10px;max-height:74vh;overflow-y:auto">
            <div id="threads"><div class="empty">Chargement…</div></div>
        </div>

        <div class="panel" style="min-height:74vh;display:flex;flex-direction:column">
            <div id="threadHead" style="display:flex;align-items:center;gap:10px;margin-bottom:12px;padding-bottom:12px;border-bottom:1px solid var(--border)">
                <span class="empty" style="padding:0">Sélectionnez une conversation à gauche.</span>
            </div>
            <div id="messages" style="flex:1;overflow-y:auto;display:flex;flex-direction:column;gap:10px;padding:4px"></div>
            <div id="replyBox" style="display:none;margin-top:14px;gap:8px" >
                <textarea id="replyText" placeholder="Répondre vous-même (visible par le client, Sarah se met en pause sur ce contact)…" style="flex:1;min-height:60px;border-radius:10px;border:1px solid var(--border);background:rgba(255,255,255,.04);color:var(--ink);padding:10px;font-family:'Inter',sans-serif;resize:vertical"></textarea>
                <div style="display:flex;flex-direction:column;gap:8px">
                    <button class="btn gold" id="btnSend">Envoyer</button>
                    <button class="btn" id="btnToggleSarah">🤖 Sarah : —</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="staros.js"></script>
<script>
let threads = [], currentWa = null;

function bubble(m) {
    const mine = m.auteur !== 'client';
    const label = m.auteur === 'sarah' ? '🤖 Sarah (auto)' : m.auteur === 'carry' ? '👤 Vous' : (m.contact_name || 'Client');
    const tone = m.auteur === 'sarah' ? 'background:rgba(94,163,255,.12);border-color:rgba(94,163,255,.35)'
               : m.auteur === 'carry' ? 'background:rgba(212,175,55,.14);border-color:rgba(212,175,55,.4)'
               : 'background:var(--card);border-color:var(--border)';
    return `<div style="align-self:${mine ? 'flex-end' : 'flex-start'};max-width:74%">
        <div class="mono" style="font-size:9.5px;color:var(--ink-muted);margin-bottom:3px;${mine ? 'text-align:right' : ''}">${esc(label)} · ${fmtDate(m.created_at)}</div>
        <div style="border:1px solid var(--border);border-radius:12px;padding:10px 13px;font-size:13px;line-height:1.5;white-space:pre-wrap;${tone}">${esc(m.body)}</div>
    </div>`;
}

function threadHTML(t) {
    const active = t.wa_id === currentWa ? 'style="border-color:var(--gold);background:var(--card-hov)"' : '';
    return `<div class="ev" data-wa="${esc(t.wa_id)}" ${active} style="cursor:pointer;grid-template-columns:1fr;padding:12px 14px;margin-bottom:8px">
        <div>
            <div class="title" style="font-size:13.5px">${esc(t.contact_name || t.wa_id)} ${t.non_lus > 0 ? `<span class="st nouveau">${t.non_lus}</span>` : ''}</div>
            <div class="meta" style="margin-top:2px">${t.sarah_actif == 1 ? '🤖 Sarah active' : '⏸ Sarah en pause'}</div>
            <div class="msg" style="max-height:34px;-webkit-line-clamp:2">${esc((t.last_body || '').slice(0, 90))}</div>
        </div>
    </div>`;
}

async function loadThreads() {
    const d = await starApi2({ action: 'threads' });
    if (!d.ok) return;
    threads = d.threads || [];
    document.getElementById('threads').innerHTML = threads.length
        ? threads.map(threadHTML).join('')
        : '<div class="empty">Aucune conversation WhatsApp pour l\'instant.</div>';
}

async function openThread(waId) {
    currentWa = waId;
    const t = threads.find(x => x.wa_id === waId);
    document.getElementById('threadHead').innerHTML = `
        <div style="font-family:'Fraunces',serif;font-size:16px">${esc(t ? (t.contact_name || t.wa_id) : waId)}</div>
        <div class="mono" style="font-size:10px;color:var(--ink-muted)">${esc(waId)}</div>`;
    const d = await starApi2({ action: 'thread', wa_id: waId });
    if (!d.ok) return;
    document.getElementById('messages').innerHTML = (d.messages || []).map(bubble).join('')
        || '<div class="empty">Pas encore de message.</div>';
    document.getElementById('messages').scrollTop = 999999;
    document.getElementById('replyBox').style.display = 'flex';
    document.getElementById('btnToggleSarah').textContent = t && t.sarah_actif == 1 ? '⏸ Mettre Sarah en pause ici' : '🤖 Réactiver Sarah ici';
    await loadThreads();
}

document.getElementById('threads').addEventListener('click', (e) => {
    const card = e.target.closest('[data-wa]');
    if (card) openThread(card.dataset.wa);
});

document.getElementById('btnSend').onclick = async () => {
    const body = document.getElementById('replyText').value.trim();
    if (!body || !currentWa) return;
    const d = await starApi2({ action: 'send_as_carry', wa_id: currentWa, body });
    if (d.ok) {
        document.getElementById('replyText').value = '';
        openThread(currentWa);
    } else {
        starToast('Envoi impossible', d.message || 'Vérifiez la configuration WhatsApp dans config.php.', '⚠️');
    }
};

document.getElementById('btnToggleSarah').onclick = async () => {
    const t = threads.find(x => x.wa_id === currentWa);
    const actif = !(t && t.sarah_actif == 1) ? 1 : 0;
    await starApi2({ action: 'toggle_sarah', wa_id: currentWa, actif });
    openThread(currentWa);
};

async function starApi2(body) {
    const r = await fetch('<?= STAR_WA_API ?>', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin', body: JSON.stringify(body)
    });
    return r.json().catch(() => ({ ok: false }));
}

loadThreads();
setInterval(() => { loadThreads(); if (currentWa) openThread(currentWa); }, 8000);
</script>
<?php staros_foot(); ?>
