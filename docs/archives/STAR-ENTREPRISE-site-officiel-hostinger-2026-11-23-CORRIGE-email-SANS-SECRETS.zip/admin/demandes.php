<?php
/**
 * STAR OS — Demandes & Commandes : le flux EN DIRECT du site web.
 * Chaque bouton agit réellement sur la base (testé).
 */
require __DIR__ . '/auth.php';
require __DIR__ . '/ui.php';

staros_head('Demandes & Commandes');
staros_topbar();
?>
<div class="wrap">
    <div class="pagehead">
        <h1>Demandes &amp; Commandes</h1>
        <p class="mono" style="font-size:10.5px;color:var(--gold-soft);letter-spacing:.1em;text-transform:uppercase">Flux en direct depuis le site web</p>
    </div>

    <div class="toolbar">
        <button class="chip active" data-filter="all">Toutes</button>
        <button class="chip" data-filter="unread">Non lues</button>
        <button class="chip" data-filter="commandes">🛒 Commandes</button>
        <button class="chip" data-filter="sarah">💬 Sarah AI</button>
        <div class="spacer" style="flex:1"></div>
        <button class="btn" id="btnTest">⚡ Tester la connexion</button>
        <button class="btn" id="btnExport">⬇️ Exporter CSV</button>
        <button class="btn" id="btnReadAll">✔ Tout marquer lu</button>
        <button class="btn" id="btnSound">🔔 Son : ON</button>
    </div>

    <div style="font-size:12px;color:var(--ink-muted);margin-bottom:12px" id="evCount"></div>
    <div id="events"><div class="empty">Chargement du flux…</div></div>
</div>

<script src="staros.js"></script>
<script>
const REFRESH = 3000;
let lastTs = 0, currentFilter = 'all';
let allEvents = []; let knownIds = new Set();

function matchesFilter(ev) {
    if (currentFilter === 'unread') return ev.is_read === 0;
    if (currentFilter === 'commandes') return ev.kind === 'commande';
    if (currentFilter === 'sarah') return ev.kind === 'conversation' || ev.kind === 'unresolved';
    return true;
}

function eventHTML(ev) {
    const long = ev.message && ev.message.length > 220;
    return `
    <div class="ev ${ev.is_read === 0 ? 'unread' : ''}" data-id="${ev.id}">
        <div class="icon">${icon(ev.kind)}</div>
        <div class="body">
            <div class="title">${esc(ev.title)}</div>
            <div class="meta">
                <span>👤 ${esc(ev.client || 'Visiteur')}</span>
                ${ev.telephone ? `<span>📞 ${esc(ev.telephone)}</span>` : ''}
                ${ev.email ? `<span>✉️ ${esc(ev.email)}</span>` : ''}
                ${ev.ville ? `<span>📍 ${esc(ev.ville)}</span>` : ''}
                <span>🕐 ${fmtDate(ev.created_at)}</span>
                ${ev.page ? `<span>🔗 ${esc(ev.page)}</span>` : ''}
            </div>
            ${ev.message ? `<div class="msg">${esc(ev.message)}</div>
            ${long ? `<button class="abtn" data-act="expand">Afficher tout ▾</button>` : ''}` : ''}
        </div>
        <div class="actions">
            <span class="st ${ev.status}">${labelStatus(ev.status)}</span>
            <div class="row">
                ${ev.status === 'nouveau' ? `<button class="abtn" data-act="encours">→ En cours</button>` : ''}
                ${ev.status !== 'traite' ? `<button class="abtn" data-act="traite">→ Traité</button>` : ''}
                ${ev.is_read === 0 ? `<button class="abtn" data-act="lu">Marquer lu</button>` : ''}
            </div>
            <div class="row"><button class="abtn red" data-act="suppr">🗑 Supprimer</button></div>
        </div>
    </div>`;
}

function renderEvents() {
    const cont = document.getElementById('events');
    const list = allEvents.filter(matchesFilter);
    document.getElementById('evCount').textContent = `${list.length} événement(s) — actualisation toutes les 3 s`;
    cont.innerHTML = list.length ? list.map(eventHTML).join('')
        : '<div class="empty"><div class="big">📭</div>Aucun événement dans ce filtre.<br>Les actions des visiteurs apparaîtront ici en direct.</div>';
}

async function refreshEvents(notify = true) {
    const d = await starApi({ action: 'events', since: lastTs, limit: 100 });
    if (!d.ok) return;
    const fresh = (d.events || []).filter(e => !knownIds.has(e.id));
    if (fresh.length) {
        fresh.forEach(e => { knownIds.add(e.id); allEvents.unshift(e); });
        allEvents.sort((a, b) => b.id - a.id);
        allEvents = allEvents.slice(0, 300);
        renderEvents();
        if (notify) {
            const imp = fresh.find(e => e.kind === 'commande') || fresh.find(e => e.kind === 'unresolved') || fresh[0];
            starBeep();
            starToast(imp.kind === 'commande' ? 'Nouvelle commande !' : 'Nouvel événement', (imp.title || '').slice(0, 90), icon(imp.kind));
        }
    }
    if (d.now) lastTs = d.now - 1;
}

async function initialLoad() {
    const d = await starApi({ action: 'events', limit: 100 });
    if (d.ok) {
        allEvents = d.events || [];
        allEvents.forEach(e => knownIds.add(e.id));
        if (d.now) lastTs = d.now - 1;
        renderEvents();
    }
}

/* ---- Actions (chaque bouton agit sur la base) ---- */
document.getElementById('events').addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-act]');
    if (!btn) return;
    const card = btn.closest('.ev');
    const id = parseInt(card.dataset.id, 10);
    const act = btn.dataset.act;

    if (act === 'expand') {
        const msg = card.querySelector('.msg');
        msg.classList.toggle('open');
        btn.textContent = msg.classList.contains('open') ? 'Réduire ▴' : 'Afficher tout ▾';
        return;
    }
    if (act === 'suppr') {
        if (!confirm('Supprimer définitivement cet événement ?')) return;
        await starApi({ action: 'delete', id });
        allEvents = allEvents.filter(x => x.id !== id); knownIds.delete(id);
        renderEvents();
        starToast('Supprimé', 'Événement retiré du flux.', '🗑');
        return;
    }
    if (act === 'lu') {
        await starApi({ action: 'mark_read', id });
        const ev = allEvents.find(x => x.id === id); if (ev) ev.is_read = 1;
        renderEvents(); return;
    }
    if (act === 'encours' || act === 'traite') {
        const st = act === 'encours' ? 'en_cours' : 'traite';
        await starApi({ action: 'update_status', id, status: st });
        const ev = allEvents.find(x => x.id === id); if (ev) ev.status = st;
        renderEvents();
        starToast(st === 'traite' ? 'Traité ✔' : 'En cours', 'Statut mis à jour dans la base.', st === 'traite' ? '✅' : '🔵');
    }
});

/* ---- Barre d'outils ---- */
document.getElementById('btnReadAll').onclick = async () => {
    await starApi({ action: 'mark_all_read' });
    allEvents.forEach(e => e.is_read = 1); renderEvents();
    starToast('Fait', 'Tous les événements sont marqués comme lus.', '✅');
};
document.getElementById('btnExport').onclick = () => { window.location.href = '../backend/api.php?action=export_csv'; };
document.getElementById('btnSound').onclick = (e) => {
    starSoundOn = !starSoundOn;
    e.target.textContent = starSoundOn ? '🔔 Son : ON' : '🔕 Son : OFF';
};
document.getElementById('btnTest').onclick = async (e) => {
    e.target.disabled = true;
    const d = await starApi({ action: 'test_event' });
    if (d.ok) { starToast('Test réussi', 'La chaîne site ↔ backend fonctionne parfaitement !', '🎉'); starBeep(); refreshEvents(false); }
    else starToast('Test échoué', 'Vérifiez la configuration du backend.', '⚠️');
    e.target.disabled = false;
};

/* ---- Filtres ---- */
document.querySelectorAll('.chip[data-filter]').forEach(chip => {
    chip.onclick = () => {
        document.querySelectorAll('.chip[data-filter]').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        currentFilter = chip.dataset.filter;
        renderEvents();
    };
});

setInterval(refreshEvents, REFRESH);
document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshEvents(false); });
initialLoad();
</script>
<?php staros_foot(); ?>
