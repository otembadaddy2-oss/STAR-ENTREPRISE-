<?php
/**
 * STAR OS — Clients (CRM automatique)
 * Chaque demande depuis le site crée ou enrichit une fiche client.
 */
require __DIR__ . '/auth.php';
require __DIR__ . '/ui.php';

staros_head('Clients');
staros_topbar();
?>
<div class="wrap">
    <div class="pagehead">
        <h1>Clients</h1>
        <p class="mono" style="font-size:10.5px;color:var(--gold-soft);letter-spacing:.1em;text-transform:uppercase">Fiches créées automatiquement à chaque contact depuis le site</p>
    </div>

    <div class="toolbar">
        <input type="text" id="search" placeholder="🔍 Rechercher un client…" style="flex:1;min-width:200px;padding:10px 15px;border-radius:10px;border:1px solid var(--border);background:rgba(7,18,36,.6);color:var(--ink);font-size:13.5px;outline:none">
        <span class="btn" id="countClients" style="cursor:default"></span>
    </div>

    <div class="panel" style="padding:8px 18px">
        <table class="data">
            <thead><tr><th>Nom</th><th>Contact</th><th>Ville</th><th>Demandes</th><th>Dernière activité</th></tr></thead>
            <tbody id="clientsBody"><tr><td colspan="5" style="text-align:center;padding:30px;color:var(--ink-muted)">Chargement…</td></tr></tbody>
        </table>
    </div>
</div>

<script src="staros.js"></script>
<script>
let cache = [];

function render(list) {
    const tbody = document.getElementById('clientsBody');
    document.getElementById('countClients').textContent = `👥 ${list.length} client(s)`;
    if (!list.length) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:36px;color:var(--ink-muted)">Aucun client pour le moment — ils apparaîtront automatiquement dès la première demande sur le site.</td></tr>';
        return;
    }
    tbody.innerHTML = list.map(c => `
        <tr>
            <td><strong>${esc(c.nom)}</strong></td>
            <td>${c.telephone ? '📞 ' + esc(c.telephone) + '<br>' : ''}${c.email ? '✉️ ' + esc(c.email) : ''}</td>
            <td>${esc(c.ville || '—')}</td>
            <td><span class="mono" style="color:var(--gold-soft)">${c.requests_count}</span></td>
            <td style="color:var(--ink-muted);font-size:12px">${fmtDate(c.last_seen)}</td>
        </tr>`).join('');
}

async function load() {
    const d = await starApi({ action: 'clients' });
    if (d.ok) { cache = d.clients || []; render(cache); }
}

document.getElementById('search').addEventListener('input', (e) => {
    const q = e.target.value.toLowerCase().trim();
    render(!q ? cache : cache.filter(c =>
        (c.nom || '').toLowerCase().includes(q) ||
        (c.telephone || '').includes(q) ||
        (c.email || '').toLowerCase().includes(q) ||
        (c.ville || '').toLowerCase().includes(q)
    ));
});

load();
setInterval(load, 10000); // mise à jour régulière
</script>
<?php staros_foot(); ?>
