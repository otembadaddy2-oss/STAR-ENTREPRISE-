<?php
/**
 * STAR OS — Aiguillage : connecté → hub des modules, sinon → connexion.
 */
require_once __DIR__ . '/../backend/db.php';

session_start();

if (isset($_SESSION['staros_last_activity']) && (time() - $_SESSION['staros_last_activity'] > SESSION_DURATION)) {
    session_unset(); session_destroy();
}

if (!empty($_SESSION['staros_logged_in'])) {
    $_SESSION['staros_last_activity'] = time();
    require __DIR__ . '/hub.php';
    exit;
}

require __DIR__ . '/login.php';
