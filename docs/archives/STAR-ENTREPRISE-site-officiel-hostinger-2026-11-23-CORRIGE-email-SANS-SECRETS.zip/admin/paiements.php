<?php
/**
 * STAR OS — 💰 Paiements MTN Money (OpenPay)
 * Toutes les transactions reçues depuis le site, EN DIRECT.
 */
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/ui.php';

staros_head('Paiements MTN Money');
staros_topbar('paiements');
?>
<div class="wrap">
    <h1>💰 Paiements MTN Money</h1>
    <div class="sub">Transactions OpenPay depuis le site — actualisation toutes les 5 s</div>

    <div class="stats" style="grid-template-columns:repeat(auto-fit,minmax(170px,1fr))">
        <div class="stat" style="--c:var(--green)"><div class="n" id="nRecus">0</div><div class="l">✔ Paiements reçus</div></div>
        <div class="stat" style="--c:var(--gold)"><div class="n" id="nFcfa">0</div><div class="l">FCFA encaissés (total)</div></div>
        <div class="stat" style="--c:#F2C31B"><div class="n" id="nJour">0</div><div class="l">FCFA aujourd'hui</div></div>
        <div class="stat" style="--c:var(--orange)"><div class="n" id="nAttente">0</div><div class="l">⏳ En attente de validation</div></div>
        <div class="stat" style="--c:var(--red)"><div class="n" id="nEchec">0</div><div class="l">Échecs</div></div>
    </div>

    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px">
        <button class="chip active" data-f="all">Tous</button>
        <button class="chip" data-f="succes">✔ Reçus</button>
        <button class="chip" data-f="attente">⏳ En attente</button>
        <button class="chip" data-f="echec">✖ Échecs</button>
        <span style="flex:1"></span>
        <button class="abtn" id="btnTest">⚡ Tester la connexion</button>
    </div>

    <div class="panel" style="padding:0;overflow:auto">
        <table class="data" style="min-width:760px">
            <thead><tr>
                <th>Référence</th><th>Article</th><th>Montant</th><th>Client</th><th>Téléphone</th><th>Statut</th><th>Mode</th><th>Date</th><th>Livre</th>
            </tr></thead>
            <tbody id="lst">
                <tr><td colspan="9" style="text-align:center;padding:36px;color:var(--ink-muted)">Chargement…</td></tr>
            </tbody>
        </table>
    </div>
    <div style="text-align:center;color:rgba(243,246,252,.4);font-size:11.5px" id="compteur"></div>
</div>

<script src="staros.js"></script>
<script>
let filtre = 'all';
let dernierId = 0;

const PILLE = {
    succes:  '<span class="st traite">✔ REÇU</span>',
    attente: '<span class="st nouveau">⏳ EN ATTENTE</span>',
    echec:   '<span class="st" style="background:rgba(255,107,107,.13);color:var(--red);border:1px solid rgba(255,107,107,.4)">✖ ÉCHEC</span>'
};

/** Construit la cellule « Livre » : bouton d'envoi WhatsApp, badge « envoyé »,
 *  ou tiret si ce paiement ne concerne pas le livre numérique. */
function libreCellule(p) {
    const art = (p.article || '').toLowerCase();
    const estLivre = art.includes('ombre') && art.includes('lumi');
    if (!estLivre) return '<span style="color:var(--ink-muted)">—</span>';
    if (p.statut !== 'succes') return '<span style="color:var(--ink-muted);font-size:12px">en attente</span>';

    const maxEnvois = (+p.montant === 25100) ? 2 : 1;
    const envoyes = +p.telecharge_compte || 0;
    if (envoyes >= maxEnvois) {
        return `<span style="color:var(--green);font-size:12px">✔ Envoyé (${envoyes}/${maxEnvois})</span>`;
    }
    return `<button class="abtn" data-envoyer-livre="${esc(p.reference)}" style="font-size:12px;padding:6px 12px">📖 Envoyer sur WhatsApp</button>`;
}

async function charger() {
    const d = await starApi({ action: 'payments' });
    if (!d.ok) return;
    const lst = d.payments || [];
    // stats globales
    let recus = 0, fcfa = 0, att = 0, ech = 0, jour = 0;
    const auj = new Date().toISOString().slice(0, 10);
    lst.forEach(p => {
        if (p.statut === 'succes') { recus++; fcfa += +p.montant; if ((p.created_at || '').slice(0, 10) === auj) jour += +p.montant; }
        if (p.statut === 'attente') att++;
        if (p.statut === 'echec') ech++;
    });
    document.getElementById('nRecus').textContent = recus;
    document.getElementById('nFcfa').textContent = fcfa.toLocaleString('fr-FR');
    document.getElementById('nJour').textContent = jour.toLocaleString('fr-FR');
    document.getElementById('nAttente').textContent = att;
    document.getElementById('nEchec').textContent = ech;

    const visibles = filtre === 'all' ? lst : lst.filter(p => p.statut === filtre);
    const tbody = document.getElementById('lst');
    if (!visibles.length) {
        tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;padding:36px;color:var(--ink-muted)">🎉 Aucun paiement ici pour l\'instant — dès qu\'un client paie une œuvre, ça apparaît EN DIRECT.</td></tr>';
    } else {
        tbody.innerHTML = visibles.map(p => `<tr${p.details ? ` title="${esc(p.details)}"` : ''}>
            <td style="font-family:'JetBrains Mono',monospace;font-size:11px">${esc(p.reference)}</td>
            <td style="max-width:240px">${esc(p.article)}${(p.details && p.statut !== 'succes') ? `<div style="font-size:11px;margin-top:3px;${p.statut === 'echec' ? 'color:var(--red)' : 'color:var(--ink-muted)'}">↳ ${esc(String(p.details).slice(0, 90))}${String(p.details).length > 90 ? '…' : ''}</div>` : ''}</td>
            <td style="font-weight:700;color:var(--gold-soft);white-space:nowrap">${(+p.montant).toLocaleString('fr-FR')} F</td>
            <td>${esc(p.client)}</td>
            <td style="white-space:nowrap">${esc(p.telephone)}</td>
            <td>${PILLE[p.statut] || esc(p.statut)}</td>
            <td>${p.mode === 'demo' ? '<span style="color:var(--ink-muted)">démo</span>' : '<span style="color:var(--green)">réel</span>'}</td>
            <td style="white-space:nowrap;font-size:12px;color:var(--ink-muted)">${fmtDate(p.created_at)}</td>
            <td style="white-space:nowrap">${libreCellule(p)}</td>
        </tr>`).join('');

        // Boutons « 📖 Envoyer sur WhatsApp » — un par ligne concernée
        tbody.querySelectorAll('[data-envoyer-livre]').forEach(btn => {
            btn.addEventListener('click', async () => {
                const ref = btn.dataset.envoyerLivre;
                btn.disabled = true; btn.textContent = '⏳ Envoi…';
                try {
                    const r = await starApi({ action: 'livre_envoyer_whatsapp', reference: ref });
                    if (r.ok) {
                        starToast('📲 Livre envoyé sur WhatsApp (' + r.telephone + ')');
                        starBeep();
                    } else {
                        starToast('❌ ' + (r.message || 'Échec de l\'envoi'));
                    }
                } catch (e) {
                    starToast('❌ Envoi impossible (connexion)');
                } finally {
                    charger();
                }
            });
        });
    }
    document.getElementById('compteur').textContent = visibles.length + ' paiement(s) affiché(s)';

    // Toast + son quand un NOUVEAU paiement arrive
    const maxId = lst.reduce((m, p) => Math.max(m, +p.id), 0);
    if (dernierId && maxId > dernierId) {
        const p = lst.find(x => +x.id === maxId);
        if (p && p.statut === 'succes') {
            starToast('💰 PAIEMENT REÇU — ' + (+p.montant).toLocaleString('fr-FR') + ' FCFA — ' + esc(p.client));
            starBeep();
        } else {
            starToast('⏳ Nouvelle transaction ' + (p ? (PILLE[p.statut] ? p.statut : '') : ''));
        }
    }
    dernierId = maxId;
}

document.querySelectorAll('.chip').forEach(c => c.addEventListener('click', () => {
    document.querySelectorAll('.chip').forEach(x => x.classList.remove('active'));
    c.classList.add('active');
    filtre = c.dataset.f;
    charger();
}));

document.getElementById('btnTest').addEventListener('click', async () => {
    try {
        const r = await fetch('../backend/paiement.php?ping=1', { credentials: 'same-origin' });
        const j = await r.json();
        starToast(j.ok ? `✔ Module de paiement OK · ${j.mode} · clé ${j.cle_live}` : '⚠️ Réponse inattendue du module');
    } catch (e) { starToast('❌ Module de paiement injoignable'); }
});

charger();
setInterval(charger, 5000);
</script>
<?php staros_foot(); ?>
