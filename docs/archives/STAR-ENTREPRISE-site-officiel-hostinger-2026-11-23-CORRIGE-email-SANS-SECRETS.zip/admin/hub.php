<?php
/**
 * STAR OS — Hub des modules (style identique à l'accueil de référence)
 * Chaque carte ouvre une page branchée sur les données réelles du site.
 */
require __DIR__ . '/auth.php';
require __DIR__ . '/ui.php';

staros_head('Accueil');
staros_topbar('hub');
?>
<div class="wrap">
    <div class="pagehead" style="text-align:center;padding-top:12px">
        <h1 style="font-size:30px">Outils STAR ENTREPRISE</h1>
        <p class="mono" style="color:var(--gold-soft);font-size:11px;letter-spacing:.12em;text-transform:uppercase">
            Connecté au site web · Données en direct
        </p>
    </div>

    <div class="hub">
        <a class="module" href="pdg.php">
            <div class="ic">📊</div>
            <b>Tableau de bord PDG</b>
            <span>Vue d'ensemble du groupe : activité du site, statistiques, sources.</span>
        </a>
        <a class="module" href="demandes.php">
            <span class="badge" id="badgeDemandes" style="display:none"></span>
            <div class="ic">🛒</div>
            <b>Demandes &amp; Commandes</b>
            <span>Flux en direct : formulaires, achats CARRY.O, demandes de devis.</span>
        </a>
        <a class="module" href="clients.php">
            <span class="badge" id="badgeClients" style="display:none"></span>
            <div class="ic">👥</div>
            <b>Clients</b>
            <span>Fiches créées automatiquement à chaque contact depuis le site.</span>
        </a>
        <a class="module" href="sarah.php">
            <span class="badge" id="badgeSarah" style="display:none"></span>
            <div class="ic">🤖</div>
            <b>SARAH AI CORE</b>
            <span>Conversations de l'assistante et questions à traiter en priorité.</span>
        </a>
        <a class="module" href="whatsapp.php">
            <span class="badge" id="badgeWhatsapp" style="display:none"></span>
            <div class="ic">💚</div>
            <b>Sarah sur WhatsApp</b>
            <span>+242 06 656 50 50 — messages clients (Sarah) et personnels, réunis dans une seule interface.</span>
        </a>
        <a class="module" href="paiements.php">
            <span class="badge" id="badgePay" style="display:none"></span>
            <div class="ic">💰</div>
            <b>Paiements MTN Money</b>
            <span>Transactions OpenPay reçues depuis le site (œuvres CARRY-O).</span>
        </a>
        <a class="module" href="../" target="_blank">
            <div class="ic">🌐</div>
            <b>Voir le site web</b>
            <span>Ouvrir le site public STAR ENTREPRISE dans un nouvel onglet.</span>
        </a>
        <a class="module" href="mot-de-passe.php">
            <div class="ic">🔑</div>
            <b>Mot de passe</b>
            <span>Sécurité : changer l'accès administrateur.</span>
        </a>
    </div>
</div>

<script>
/* Badges en direct sur les cartes (preuve de la relation avec le site) */
async function majBadges() {
    try {
        const r = await fetch('<?= STAR_API ?>', {
            method: 'POST', headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin', body: JSON.stringify({action: 'stats'})
        });
        const d = await r.json();
        if (!d.ok) return;
        const s = d.stats;
        const set = (id, txt, show) => { const e = document.getElementById(id); if (txt) { e.textContent = txt; e.style.display = 'block'; } };
        set('badgeDemandes', s.non_lus > 0 ? s.non_lus + ' non lus' : '', true);
        set('badgeClients', s.clients + ' clients', true);
        set('badgeSarah', s.unresolved > 0 ? s.unresolved + ' à traiter' : '', true);
        set('badgePay', s.pay_recus > 0 ? s.pay_recus + ' reçu' + (s.pay_recus > 1 ? 's' : '') + (s.pay_attente > 0 ? ' · ⏳' + s.pay_attente : '') : (s.pay_attente > 0 ? '⏳ ' + s.pay_attente + ' en cours' : ''), true);
    } catch (e) {}
}
async function majBadgeWhatsapp() {
    try {
        const r = await fetch('../backend/whatsapp.php?admin=1', {
            method: 'POST', headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin', body: JSON.stringify({action: 'threads'})
        });
        const d = await r.json();
        if (!d.ok) return;
        const n = (d.threads || []).reduce((sum, t) => sum + (parseInt(t.non_lus, 10) || 0), 0);
        const e = document.getElementById('badgeWhatsapp');
        if (n > 0) { e.textContent = n + ' à traiter'; e.style.display = 'block'; }
    } catch (e) {}
}
majBadges();
majBadgeWhatsapp();
setInterval(majBadges, 10000);
setInterval(majBadgeWhatsapp, 10000);
</script>
<?php staros_foot(); ?>
