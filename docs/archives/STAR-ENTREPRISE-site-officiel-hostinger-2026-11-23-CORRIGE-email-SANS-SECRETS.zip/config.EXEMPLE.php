<?php
// MODÈLE SANS SECRETS — à copier en config.php et remplir sur le serveur Hostinger.
// Les vraies valeurs ne doivent JAMAIS être dans le dépôt.
/**
 * ============================================================
 *  STAR OS — CONFIGURATION CENTRALE DU BACKEND
 * ============================================================
 *  ⚠️  MODIFIEZ LES 4 VALEURS CI-DESSOUS AVANT LA MISE EN LIGNE
 * ============================================================
 */

// ► 1. DOMAINE(S) AUTORISÉ(S) à appeler l'API (votre site public)
//    Ajoutez ici les domaines depuis lesquels votre site enverra les données.
define('STAR_ALLOWED_ORIGINS', [
    'https://starentreprise.vercel.app',
    'https://starentreprise-api.vercel.app',  // ← le site EST EN LIGNE à cette adresse ✔
    'https://www.starentreprise.com',      // ← votre futur domaine Hostinger
    'https://starentreprise.com',
    'http://localhost',                     // tests locaux
    'http://127.0.0.1',
]);

// ► 2. EMAIL de notification (reçoit chaque nouvelle commande / alerte)
define('STAR_NOTIFY_EMAIL', '');  // ← boîte qui reçoit les alertes ✔
define('STAR_FROM_EMAIL', '');          // (utilisé seulement en secours par PHP mail())

// ------------------------------------------------------------
//  ✉️ ENVOI D'E-MAIL VIA BREVO (gratuit : 300 e-mails/jour)
// ------------------------------------------------------------
//  1. Créez votre compte gratuit sur https://www.brevo.com
//  2. Menu « SMTP & API » → onglet « API Keys » → « Generate a new key »
//  3. Collez la clé xkeysib-... ci-dessous :
define('BREVO_API_KEY', ''); // ✔ TESTÉE LE 27/08/2026 : envoi OK (HTTP 201), expéditeur validé
//  4. Dans Brevo → « Senders & IP » → « Senders » → « + Add a sender » :
//     ajoutez contact.starentreprise@gmail.com et cliquez sur le lien
//     de confirmation reçu sur cette boîte Gmail. (sinon l'envoi sera refusé)
define('BREVO_SENDER_EMAIL', '');
define('BREVO_SENDER_NAME', '');

// ► 3. CLÉ API secrète — DOIT être identique à celle du fichier
//    star-backend-bridge.js de votre site (STAR_BACKEND_API_KEY)
define('STAR_API_KEY', '');

// ---------------------------------------------------------
//  💰 PAIEMENT MOBILE MONEY — OpenPay (MTN Money)
// ---------------------------------------------------------
//  ⚠️ CETTE CLÉ EST SECRÈTE : elle reste ICI, côté serveur.
//  Elle n'apparaît JAMAIS dans le code du site ni dans l'admin.
define('OPENPAY_API_URL', '');
define('OPENPAY_API_KEY', '');
//  'live' uniquement — la simulation est refusée (aucun e-mail « paiement reçu » fictif)
define('OPENPAY_MODE', '');

// ---------------------------------------------------------
//  💳 PAIEMENT PAR CARTE BANCAIRE (Visa / Mastercard) + Mobile Money
//  — CinetPay, agrégateur présent en République du Congo —
// ---------------------------------------------------------
//  1. Créez votre compte marchand gratuit sur https://cinetpay.com
//     (choisissez « République du Congo » comme pays à l'inscription)
//  2. Dans votre tableau de bord CinetPay → « Intégration API », récupérez :
//     - la clé API (apikey)
//     - l'identifiant de site (site_id)
//  3. Collez les deux valeurs ci-dessous. Tant que CINETPAY_APIKEY reste
//     vide, le bouton « Payer par carte bancaire » du site est simplement
//     désactivé — aucun risque pour le reste du site.
//  4. L'argent collecté (carte OU Mobile Money) arrive sur votre compte
//     marchand CinetPay, puis se transfère vers votre Mobile Money
//     (MTN/Airtel) depuis le tableau de bord CinetPay → « Transférer les
//     fonds » (délai habituel : sous 48 h, frais de transfert en sus des
//     frais de transaction). De là, retrait cash comme pour n'importe
//     quel dépôt Mobile Money reçu.
define('CINETPAY_APIKEY', '');
define('CINETPAY_SITE_ID', '');
//  Devise officielle du Congo-Brazzaville (zone CEMAC) — ne pas modifier.
define('CINETPAY_DEVISE', '');

// ---------------------------------------------------------
//  💬 SARAH SUR WHATSAPP BUSINESS (API Cloud officielle Meta)
// ---------------------------------------------------------
//  Ces 4 valeurs viennent de business.facebook.com → WhatsApp Manager
//  → Configuration de l'API (guide complet donné par Claude en chat).
//  Tant que WHATSAPP_TOKEN reste vide, l'intégration est simplement inactive
//  (aucun risque pour le reste du site : backend/whatsapp.php est isolé).
define('WHATSAPP_TOKEN', '');
define('WHATSAPP_PHONE_NUMBER_ID', '');
//  Choisissez vous-même une phrase secrète, et remettez EXACTEMENT la même
//  dans WhatsApp Manager au moment de « Vérifier et enregistrer » le webhook.
define('WHATSAPP_VERIFY_TOKEN', '');
//  Recommandé (sécurité) : « App secret » de votre app Meta — permet à
//  whatsapp.php de vérifier que chaque message reçu vient bien de Meta.
define('WHATSAPP_APP_SECRET', '');
//  Numéros que Sarah ne doit JAMAIS traiter, même business (proches, famille…),
//  au format international sans + ni espace, ex: '242066565050'.
define('WHATSAPP_PERSONAL_CONTACTS', [
    // '242XXXXXXXXX',
]);

// ---------------------------------------------------------
//  🧠 SARAH — MOTEUR IA (Anthropic Claude, CÔTÉ SERVEUR UNIQUEMENT)
// ---------------------------------------------------------
//  ⚠️ Ne collez JAMAIS de vraie clé Anthropic dans sarah-ai.js (le code du
//  site est visible par tout le monde) : elle doit vivre UNIQUEMENT ici,
//  utilisée côté serveur par backend/whatsapp.php. Sans clé, Sarah répond
//  seulement à partir de backend/sarah-knowledge.json (fiable, jamais
//  d'invention) et escalade calmement le reste vers vous.
define('ANTHROPIC_API_KEY', '');

// ---------------------------------------------------------
//  🎬 HIGGSFIELD — GÉNÉRATION IMAGES / VIDÉOS (proxy sécurisé)
// ---------------------------------------------------------
//  Ce bloc permet à Claude de générer des images/vidéos Higgsfield
//  pour STAR ENTREPRISE et X SAPHIR SANS jamais voir votre clé —
//  elle reste ICI, côté serveur, utilisée uniquement par
//  backend/higgsfield.php.
//
//  1. Allez sur open.higgsfield.ai → API Keys → copiez votre clé
//     (celle que vous venez de créer).
//  2. Collez-la ci-dessous, à la place du texte en majuscules.
//     NE LA COLLEZ JAMAIS AILLEURS (ni dans un chat, ni dans un
//     fichier public du site).
define('HIGGSFIELD_API_KEY', '');
define('HIGGSFIELD_API_BASE', '');
//  Jeton généré automatiquement (ne pas modifier) — c'est ce que
//  Claude utilise pour prouver qu'il est autorisé à appeler ce
//  proxy ; il n'a aucun rapport avec votre clé Higgsfield et peut
//  être changé à tout moment si besoin (il suffit d'en regénérer
//  un autre et de me donner le nouveau).
define('STAR_AUTOMATION_TOKEN', '');

// ► 4. BASE DE DONNÉES MySQL — Paramètres Hostinger
//    (hPanel → Bases de données → Bases de données MySQL)
define('DB_HOST', '');                          // Hostinger
define('DB_NAME', '');                  // base créée le 16/09/2026
define('DB_USER', '');                  // utilisateur MySQL
define('DB_PASS', '');                     // mot de passe MySQL Hostinger
define('DB_CHARSET', '');

// ► Identifiants de connexion à l'interface d'administration (/admin/)
define('ADMIN_USERNAME', '');
// Mot de passe : « Good24 » (haché — invisible même en lisant ce fichier)
define('ADMIN_PASSWORD_HASH', '');

// ► Durée de session admin (déconnexion auto après inactivité)
define('SESSION_DURATION', 2 * 60 * 60); // 2 heures

// ► Fuseau horaire du Congo
date_default_timezone_set('Africa/Brazzaville');

// ============================================================
//  NE RIEN MODIFIER SOUS CETTE LIGNE
// ============================================================
define('STAR_BACKEND_VERSION', '');
